#pragma once
#include <vector>
#include <GLM/glm.hpp>
#include "PathFindingAlgorithm.h"

namespace hiveCrowdSimulation
{
	class CScene;
	class CBaseGraph;

	class CBestNextFinding
	{
	public:
		CBestNextFinding(void);
		~CBestNextFinding(void);

		void setPathFindingAlgorithm(CPathFindingAlgorithm* vPathFindingAlgorithm) {m_pPathFindingAlgorithm = vPathFindingAlgorithm;}
		glm::vec2 fetchBestNext(const glm::vec2& vStart, const glm::vec2& vEnd, CScene* vScene, const CBaseGraph* vGraphWithOutCrowd, const CBaseGraph* vGraphWithCrowd, float vViewRange, std::vector<glm::vec2>& voRoad);
		glm::vec2 fetchBestNext(const glm::vec2& vStart, const glm::vec2& vEnd, CScene* vScene, const CBaseGraph* vGraphWithOutCrowd, const CBaseGraph* vGraphWithCrowd, float vViewRange, std::vector<glm::vec2>& voRoad, std::vector<glm::vec2>& voPathAfter);
	
	private:
		CPathFindingAlgorithm* m_pPathFindingAlgorithm;
	};
}