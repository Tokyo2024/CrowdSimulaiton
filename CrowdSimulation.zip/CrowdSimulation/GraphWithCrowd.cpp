#include "GraphWithCrowd.h"
#include <GLM/glm.hpp>
#include "Scene.h"

using namespace hiveCrowdSimulation;

CGraphWithCrowd::CGraphWithCrowd(CScene* vScene) : m_pScene(vScene)
{
}

CGraphWithCrowd::~CGraphWithCrowd()
{
}

//*******************************************************************
//FUNCTION:
double CGraphWithCrowd::_computeEdgeWeightV(const glm::vec2& vBegin, const glm::vec2& vEnd) const
{
	const CQuadTreeNode<SNode>* pEndNode = m_pScene->getLeafNodeBySceneCoord(vEnd);
	CSceneGrid* pEndGrid = m_pScene->fetchSceneGrid(pEndNode);

	glm::vec2 Begin2EndVec   = glm::normalize(vEnd - vBegin);
	double Distance          = glm::distance(vBegin, vEnd);
	if (pEndGrid->getCrowdDensity() == 0.0f)
	{
		return Distance;
	}
//	double CosAngle          = dot(Begin2EndVec, glm::normalize(pEndGrid->getAvgMoveDirection()));
	double CosAngle          = dot(Begin2EndVec, pEndGrid->getAvgMoveDirection());
	double ResistanceForce   = CosAngle >= 0.0 ? 1.0 : (-CosAngle * pEndGrid->getAvgSpeed());
	_ASSERT(ResistanceForce > 0.0);

	return Distance * ResistanceForce * (1.0 + pEndGrid->getCrowdDensity());
}

//********************************************************************
//FUNCTION:
void CGraphWithCrowd::__updateTwoWayEdgeWeight(const glm::vec2& vTarget)
{
	std::vector<glm::vec2> AdjacentNode;
	getAdjacentNodeSet(vTarget, AdjacentNode);

	for (auto& Node : AdjacentNode)
	{
		updateEdgeWeight(Node, vTarget, _computeEdgeWeightV(Node, vTarget));
	}
}

//********************************************************************
//FUNCTION:
void CGraphWithCrowd::updateGraph()
{
	std::vector<const CQuadTreeNode<SNode>*> QuadTreePassNodeSet;
	m_pScene->dumpPassableLeafNodes(QuadTreePassNodeSet);

	for (auto& TreeNode : QuadTreePassNodeSet)
	{
		CSceneGrid* pGrid = m_pScene->fetchSceneGrid(TreeNode);
		if (pGrid->isUpdate())
			updateGraph4SpecifiedGrid(TreeNode->getCenter());
	}
}

//********************************************************************
//FUNCTION:
void CGraphWithCrowd::updateGraph4SpecifiedGrid(const glm::vec2& vGridCenter)
{
	__updateTwoWayEdgeWeight(vGridCenter);
}