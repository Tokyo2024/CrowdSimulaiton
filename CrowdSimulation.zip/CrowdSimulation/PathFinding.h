#pragma once
#include <vector>
#include <GLM/glm.hpp>

namespace hiveCrowdSimulation
{
	class CBaseGraph;
	class CPathFinding
	{
	public:
		CPathFinding(void);
		virtual ~CPathFinding(void);

		virtual bool findShortestPathV(const CBaseGraph* vGraph, const glm::vec2& vStart, const glm::vec2& vEnd, std::vector<glm::vec2>& voSceneGridCoordSet) = 0;
		virtual bool findShortestPathV(const CBaseGraph* vGraph, const glm::vec2& vStart, const glm::vec2& vEnd) = 0;
		virtual float getTotalCost() = 0;
	};
}