#pragma once
#include <vector>
#include <queue>
#include "Common.h"

namespace hiveCrowdSimulation
{
	class CAgent;

	class CSubgroup
	{
	public:
		CSubgroup();
		~CSubgroup();

		void updateAwareness();
		void setSubgroupState(bool vFlag) {m_NewSubgroup = vFlag;}
		void addAgent(CAgent* vAgent);
		void exchangeInfo();
		void updateCenter();
		void setToDoTask(STaskInfo* vTask);
		void finishTask();
		void setNecessity2MakeDecision(bool vFlag) {m_Necessary2MakeDecision = vFlag;}
		void splitSubgroup(std::vector<CSubgroup*>& voSplitSubGroupSet);
		void updateTimeElapsed();
		void setAttention(float vAttention);
		void updateFinishState(bool& voFlag);
		
		bool getSubgroupState() {return m_NewSubgroup;}
		bool reachTempGoal();
		bool getToDoState() const {return m_DoTask;}
		bool isAwareness() const {return m_IsAwareness;}
		bool isAgentInThisSubgroup(const CAgent* vAgent) const;
		bool isNecessary2MakeDecision() {return m_Necessary2MakeDecision;}   
		bool isAble2MergeThisSubgroupAndSetTaskFinishedIfNecessiry(CSubgroup* vSubGroup);

		STaskInfo*    getTaskInfo() const {return m_Task;}
		CSubgroup*    generateTask();
		CAgent*       fetchAgent(unsigned int vIndex) const; 
		unsigned int  getNumSubgroupMembers() const {return m_AgentSet.size();}
		int           getTimeElapsed();
		float         getAttention();
		glm::vec2     getSubgroupCenter() const;
		const CAgent* getTargetAgent() const;

		//********************************************************************
        #ifdef _DEBUG
		void setDefaultIntimacy();
        #endif
		
	private:
		void __judgeIfNecessary2MakeDecision(std::vector<CSubgroup*>& voSplitSubgroupSet);
		std::pair<CAgent*, SCost2FindSomeone*> __chooseCandidate();

	private:
		bool                 m_IsAwareness;
		STaskInfo*           m_Task;
		std::vector<CAgent*> m_AgentSet;
		bool m_NewSubgroup;
		bool m_DoTask;
		bool m_Necessary2MakeDecision;
		glm::vec2 m_SubgroupCenter;
		std::vector<std::pair<CAgent*, SCost2FindSomeone*>> m_TargetCandidates;
	};
}