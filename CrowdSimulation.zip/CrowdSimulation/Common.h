#pragma once
#include <GLM/glm.hpp>
#include <boost/random.hpp>
#include "SimulationTools.h"

namespace hiveCrowdSimulation
{
	class CAgent;
	class CSubgroup;

	struct SPoint
	{
		SPoint() 
		{
			pParent             = NULL;
			CostOfStart2Current = 0.0;
			CostOfCurrent2End   = 0.0;
			TotalCost           = 0.0;
		}
		SPoint(const glm::vec2& vGrid, SPoint* vParent, double vCostOfStart2Current, double vCostOfCurrent2End)
		{
			Grid                = vGrid;
			pParent             = vParent;
			CostOfStart2Current = vCostOfStart2Current;
			CostOfCurrent2End   = vCostOfCurrent2End;
			TotalCost           = CostOfStart2Current + CostOfCurrent2End;
		}
		SPoint(const glm::vec2& vGrid, SPoint* vParent)
		{
			Grid    = vGrid;
			pParent = vParent;
			CostOfStart2Current = 0.0;
			CostOfCurrent2End   = 0.0;
			TotalCost           = 0.0;
		}
		~SPoint() {}

		SPoint* pParent;
		glm::vec2 Grid;
		double CostOfStart2Current;
		double CostOfCurrent2End;
		double TotalCost;
	};

	struct SAgentRelationship
	{
		SAgentRelationship() : Intimacy(0.0), LastCheckTime(0){}
		float Intimacy;
		int   LastCheckTime;
		glm::vec2 LastPosition;
	};

	struct STaskInfo
	{
		STaskInfo() : pTargetAgent(NULL), TimeElapsed(0), Attention(0.0) {}
		STaskInfo(const CAgent* vAgent, int vTimeElapsed, float vAttention)
		{
			_ASSERT(vAgent);
			pTargetAgent = vAgent;
			TimeElapsed  = vTimeElapsed;
			Attention    = vAttention;
		}

		const CAgent* pTargetAgent;
		int           TimeElapsed;
		float         Attention;
	};

	struct SCost2FindSomeone
	{
		const CAgent* pTargetAgent;
		float   Attention;
	};
}