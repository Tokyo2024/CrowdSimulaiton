#include "CrowdSimulation.h"
#include <algorithm>
#include <fstream>
#include <eigen/dense>
#include "PrepareScene.h"
#include "AgentConfig.h"
#include "CrowdSimulationConfig.h"
#include "IAgent.h"
#include "SubGroup.h"
#include "Group.h"
#include "Scene.h"
#include "AStar.h"
#include "AgentGenerator.h"
#include "SimulationTools.h"
#include "GraphWithCrowd.h"
#include "GraphWithoutCrowd.h"
#include "BestNextFinding.h"
#include "GroupForce.h"
#include <cmath>

using namespace hiveCrowdSimulation;

CCrowdSimulation::CCrowdSimulation() : m_NumElapsedFrame(0)
{
	m_pRVOSimulator    = new RVO::RVOSimulator();
	m_pBestNextFinding = new CBestNextFinding();
	m_pKnnSearch = new CKNNSearch;
	m_NeighborNum = std::min(CCrowdSimulationConfig::getInstance()->getNeighbourNum(), m_pRVOSimulator->getNumAgents()-1);
}

CCrowdSimulation::~CCrowdSimulation()
{
	delete m_pKnnSearch;
	delete m_pRVOSimulator;
	delete m_pBestNextFinding;
	delete m_pPathFinding;

	for (auto& Agent : m_AgentSet)
	{
		delete Agent;
	}

	for (auto& Group : m_GroupSet)
	{
		delete Group;
	}
}

//*******************************************************************
//FUNCTION:
bool CCrowdSimulation::isFinished()
{
	bool Flag = true;

	for (auto& Group : m_GroupSet)
	{
		Group->updateFinishState(Flag);
	}

	for (auto& Agent : m_AgentSet)
	{
		Agent->updateFinishState(Flag);
	}
	return Flag;
}

//*******************************************************************
//FUNCTION:
void CCrowdSimulation::__updateVelocityInfluencedByGroup()
{
	for (unsigned int m=0; m<m_GroupSet.size(); m++) 
	{
		CGroup* pGroup = m_GroupSet[m];		
		for (unsigned int i=0; i<pGroup->getNumSubgroup(); i++)
		{
			CSubgroup* pSubgroup = pGroup->fetchSubgroup(i);
			if (pSubgroup->getNumSubgroupMembers() == 1)
			{
				continue;
			}

			for (unsigned int k=0; k<pSubgroup->getNumSubgroupMembers(); k++)
			{
				glm::vec2 VelocityInfluencedByTarget, VelocityInfluencedByAllGroupMembers, VelocityInfluencedByAwareGroupMembers;
				CAgent* pTempAgent = pSubgroup->fetchAgent(k);

				m_GroupForce(pSubgroup, pTempAgent, VelocityInfluencedByAllGroupMembers);

				if (!pTempAgent->isAwareness()) 
				{
					m_GroupForce(pSubgroup, pTempAgent, VelocityInfluencedByAwareGroupMembers);
				} 

				VelocityInfluencedByTarget = pTempAgent->getPrefVelocity(); 
				float PartA = CCrowdSimulationConfig::getInstance()->getWeightOfTargetForce();
				float PartB = CCrowdSimulationConfig::getInstance()->getWeightOfGroupCohesionForce();
				float PartC = CCrowdSimulationConfig::getInstance()->getWeightOfGroupAwarenessForce();
				glm::vec2 FinalPrefVelocity = (PartA * VelocityInfluencedByTarget + PartB * VelocityInfluencedByAllGroupMembers + PartC * VelocityInfluencedByAwareGroupMembers); //different contribution for final velocity
				pTempAgent->setPreferedVelocity(FinalPrefVelocity);
			}
		}
	}
}

//********************************************************************
//FUNCTION:
void hiveCrowdSimulation::CCrowdSimulation::__updateVelocityInfluencedByTarget()
{
	int Temp = 0;
	for (auto& Agent : m_AgentSet)
	{
		std::vector<glm::vec2> AgentRoadMapSet;
		Agent->dumpRoadMap(AgentRoadMapSet);

		glm::vec2 TargetVelocity = __computeVelocityInfluencedByTarget(Agent->getPosition(), AgentRoadMapSet);
		Agent->updateRoadmap(AgentRoadMapSet);
		Agent->setPreferedVelocity(TargetVelocity);
		Temp++;
	}
	for (auto& Group : m_GroupSet)
	{
		for (unsigned int i=0; i<Group->getNumSubgroup(); ++i)
		{
			const CSubgroup* pSubgroup = Group->fetchSubgroup(i);
			for (unsigned int k=0; k<pSubgroup->getNumSubgroupMembers(); ++k)
			{
				CAgent* pSubgroupMember = pSubgroup->fetchAgent(k);
				std::vector<glm::vec2> RoadMapSet; 
				pSubgroupMember->dumpRoadMap(RoadMapSet);
				glm::vec2 TargetVelocity = __computeVelocityInfluencedByTarget(pSubgroupMember->getPosition(), RoadMapSet);
			    pSubgroupMember->updateRoadmap(RoadMapSet);
				pSubgroupMember->setPreferedVelocity(TargetVelocity);
			}
		}
	}
}

//*******************************************************************
//FUNCTION: 
glm::vec2 CCrowdSimulation::__computeVelocityInfluencedByTarget(const glm::vec2& vPos, std::vector<glm::vec2>& vioRoadMap)
{
	if (vioRoadMap.size() == 0)
	{
		return glm::vec2(0, 0);
	}

	float Dist = glm::distance(vioRoadMap[0], vPos);
	while (Dist < CCrowdSimulationConfig::getInstance()->getOffset())
	{
		vioRoadMap.erase(vioRoadMap.begin());
		//Dist = sqrt((vioRoadMap[0].x - vPos.x) * (vioRoadMap[0].x - vPos.x) + (vioRoadMap[0].y - vPos.y) * (vioRoadMap[0].y - vPos.y));
		if (vioRoadMap.size()== 0)
		{
			break;
		}
		Dist = glm::distance(vioRoadMap[0], vPos);
	}
	glm::vec2 TargetVelocity;
	return vioRoadMap.size() == 0 ? TargetVelocity : glm::normalize(vioRoadMap[0] - vPos);
}

//*******************************************************************
//FUNCTION:
void CCrowdSimulation::initSimulator()
{
	CAStar* pPathFinding = new CAStar;
	setPathFinding(pPathFinding);
	m_pBestNextFinding->setPathFindingAlgorithm(pPathFinding);
	setGroupForce(CGroupForce::computeGroupForceByGroupCenter);
	m_pRVOSimulator->setTimeStep(CCrowdSimulationConfig::getInstance()->getTimeStep());
	m_pRVOSimulator->setAgentDefaults(CAgentConfig::getInstance()->getNeighborDist(), CAgentConfig::getInstance()->getMaxNeighbors(), CAgentConfig::getInstance()->getTimeHorizon(), CAgentConfig::getInstance()->getTimeHorizonObst(), CAgentConfig::getInstance()->getRadius(), CAgentConfig::getInstance()->getMaxSpeed());
}

//********************************************************************
//FUNCTION:
void hiveCrowdSimulation::CCrowdSimulation::initAgentWithSpecifiedInfo(const glm::vec2& vPos, bool vIsAwareness, int vGroupID)
{
	const CQuadTreeNode<SNode>* pNode4PlacingAgent = m_pScene->getLeafNodeBySceneCoord(vPos);
	_ASSERT(pNode4PlacingAgent->getExtraInfo().Passability == PASS);
	CAgentGenerator* pAgentGenerator =new CAgentGenerator();
	CAgent* pAgent = pAgentGenerator->genAgentAtFixedCoordinate(m_pScene, vPos);
	pAgent->setAwareness(vIsAwareness);
	pAgent->setGroupID(vGroupID);

	if (vIsAwareness)
	{
		pAgent->setInitSpeed(CAgentConfig::getInstance()->getMaxSpeed());
	}

	unsigned int Index;
	if (vGroupID == -1)
	{
		Index = addNoGroupMemberAgent(pAgent);
	}
	else
	{
		CGroup* pGroup = NULL;
		if (getNumGroups() > vGroupID)
		{
			pGroup = getGroup(vGroupID);
		}
		else
		{
			pGroup = new CGroup();
			addGroup2GroupSet(pGroup);
		}
		pGroup->addGroupMember(pAgent);
		unsigned int Index = m_pRVOSimulator->addAgent(pAgent->getInitPosition());
	}
	CSceneGrid* pGrid4PlacingAgent = m_pScene->fetchSceneGrid(pNode4PlacingAgent);
	initAgentAdditionalInfo(m_pRVOSimulator, Index, pGrid4PlacingAgent->getCoordinate(), pAgent);
	pGrid4PlacingAgent->addAgent(pAgent);

	delete pAgentGenerator;
}

//********************************************************************
//FUNCTION:
void hiveCrowdSimulation::CCrowdSimulation::initCrowdDistribution(unsigned int vNumTotalAgent, unsigned int vNumIgnorantAgent, unsigned int vNumNotGroupMembers, unsigned int vNumGroups, unsigned int voMinNumGroupMembers, unsigned int voMaxNumGroupMembers)
{
	_ASSERT(m_pScene);
	__initNotGroupMemberDistribution(vNumNotGroupMembers);
	__initGroupDistribution(vNumTotalAgent-vNumNotGroupMembers, vNumGroups, voMinNumGroupMembers, voMaxNumGroupMembers);
	__setIgnorance4Crowd(vNumIgnorantAgent);
}

//********************************************************************
//FUNCTION:
void hiveCrowdSimulation::CCrowdSimulation::addCrowdDistributionAtSpecificArea(const glm::vec2& vCenter, int vRadius, unsigned int vNumNotGroupMembers, bool vIsAware)
{
	_ASSERT(m_pScene);
	__initNotGroupMumberDistributionAtSpecificArea(vCenter, vRadius, vNumNotGroupMembers);
	if (!vIsAware)
		__setIgnorance4Crowd(vNumNotGroupMembers);
}

//********************************************************************
//FUNCTION:
void hiveCrowdSimulation::CCrowdSimulation::__initGroupDistribution(unsigned int vNumOfAllGroupMembers, unsigned int vNumGroup, unsigned int voMinNumGroupMembers, unsigned int voMaxNumGroupMembers)
{
	__dumpGroupInfo(vNumOfAllGroupMembers, vNumGroup, voMinNumGroupMembers, voMaxNumGroupMembers);

	for (unsigned int i=0; i<m_GroupSet.size(); i++)
	{
		__initGroupMembers(i);
		m_GroupSet[i]->initRelationship(); 
	}
}

//********************************************************************
//FUNCTION:
void hiveCrowdSimulation::CCrowdSimulation::__dumpGroupInfo(int vNumOfAllGroupMembers, int vNumGroup, int voMinNumGroupMembers, int voMaxNumGroupMembers)
{
	int CurMin      = voMinNumGroupMembers;
	int CurMax      = voMaxNumGroupMembers;
	int RestMembers = vNumOfAllGroupMembers;
	int TempNumGroupMembers = 0;
	int GeneratedGroupMembers = 0;
	for (int i=0; i<vNumGroup; ++i)
	{
		CurMin = (voMinNumGroupMembers > RestMembers-voMaxNumGroupMembers*(vNumGroup-i-1) ? voMinNumGroupMembers : RestMembers-voMaxNumGroupMembers*(vNumGroup-i-1));
		CurMax = (voMaxNumGroupMembers < RestMembers-voMinNumGroupMembers*(vNumGroup-i-1) ? voMaxNumGroupMembers : RestMembers-voMinNumGroupMembers*(vNumGroup-i-1));
		TempNumGroupMembers = getIntRandom(CurMin, CurMax);
		RestMembers -= TempNumGroupMembers;
		CGroup* pGroup = new CGroup();
		pGroup->setGroupSize(TempNumGroupMembers);
		addGroup2GroupSet(pGroup);
	}
}

//********************************************************************
//FUNCTION:
void hiveCrowdSimulation::CCrowdSimulation::__initNotGroupMemberDistribution(unsigned int vNumNotGroupMembers)
{
	for (unsigned int i=0; i<vNumNotGroupMembers; i++)
	{
		CSceneGrid* pGrid4PlacingAgent = NULL;
		CAgent* pAgent = __genRandomAgent(pGrid4PlacingAgent);
		size_t Index = addNoGroupMemberAgent(pAgent);
		initAgentAdditionalInfo(m_pRVOSimulator, Index, pGrid4PlacingAgent->getCoordinate(), pAgent);
		pGrid4PlacingAgent->addAgent(pAgent);
		pAgent->setGoalPos(glm::vec2(-FLT_MAX, -FLT_MAX));
		pAgent->setIndex(i);
	}
}

//********************************************************************
//FUNCTION:
void hiveCrowdSimulation::CCrowdSimulation::__initNotGroupMumberDistributionAtSpecificArea(const glm::vec2& vCenter, int vRadius, unsigned int vNumNotGroupMembers)
{
	for (unsigned int i=0; i<vNumNotGroupMembers; ++i)
	{
		CSceneGrid* pGrid4PlacingAgent = NULL;
		CAgent* pAgent = __genRandomAgentAtSpecificArea(vCenter, vRadius, pGrid4PlacingAgent);
		size_t Index = addNoGroupMemberAgent(pAgent);
		initAgentAdditionalInfo(m_pRVOSimulator, Index, pGrid4PlacingAgent->getCoordinate(), pAgent);
		pGrid4PlacingAgent->addAgent(pAgent);
		pAgent->setGoalPos(glm::vec2(-FLT_MAX, -FLT_MAX));
		pAgent->setIndex(i);
	}
}

//********************************************************************
//FUNCTION:
CAgent* hiveCrowdSimulation::CCrowdSimulation::__genRandomAgent(CSceneGrid*& voGrid)
{
	glm::vec2 PassablePosCoord;
	const CQuadTreeNode<SNode>* pPassableLeafNode;

	int OffSet = CAgentConfig::getInstance()->getRadius();
	int MinWidth = m_pScene->getSceneWidth() / std::pow(2, CCrowdSimulationConfig::getInstance()->getMinNodeDeep());
	int MinHeight = m_pScene->getSceneHeight() / std::pow(2, CCrowdSimulationConfig::getInstance()->getMinNodeDeep());
	do {
		PassablePosCoord = glm::vec2(getIntRandom(OffSet, m_pScene->getSceneWidth() - OffSet), getIntRandom(OffSet, m_pScene->getSceneHeight() - OffSet));
		pPassableLeafNode = m_pScene->getLeafNodeBySceneCoord(PassablePosCoord);
	} while (pPassableLeafNode->getExtraInfo().Passability == NOPASS || m_pScene->getLeafNodeBySceneCoord(PassablePosCoord)->getWidth() == MinWidth || m_pScene->getLeafNodeBySceneCoord(PassablePosCoord)->getHeight() == MinHeight);

	glm::vec4 Rectangle = pPassableLeafNode->getRectangle();
	PassablePosCoord = glm::vec2(getIntRandom(Rectangle.x + 2 * OffSet, Rectangle.z - 2 * OffSet), getIntRandom(Rectangle.y + 2 * OffSet, Rectangle.w - 2 * OffSet));

	voGrid = m_pScene->fetchSceneGrid(pPassableLeafNode);
	CAgentGenerator* pAgentGenerator = new CAgentGenerator();
	CAgent* pAgent = pAgentGenerator->genAgentAtFixedCoordinate(m_pScene, PassablePosCoord);
	delete pAgentGenerator;
	return pAgent;
}

//*******************************************************************
//FUNCTION:
void hiveCrowdSimulation::CCrowdSimulation::__genRectBySpecificPos(const glm::vec2& vCenter, int vRadius, glm::vec2& voMinPoint, glm::vec2& voMaxPoint)
{
	float SceneWidth  = m_pScene->getSceneWidth();
	float SceneHeight = m_pScene->getSceneHeight();

	_ASSERT(vCenter.x >= 0 && vCenter.x < SceneWidth);
	_ASSERT(vCenter.y >= 0 && vCenter.y < SceneHeight);

	float MinX = vCenter.x - vRadius;
	float MaxX = vCenter.x + vRadius;
	float MinY = vCenter.y - vRadius;
	float MaxY = vCenter.y + vRadius;

	if (MinX < 0)
		MinX = 0;
	if (MaxX >= SceneWidth)
		MaxX = SceneWidth - 1;
	if (MinY < 0)
		MinY = 0;
	if (MaxY >= SceneHeight)
		MaxY = SceneHeight - 1;

	voMinPoint.x = MinX;
	voMinPoint.y = MinY;
	voMaxPoint.x = MaxX;
	voMaxPoint.y = MaxY;
}

//*******************************************************************
//FUNCTION:
CAgent* hiveCrowdSimulation::CCrowdSimulation::__genRandomAgentAtSpecificArea(const glm::vec2& vCenter, int vRadius, CSceneGrid*& voGrid)
{
	glm::vec2 MinPoint, MaxPoint;
	__genRectBySpecificPos(vCenter, vRadius, MinPoint, MaxPoint);

	int OffSet = CAgentConfig::getInstance()->getRadius();
	glm::vec2 PassablePosCoord;
	const CQuadTreeNode<SNode>* pPassableLeafNode;
	do {
		PassablePosCoord = glm::vec2(getIntRandom(MinPoint.x + OffSet, MaxPoint.x - OffSet), getIntRandom(MinPoint.y + OffSet, MaxPoint.y - OffSet));
		pPassableLeafNode = m_pScene->getLeafNodeBySceneCoord(PassablePosCoord);
	} while (pPassableLeafNode->getExtraInfo().Passability == NOPASS);

	voGrid = m_pScene->fetchSceneGrid(pPassableLeafNode);
	CAgentGenerator* pAgentGenerator = new CAgentGenerator();
	CAgent* pAgent = pAgentGenerator->genAgentAtFixedCoordinate(m_pScene, PassablePosCoord);
	delete pAgentGenerator;
	return pAgent;
}

//*******************************************************************
//FUNCTION:
void hiveCrowdSimulation::CCrowdSimulation::__initGroupMembers(unsigned int vGroupIndex)
{
	_ASSERT(vGroupIndex < m_GroupSet.size());

	CGroup* pGroup = m_GroupSet[vGroupIndex];
	CSceneGrid* pGrid = NULL;
	CAgentGenerator* pAgentGenerator = new CAgentGenerator();
	int MaxR = CAgentConfig::getInstance()->getNeighborDist();
	int Radius = CAgentConfig::getInstance()->getRadius();

	glm::vec2 CenterAgentCoordinate;
	glm::vec2 OtherAgentCoordinate;
	int MinWidth = m_pScene->getSceneWidth() / std::pow(2, CCrowdSimulationConfig::getInstance()->getMinNodeDeep());
	int MinHeight = m_pScene->getSceneHeight() / std::pow(2, CCrowdSimulationConfig::getInstance()->getMinNodeDeep());
	CAgent* pAgent = NULL;
	const CQuadTreeNode<SNode>* pCenterAgentCoordinateLeafNode = NULL;
	const CQuadTreeNode<SNode>* pOtherAgentCoordinateLeadNode = NULL;
	float Distance = 0;

	for (int i=0; i<pGroup->getNumGroupMembers(); ++i)
	{
		if (i == 0)
		{
			CenterAgentCoordinate.x = getIntRandom(Radius, m_pScene->getSceneWidth() - Radius);
			CenterAgentCoordinate.y = getIntRandom(Radius, m_pScene->getSceneHeight() - Radius);
			pCenterAgentCoordinateLeafNode = m_pScene->getLeafNodeBySceneCoord(CenterAgentCoordinate);
			while (!m_pScene->isCoordinateInPassableSceneGrid(CenterAgentCoordinate, pGrid) || pCenterAgentCoordinateLeafNode->getWidth() == MinWidth || pCenterAgentCoordinateLeafNode->getHeight() == MinHeight)
			{
				CenterAgentCoordinate.x = getIntRandom(Radius, m_pScene->getSceneWidth()-Radius);
				CenterAgentCoordinate.y = getIntRandom(Radius, m_pScene->getSceneHeight()-Radius);
				pCenterAgentCoordinateLeafNode = m_pScene->getLeafNodeBySceneCoord(CenterAgentCoordinate);
			}
			glm::vec4 Rectangle = pCenterAgentCoordinateLeafNode->getRectangle();
			CenterAgentCoordinate = glm::vec2(getIntRandom(Rectangle.x + 2 * Radius, Rectangle.z - 2 * Radius), getIntRandom(Rectangle.y + 2 * Radius, Rectangle.w - 2 * Radius));
			pAgent = pAgentGenerator->genAgentAtFixedCoordinate(m_pScene, CenterAgentCoordinate);
		}
		else
		{
			do 
			{
				OtherAgentCoordinate.x = getIntRandom(CenterAgentCoordinate.x - MaxR + Radius, CenterAgentCoordinate.x + MaxR - Radius);
				OtherAgentCoordinate.y = getIntRandom(CenterAgentCoordinate.y - MaxR + Radius, CenterAgentCoordinate.y + MaxR - Radius);
				pOtherAgentCoordinateLeadNode = m_pScene->getLeafNodeBySceneCoord(OtherAgentCoordinate);
				Distance = glm::distance(OtherAgentCoordinate, OtherAgentCoordinate);
				while (!m_pScene->isVisible(CenterAgentCoordinate, OtherAgentCoordinate, CAgentConfig::getInstance()->getVisualRange()) || !m_pScene->isCoordinateInPassableSceneGrid(OtherAgentCoordinate, pGrid) || m_pScene->getLeafNodeBySceneCoord(OtherAgentCoordinate)->getWidth() == MinWidth || m_pScene->getLeafNodeBySceneCoord(OtherAgentCoordinate)->getHeight() == MinHeight)
				{
					OtherAgentCoordinate.x = m_pScene->getIntRandomXInScene(CenterAgentCoordinate.x - MaxR + Radius, CenterAgentCoordinate.x + MaxR - Radius);
					OtherAgentCoordinate.y = m_pScene->getIntRandomYInScene(CenterAgentCoordinate.y - MaxR + Radius, CenterAgentCoordinate.y + MaxR - Radius);
					pOtherAgentCoordinateLeadNode = m_pScene->getLeafNodeBySceneCoord(OtherAgentCoordinate);
					Distance = glm::distance(OtherAgentCoordinate, CenterAgentCoordinate);
				}
				glm::vec4 Rectangle = pOtherAgentCoordinateLeadNode->getRectangle();
				OtherAgentCoordinate = glm::vec2(getIntRandom(Rectangle.x + Radius, Rectangle.z - Radius), getIntRandom(Rectangle.y + Radius, Rectangle.w - Radius));
				
			} while (Distance > MaxR - 2 * Radius);
			pAgent = pAgentGenerator->genAgentAtFixedCoordinate(m_pScene, OtherAgentCoordinate);
		}
		size_t Index = m_pRVOSimulator->addAgent(pAgent->getInitPosition());
		initAgentAdditionalInfo(m_pRVOSimulator, Index, pGrid->getCoordinate(), pAgent);
		pAgent->setGroupID(vGroupIndex);
		pGroup->addGroupMember(pAgent);
		pGrid->addAgent(pAgent);
	}

	delete pAgentGenerator;
}

//********************************************************************
//FUNCTION:
void hiveCrowdSimulation::CCrowdSimulation::initAgentAdditionalInfo(RVO::RVOSimulator* vRVOSimulator, unsigned int vIndex, const glm::vec2& vGridID, CAgent* vioAgent)
{
	_ASSERT(vioAgent);

	vioAgent->setRVOAgent(vRVOSimulator->getAgent(vIndex));
	vioAgent->setTempGoal(vioAgent->getInitPosition());
	vioAgent->setGridID(vGridID);
}

//*******************************************************************
//FUNCTION:
void CCrowdSimulation::addObstacleToRVO()
{
	std::vector<const CQuadTreeNode<SNode>*> ObstacleSet;
	m_pScene->dumpNoPassableLeafNodes(ObstacleSet);

	for (auto Obstacle : ObstacleSet)
	{
		std::vector<glm::vec2> TempObstacle;
		TempObstacle.push_back(glm::vec2(Obstacle->getMinX(), Obstacle->getMinY()));
		TempObstacle.push_back(glm::vec2(Obstacle->getMinX(), Obstacle->getMaxY()));
		TempObstacle.push_back(glm::vec2(Obstacle->getMaxX(), Obstacle->getMinY()));
		TempObstacle.push_back(glm::vec2(Obstacle->getMaxX(), Obstacle->getMaxY()));
		m_pRVOSimulator->addObstacle(TempObstacle);
	}

	int Width = m_pScene->getSceneWidth();
	int Height = m_pScene->getSceneHeight();
	std::vector<glm::vec2> BorderObstacle;
	BorderObstacle.push_back(glm::vec2(-1, 0));
	BorderObstacle.push_back(glm::vec2(0, 0));
	BorderObstacle.push_back(glm::vec2(-1, Height));
	BorderObstacle.push_back(glm::vec2(0, Height));
	m_pRVOSimulator->addObstacle(BorderObstacle);

	BorderObstacle.clear();
	BorderObstacle.push_back(glm::vec2(Width, 0));
	BorderObstacle.push_back(glm::vec2(Width+1, 0));
	BorderObstacle.push_back(glm::vec2(Width, Height));
	BorderObstacle.push_back(glm::vec2(Width+1, Height));
	m_pRVOSimulator->addObstacle(BorderObstacle);

	BorderObstacle.clear();
	BorderObstacle.push_back(glm::vec2(-1, -1));
	BorderObstacle.push_back(glm::vec2(Width+1, -1));
	BorderObstacle.push_back(glm::vec2(-1, 0));
	BorderObstacle.push_back(glm::vec2(Width+1, 0));
	m_pRVOSimulator->addObstacle(BorderObstacle);

	BorderObstacle.clear();
	BorderObstacle.push_back(glm::vec2(-1, Height));
	BorderObstacle.push_back(glm::vec2(Width+1, Height));
	BorderObstacle.push_back(glm::vec2(-1, Height+1));
	BorderObstacle.push_back(glm::vec2(Width+1, Height+1));
	m_pRVOSimulator->addObstacle(BorderObstacle);

	m_pRVOSimulator->processObstacles();
}

//*******************************************************************
//FUNCTION:
void CCrowdSimulation::__updateRoadMap()
{
	m_pKnnSearch->destructData();
	std::vector<glm::vec2> AgentPositionSet;
	for (unsigned int i=0; i<m_pRVOSimulator->getNumAgents(); ++i)
		AgentPositionSet.push_back(m_pRVOSimulator->getAgent(i)->getPosition());

	if (CCrowdSimulationConfig::getInstance()->getAwarenessPercentage() < 1.0)
		m_pKnnSearch->initKNNSearch(AgentPositionSet, CCrowdSimulationConfig::getInstance()->getDimension(), m_NeighborNum);

	for (auto& Agent : m_AgentSet)
		__updateRoadMapForOneAgent (Agent, m_pKnnSearch);

	for (auto& Group : m_GroupSet)
	{
		for (unsigned int i=0; i<Group->getNumSubgroup(); ++i)
		{
			CSubgroup* pSubgroup = Group->fetchSubgroup(i);
			CAgent* pTempAgent = pSubgroup->fetchAgent(0);
			bool TestA = pSubgroup->reachTempGoal();
			__checkAround(pSubgroup);
			if ((pSubgroup->reachTempGoal() && (!pTempAgent->hasFoundExit())) || pSubgroup->getSubgroupState() == true)
			{
				if (pSubgroup->isAwareness())
				{
					CAgent* pTempAgent = pSubgroup->fetchAgent(0);
					std::vector<glm::vec2> Road;
					std::vector<glm::vec2> PathAfter;
					glm::vec2 BestNext = m_pBestNextFinding->fetchBestNext(pTempAgent->getPosition(), pTempAgent->getGoal(), m_pScene, m_pGraphWithoutCrowd, m_pGraphWithCrowd, CAgentConfig::getInstance()->getVisualRange(), Road);
					Road.push_back(pTempAgent->getGoal());
					for (unsigned int k=0; k<pSubgroup->getNumSubgroupMembers(); ++k)
					{
						CAgent* pTempAgent = pSubgroup->fetchAgent(k);
						pTempAgent->updateRoadmap(Road);
						pTempAgent->setTempGoal(BestNext);
					}
					pSubgroup->setSubgroupState(false);
				}
				else
				{
					CAgent* pTempAgent = pSubgroup->fetchAgent(0);
					const CQuadTreeNode<SNode>* pTempNode;
					std::vector<glm::vec2> VelocitySet;
					std::vector<glm::vec2> NavigationPointSet;
					std::vector<float>     IndexSet;
					glm::vec2 NavigationPoint;
					const CQuadTreeNode<SNode>* pNode = m_pScene->getLeafNodeBySceneCoord(pTempAgent->getPosition());

					float Angle = 0.0f;
					while ((Angle += 10.0f) < 360.0f)
					{
						glm::vec2 AgentVelocity = pTempAgent->getVelocity();
						if (AgentVelocity == glm::vec2(0.0, 0.0))
							AgentVelocity = glm::vec2(1.0, 0.0);
						glm::vec2 Velocity = rotateVector(AgentVelocity, Angle);
						glm::vec2 TempPosition = pTempAgent->getPosition() + Velocity * CCrowdSimulationConfig::getInstance()->getAdvanceTime();
						/*float Offset = CCrowdSimulationConfig::getInstance()->getAttribute<float>(OFFSET); 
						TempPosition = glm::vec2(std::max(Offset, std::min(TempPosition.x, m_pScene->getSceneWidth() - 1)), std::max(Offset, std::min(TempPosition.y, m_pScene->getSceneHeight() - 1)));*/
						if (TempPosition.x < 1 || TempPosition.x > m_pScene->getSceneWidth() - 1 || TempPosition.y < 1 || TempPosition.y > m_pScene->getSceneHeight() - 1) continue;
						pTempNode = m_pScene->getLeafNodeBySceneCoord(TempPosition);
						//if (pNode == pTempNode) continue;
						if (pTempNode->getExtraInfo().Passability == PASS)
						{
							VelocitySet.push_back(Velocity);
							NavigationPointSet.push_back(TempPosition);
							float Possbility = (Angle >= 270.0f) || (Angle <= 90.0f) ? 3.0 : 1.0;//magic number
							IndexSet.push_back(Possbility);
						}
					}

					//int Index = getIntRandom(0, IndexSet.size()-1);
					int Index = choseByRoulette(IndexSet);

					pTempAgent->setVelocity(VelocitySet[Index]);
					NavigationPoint = NavigationPointSet[Index];

					std::vector<glm::vec2> RoadSet;
					m_pPathFinding->findShortestPathV(m_pGraphWithoutCrowd, m_pScene->getLeafNodeBySceneCoord(pTempAgent->getPosition())->getCenter(), m_pScene->getLeafNodeBySceneCoord(NavigationPoint)->getCenter(), RoadSet);
					RoadSet.push_back(NavigationPoint);
					pTempAgent->setTempGoal(RoadSet[RoadSet.size()-1]);
					pTempAgent->updateRoadmap(RoadSet);
					for (unsigned int k=0; k<pSubgroup->getNumSubgroupMembers(); ++k)
					{
						CAgent* pTempAgent = pSubgroup->fetchAgent(k);
						pTempAgent->setTempGoal(RoadSet[RoadSet.size()-1]);
						pTempAgent->updateRoadmap(RoadSet);
					}
					pSubgroup->setSubgroupState(false);
				}				
			}			
		}
	}
}

//*******************************************************************
//FUNCTION:
void CCrowdSimulation::setScene(CScene* vScene)
{
	_ASSERT(vScene);

	m_pScene = vScene;
}

//*******************************************************************
//FUNCTION:
void hiveCrowdSimulation::CCrowdSimulation::updateScene()
{
	bool IsUpdate = false;

	for (auto Agent : m_AgentSet)
	{
		const CQuadTreeNode<SNode>* pNode = m_pScene->getLeafNodeBySceneCoord(Agent->getPosition());
		CSceneGrid* pGrid = m_pScene->fetchSceneGrid(pNode);
		if (pGrid->getCoordinate() != Agent->getGridID())
		{
			const CQuadTreeNode<SNode>* pTempNode = m_pScene->getLeafNodeBySceneCoord(Agent->getGridID());
			CSceneGrid* pTempGrid = m_pScene->fetchSceneGrid(pTempNode);
			pGrid->addAgent(Agent);
			pTempGrid->deleteAgent(Agent);
			Agent->setGridID(pGrid->getCoordinate());
			IsUpdate = true;
		}
	}

	for (auto& Group : m_GroupSet)
	{
		for (unsigned int i=0; i<Group->getNumSubgroup(); ++i)
		{
			CSubgroup* pTempSubgroup = Group->fetchSubgroup(i);
			for (unsigned int k=0; k<Group->fetchSubgroup(i)->getNumSubgroupMembers(); ++k)
			{
				CAgent* pTempAgent = pTempSubgroup->fetchAgent(k);
				const CQuadTreeNode<SNode>* pNode = m_pScene->getLeafNodeBySceneCoord(pTempAgent->getPosition());
				CSceneGrid* pGrid = m_pScene->fetchSceneGrid(pNode);
				if (pGrid->getCoordinate() != pTempAgent->getGridID())
				{
					const CQuadTreeNode<SNode>* pTempNode = m_pScene->getLeafNodeBySceneCoord(pTempAgent->getGridID());
					CSceneGrid* pTempGrid = m_pScene->fetchSceneGrid(pTempNode);
					pGrid->addAgent(pTempAgent);
					pTempGrid->deleteAgent(pTempAgent);
					pTempAgent->setGridID(pGrid->getCoordinate());
					IsUpdate = true;
				}
			}
		}
	}

	if (IsUpdate)
		m_pGraphWithCrowd->updateGraph();
}

//********************************************************************
//FUNCTION:
unsigned int hiveCrowdSimulation::CCrowdSimulation::getNumAgent() const
{
	_ASSERT(m_pRVOSimulator);

	return m_pRVOSimulator->getNumAgents();
}

//********************************************************************
//FUNCTION:
const glm::vec2& hiveCrowdSimulation::CCrowdSimulation::getAgentPosition(unsigned int vAgentIndex) const
{
	_ASSERT(m_pRVOSimulator);
	_ASSERT(vAgentIndex < getNumAgent());

	return m_pRVOSimulator->getAgentPosition(vAgentIndex);
}

//*******************************************************************
//FUNCTION:
void hiveCrowdSimulation::CCrowdSimulation::__findOtherWayOut()
{
	int Index = 0;
	for (auto& Agent : m_AgentSet)
	{
		//test
		std::cout << Index++ << std::endl;
		__findOtherWayOut4Agent(Agent);
	}

	for (auto& Group : m_GroupSet)
		__findOtherWayOut4Group(Group);
}

#ifdef _DEBUG
//*******************************************************************
//FUNCTION:
void hiveCrowdSimulation::CCrowdSimulation::advance4TestClashing()
{
	__updateGroupInfo();
	__updateVelocityInfluencedByTarget();	
	__updateVelocityInfluencedByGroup();
	m_pRVOSimulator->doStep();
}
#endif

#ifdef _DEBUG
//*******************************************************************
//FUNCTION:
void hiveCrowdSimulation::CCrowdSimulation::addGroup2GroupSet(CGroup* vGroup)
{
	m_GroupSet.push_back(vGroup);
}
#endif

//*******************************************************************
//FUNCTION:
void hiveCrowdSimulation::CCrowdSimulation::__findOtherWayOut4Agent(CAgent* vAgent)
{
	__checkAround(vAgent);

	if (!vAgent->isReachedGoal(vAgent->getGoal(), CCrowdSimulationConfig::getInstance()->getRadiusOfTempGoal()))
	{
		if (vAgent->hasFoundExit())
			return;

		if (vAgent->isAwareness())
		{				
			unsigned int ExitIndex = __chooseExitForOneAgent(vAgent);
			vAgent->setGoalPos(CPrepareScene::getInstance()->getExit(ExitIndex));
			__computeNavigationForKnewExit(vAgent);
		}
		else
		{
			const CQuadTreeNode<SNode>* pTempNode;
			std::vector<glm::vec2> VelocitySet;
			std::vector<glm::vec2> NavigationPointSet;
			glm::vec2 NavigationPoint;
			const CQuadTreeNode<SNode>* pNode = m_pScene->getLeafNodeBySceneCoord(vAgent->getPosition());

			float Angle = 0.0f;
			while ((Angle += 10.0f) < 360.0f)
			{
				glm::vec2 AgentVelocity = vAgent->getVelocity();
				if (AgentVelocity == glm::vec2(0.0, 0.0))
					AgentVelocity = glm::vec2(1.0, 0.0);
				glm::vec2 Velocity = rotateVector(AgentVelocity, Angle);
				glm::vec2 TempPosition = vAgent->getPosition() + Velocity * CCrowdSimulationConfig::getInstance()->getAdvanceTime();
				float Offset = CCrowdSimulationConfig::getInstance()->getAttribute<float>(OFFSET); 
				TempPosition = glm::vec2(std::max(Offset, std::min(TempPosition.x, m_pScene->getSceneWidth() - 1)), std::max(Offset, std::min(TempPosition.y, m_pScene->getSceneHeight() - 1)));
				//if (TempPosition.x < 1 || TempPosition.x > m_pScene->getSceneWidth() - 1 || TempPosition.y < 1 || TempPosition.y > m_pScene->getSceneHeight() - 1) continue;
				pTempNode = m_pScene->getLeafNodeBySceneCoord(TempPosition);
				if (pNode == pTempNode) continue;
				if (pTempNode->getExtraInfo().Passability == PASS)
				{
					VelocitySet.push_back(Velocity);
					NavigationPointSet.push_back(TempPosition);
				}
			}

			unsigned int Index = getIntRandom(0, VelocitySet.size()-1);
			vAgent->setVelocity(VelocitySet[Index]);
			NavigationPoint = NavigationPointSet[Index];

			std::vector<glm::vec2> RoadSet;
			m_pPathFinding->findShortestPathV(m_pGraphWithoutCrowd, m_pScene->getLeafNodeBySceneCoord(vAgent->getPosition())->getCenter(), m_pScene->getLeafNodeBySceneCoord(NavigationPoint)->getCenter(), RoadSet);
			RoadSet.push_back(NavigationPoint);
			vAgent->setTempGoal(RoadSet[RoadSet.size()-1]);
			vAgent->updateRoadmap(RoadSet);
		}	
	}
	else
	{
		vAgent->setIsReachGoal();
	}
}

//*******************************************************************
//FUNCTION:
void hiveCrowdSimulation::CCrowdSimulation::__findOtherWayOut4Group(CGroup* vGroup)
{
	for (unsigned int i=0; i<vGroup->getNumSubgroup(); ++i)
	{
		CSubgroup* pSubgroup = vGroup->fetchSubgroup(i);
		if (__checkAround(pSubgroup))
		{
			continue;
		}
		if (pSubgroup->getToDoState())
		{
			_ASSERT(pSubgroup->getNumSubgroupMembers() > 0);
			CAgent* pTempAgent = pSubgroup->fetchAgent(0);
			std::vector<glm::vec2> RoadSet;
			m_pPathFinding->findShortestPathV(m_pGraphWithoutCrowd, m_pScene->getLeafNodeBySceneCoord(pTempAgent->getPosition())->getCenter(), m_pScene->getLeafNodeBySceneCoord(pTempAgent->getTempGoal())->getCenter(), RoadSet);
			RoadSet.push_back(pTempAgent->getTempGoal());
			pTempAgent->updateRoadmap(RoadSet);
			continue;
		}

		if (pSubgroup->isAwareness())
		{
			CAgent* pTempAgent = pSubgroup->fetchAgent(0); 
			unsigned int ExitIndex = __chooseExitForOneAgent(pTempAgent);
			pTempAgent->setGoalPos(CPrepareScene::getInstance()->getExit(ExitIndex));
			std::vector<glm::vec2> Road;
			pSubgroup->updateCenter();
			glm::vec2 CenterPos = pSubgroup->getSubgroupCenter();
			glm::vec2 BestNext = m_pBestNextFinding->fetchBestNext(CenterPos, pTempAgent->getGoal(), m_pScene, m_pGraphWithCrowd, m_pGraphWithoutCrowd, CAgentConfig::getInstance()->getVisualRange(), Road);
			BestNext           = BestNext;

			Road.push_back(pTempAgent->getGoal());

			for (unsigned int k=0; k<pSubgroup->getNumSubgroupMembers(); ++k)
			{
				CAgent* pTempAgent = pSubgroup->fetchAgent(k);
				pTempAgent->setGoalPos(CPrepareScene::getInstance()->getExit(ExitIndex));
				pTempAgent->setTempGoal(BestNext);
				pTempAgent->updateRoadmap(Road);
			}
		}
		else
		{
			CAgent* pTempAgent = pSubgroup->fetchAgent(0);
			const CQuadTreeNode<SNode>* pTempNode;
			std::vector<glm::vec2> VelocitySet;
			std::vector<glm::vec2> NavigationPointSet;
			glm::vec2 NavigationPoint;
			const CQuadTreeNode<SNode>* pNode = m_pScene->getLeafNodeBySceneCoord(pTempAgent->getPosition());

			float Angle = 0.0f;
			while ((Angle += 10.0f) < 360.0f)
			{
				glm::vec2 Velocity = rotateVector(pTempAgent->getVelocity(), Angle);
				glm::vec2 TempPosition = pTempAgent->getPosition() + Velocity * CCrowdSimulationConfig::getInstance()->getAdvanceTime();
				float Offset = CCrowdSimulationConfig::getInstance()->getAttribute<float>(OFFSET); 
				TempPosition = glm::vec2(std::max(Offset, std::min(TempPosition.x, m_pScene->getSceneWidth() - 1)), std::max(Offset, std::min(TempPosition.y, m_pScene->getSceneHeight() - 1)));
				pTempNode = m_pScene->getLeafNodeBySceneCoord(TempPosition);
				if (pNode == pTempNode) continue;
				if (pTempNode->getExtraInfo().Passability == PASS)
				{
					VelocitySet.push_back(Velocity);
					NavigationPointSet.push_back(TempPosition);
				}
			}

			unsigned int Index = getIntRandom(0, VelocitySet.size()-1);

			pTempAgent->setVelocity(VelocitySet[Index]);
			NavigationPoint = NavigationPointSet[Index];

			std::vector<glm::vec2> RoadSet;
			m_pPathFinding->findShortestPathV(m_pGraphWithoutCrowd, m_pScene->getLeafNodeBySceneCoord(pTempAgent->getPosition())->getCenter(), m_pScene->getLeafNodeBySceneCoord(NavigationPoint)->getCenter(), RoadSet);
			RoadSet.push_back(NavigationPoint);
			pTempAgent->setTempGoal(RoadSet[RoadSet.size()-1]);
			pTempAgent->updateRoadmap(RoadSet);
			for (unsigned int k=0; k<pSubgroup->getNumSubgroupMembers(); ++k)
			{
				CAgent* pTempAgent = pSubgroup->fetchAgent(k);
				pTempAgent->setTempGoal(RoadSet[RoadSet.size()-1]);
				pTempAgent->updateRoadmap(RoadSet);
			}
		}		
	}
}

//*******************************************************************
//FUNCTION:
void hiveCrowdSimulation::CCrowdSimulation::__updateRoadMapForOneAgent(CAgent* vAgent, CKNNSearch* vKNNSearch)
{
	if (!vAgent->getIsReachGoal())
	{
		if (!__checkAround(vAgent))
		{
			if (vAgent->isReachedGoal(vAgent->getTempGoal(), CCrowdSimulationConfig::getInstance()->getRadiusOfTempGoal()))
			{	
				if (vAgent->isAwareness() || vAgent->hasFoundExit())
				{
					__computeNavigationForKnewExit(vAgent);
				}
				else                                                                     
					__computeNavigationForIgnorance(vAgent, vKNNSearch);
			}	
		}
	}
}

//*******************************************************************
//FUNCTION:
bool hiveCrowdSimulation::CCrowdSimulation::__checkAround(CAgent* vAgent)
{
	for (unsigned int k=0; k<CPrepareScene::getInstance()->getNumExit(); ++k)
	{
		if ((m_pScene->isVisible(vAgent->getPosition(), CPrepareScene::getInstance()->getExit(k), CAgentConfig::getInstance()->getVisualRange())) && !vAgent->hasFoundExit())
		{
			vAgent->setHasFoundExit(true);
			vAgent->setGoalPos(CPrepareScene::getInstance()->getExit(k));
			__computeNavigationForKnewExit(vAgent);

			std::vector<glm::vec2> TempRoadMap;
			vAgent->dumpRoadMap(TempRoadMap);
			TempRoadMap[TempRoadMap.size()-1] = CPrepareScene::getInstance()->getExit(k);
			vAgent->updateRoadmap(TempRoadMap);

			return true;
		}
		if (!m_pScene->isVisible(vAgent->getPosition(), CPrepareScene::getInstance()->getExit(k), CAgentConfig::getInstance()->getVisualRange()))
		{
			vAgent->setHasFoundExit(false);
		}
	}
	return false;
}

//*******************************************************************
//FUNCTION:
bool hiveCrowdSimulation::CCrowdSimulation::__checkAround(CSubgroup* vSubgroup)
{
	if (vSubgroup->fetchAgent(0)->hasFoundExit())
	{
		return true;
	}
	else
	{
		int Index = -1;
		bool Flag = false;
		std::vector<glm::vec2> Road;
		for (unsigned int i=0; i<vSubgroup->getNumSubgroupMembers() && !Flag; ++i)
		{
			CAgent* pAgent = vSubgroup->fetchAgent(i);
			for (unsigned int k=0; k<CPrepareScene::getInstance()->getNumExit(); ++k)
			{
				if (m_pScene->isVisible(pAgent->getPosition(), CPrepareScene::getInstance()->getExit(k), CAgentConfig::getInstance()->getVisualRange()))
				{
					pAgent->setHasFoundExit(true);
					pAgent->setGoalPos(CPrepareScene::getInstance()->getExit(k));

					m_pPathFinding->findShortestPathV(m_pGraphWithCrowd, m_pScene->getLeafNodeBySceneCoord(pAgent->getPosition())->getCenter(), m_pScene->getLeafNodeBySceneCoord(CPrepareScene::getInstance()->getExit(k))->getCenter(), Road);
					Road.push_back(pAgent->getGoal());
					pAgent->updateRoadmap(Road);
				}
				else
				{
					pAgent->setHasFoundExit(false);
				}
				if (pAgent->hasFoundExit())
				{
					Index = i;
					Flag = true;
					break;
				}
			}
		}
		if (Flag)
		{
			for (unsigned int i=0; i<vSubgroup->getNumSubgroupMembers(); ++i)
			{			
				CAgent* pAgent = vSubgroup->fetchAgent(i);
				pAgent->setHasFoundExit(true);
				pAgent->setGoalPos(vSubgroup->fetchAgent(Index)->getGoal());
				pAgent->updateRoadmap(Road);
			}
		}

		return Flag;
	}	
}

//*******************************************************************
//FUNCTION:
void hiveCrowdSimulation::CCrowdSimulation::__computeNavigationForKnewExit(CAgent* vAgent)
{
	std::vector<glm::vec2> Road;
	std::vector<glm::vec2> PathAfter;
	glm::vec2 BestNext = m_pBestNextFinding->fetchBestNext(vAgent->getPosition(), vAgent->getGoal(), m_pScene, m_pGraphWithoutCrowd, m_pGraphWithoutCrowd, CAgentConfig::getInstance()->getVisualRange(), Road);
	vAgent->setTempGoal(BestNext);
	vAgent->updateRoadmap(Road);
}

//********************************************************************
//FUNCTION:
void hiveCrowdSimulation::CCrowdSimulation::__computeNavigationForIgnorance(CAgent* vAgent, CKNNSearch* vKNNSearch)
{
	//test 
	/*if (vAgent->getIndex() == 5)
	{
	std::cout << "begin to find out other way" << std::endl;
	}*/
	glm::vec2 NavigationPoint = __doInfluenceSpaceForIgnorance(vAgent, vKNNSearch);

	std::vector<glm::vec2> RoadSet;

	m_pPathFinding->findShortestPathV(m_pGraphWithoutCrowd, m_pScene->getLeafNodeBySceneCoord(vAgent->getPosition())->getCenter(), m_pScene->getLeafNodeBySceneCoord(NavigationPoint)->getCenter(), RoadSet);

	RoadSet.push_back(NavigationPoint);
	vAgent->setTempGoal(NavigationPoint);
	vAgent->updateRoadmap(RoadSet);
}

//*******************************************************************
//FUNCTION:
unsigned int hiveCrowdSimulation::CCrowdSimulation::__chooseExitForOneAgent(CAgent* vAgent)
{
	std::vector<float> Distance2Exit;
	for (unsigned int k=0; k<CPrepareScene::getInstance()->getNumExit(); ++k)
	{
		if (vAgent->getGoal() == CPrepareScene::getInstance()->getExit(k))
		{
			Distance2Exit.push_back(hiveCrowdSimulation::LOWPOSSIBILITY / glm::distance(vAgent->getPosition(), CPrepareScene::getInstance()->getExit(k)));
		}else
		{
			Distance2Exit.push_back(hiveCrowdSimulation::HIGHPOSSIBILITY / glm::distance(vAgent->getPosition(), CPrepareScene::getInstance()->getExit(k)));
		}
	}
	return choseByRoulette(Distance2Exit);
}

//********************************************************************
//FUNCTION:
void hiveCrowdSimulation::CCrowdSimulation::__findNavigationCoordinate(CAgent* vAgent, glm::vec2& vNavigation, std::vector<glm::vec2>& voNavigationSet)
{	
	vNavigation = glm::vec2(std::max(CAgentConfig::getInstance()->getRadius(), std::min(vNavigation.x, m_pScene->getSceneWidth() - CAgentConfig::getInstance()->getRadius())), std::max(CAgentConfig::getInstance()->getRadius(), std::min(vNavigation.y, m_pScene->getSceneHeight() - CAgentConfig::getInstance()->getRadius())));
	std::vector<glm::vec2> RoadSet;

	glm::vec2 NavigationInArray = vNavigation;
	glm::vec2 PositionInArray   = vAgent->getPosition();
	m_pScene->computeGridCoordBetweenTwoGrids(NavigationInArray, PositionInArray, RoadSet);

	std::vector<const CQuadTreeNode<SNode>*> NodeSet;
	for (auto Road : RoadSet)
	{
		const CQuadTreeNode<SNode>* pNode = m_pScene->getBaseNode(Road.x, Road.y);
		m_pScene->getLeafNodeFromOnNode(pNode, NodeSet);
	}

	for (unsigned int i=0; i<NodeSet.size(); ++i)
	{
		if (NodeSet[i]->getExtraInfo().Passability == PASS)
		{
			voNavigationSet.push_back(NodeSet[i]->getCenter());
		}
	}
}

//********************************************************************
//FUNCTION:
void hiveCrowdSimulation::CCrowdSimulation::__findNavigationCoordinate(CAgent* vAgent, glm::vec2& voNavigation)
{
	voNavigation = glm::vec2(std::max(CAgentConfig::getInstance()->getRadius(), std::min(voNavigation.x, m_pScene->getSceneWidth() - CAgentConfig::getInstance()->getRadius())), std::max(CAgentConfig::getInstance()->getRadius(), std::min(voNavigation.y, m_pScene->getSceneHeight() - CAgentConfig::getInstance()->getRadius())));
	std::vector<glm::vec2> RoadSet;
	glm::vec2 NavigationInArray = voNavigation;
	glm::vec2 PositionInArray   = vAgent->getPosition();
	m_pScene->computeGridCoordBetweenTwoGrids(NavigationInArray, PositionInArray, RoadSet);

	if (PositionInArray == RoadSet[0])
	{		
		unsigned int k = 0;
		for (; k<RoadSet.size(); ++k)
		{
			if (m_pScene->getLeafNodeBySceneCoord(RoadSet[k])->getExtraInfo().Passability)
			{
				voNavigation = RoadSet[k];
			}

			else
			{
				break;
			}
		}
	}
	else
	{		
		int k=RoadSet.size()-1;
		for (; k>=0; --k)
		{
			if (m_pScene->getLeafNodeBySceneCoord(RoadSet[k])->getExtraInfo().Passability)
			{
				voNavigation = RoadSet[k];
			}
			else
			{
				break;
			}
		}
	}	
}

//*******************************************************************
//FUNCTION:
glm::vec2 hiveCrowdSimulation::CCrowdSimulation::__doInfluenceSpaceForIgnorance(CAgent* vAgent, CKNNSearch* vKNNSearch)
{
	std::vector<unsigned int> NeighborSet;
	vKNNSearch->executeKNN(vAgent->getPosition(), NeighborSet);

	std::vector<glm::vec2> PositionSet;
	std::vector<glm::vec2> VelocitySet;
	for (unsigned int k=1; k<NeighborSet.size(); ++k)
	{
		if (m_pScene->isVisible(m_pRVOSimulator->getAgent(NeighborSet[k])->getPosition(), vAgent->getPosition(), CAgentConfig::getInstance()->getVisualRange()))
		{
			PositionSet.push_back(m_pRVOSimulator->getAgent(NeighborSet[k])->getPosition());
			VelocitySet.push_back(m_pRVOSimulator->getAgent(NeighborSet[k])->getVelocity());
		}		
	}
	
	glm::vec2 Velocity = vAgent->computeIgnoranceVelocity(PositionSet, VelocitySet);
	glm::vec2 Position = vAgent->getPosition() + Velocity * CCrowdSimulationConfig::getInstance()->getAdvanceTime();
	Position = glm::vec2(std::max(4.0f, std::min(Position.x, m_pScene->getSceneWidth() - 1)), std::max(4.0f, std::min(Position.y, m_pScene->getSceneHeight() - 1)));
	return Position;
}

//*******************************************************************
//FUNCTION:
unsigned int hiveCrowdSimulation::CCrowdSimulation::addNoGroupMemberAgent(CAgent* vAgent)
{
	m_AgentSet.push_back(vAgent); 
	return m_pRVOSimulator->addAgent(vAgent->getInitPosition());
}

//********************************************************************
//FUNCTION:
void hiveCrowdSimulation::CCrowdSimulation::setGraph(CGraphWithoutCrowd* vGraph, CGraphWithCrowd* vGraphWithCrowd)
{
	_ASSERT(vGraph && vGraphWithCrowd);

	m_pGraphWithoutCrowd = vGraph;
	m_pGraphWithCrowd    = vGraphWithCrowd;
}

//********************************************************************
//FUNCTION:
void hiveCrowdSimulation::CCrowdSimulation::advance()
{
	__updateGroupInfo();
	__execFindingPathProcess();		
	__updateVelocityInfluencedByTarget();	
	__updateVelocityInfluencedByGroup();
	m_pRVOSimulator->doStep();
	m_NumElapsedFrame++;
	if (m_NumElapsedFrame % 5 == 0)
		updateScene();
}

//********************************************************************
//FUNCTION:
void hiveCrowdSimulation::CCrowdSimulation::__execFindingPathProcess()
{
	if (m_NumElapsedFrame % CCrowdSimulationConfig::getInstance()->getProceedingTime() == 0)
		__findOtherWayOut();
	else
		__updateRoadMap(); 
}

//********************************************************************
//FUNCTION:
void hiveCrowdSimulation::CCrowdSimulation::__updateGroupInfo()
{
	for (auto& Group : m_GroupSet)
		Group->updateStatus();
}

//********************************************************************
//FUNCTION:
CGroup* hiveCrowdSimulation::CCrowdSimulation::getGroup(unsigned int vGroupIndex) const
{
	_ASSERT(vGroupIndex < m_GroupSet.size());

	return m_GroupSet[vGroupIndex];
}

//********************************************************************
//FUNCTION:
CAgent* hiveCrowdSimulation::CCrowdSimulation::getNoGroupMembers(unsigned int vIndex) const
{
	_ASSERT(vIndex < m_AgentSet.size());

	return m_AgentSet[vIndex];
}

//********************************************************************
//FUNCTION:
void hiveCrowdSimulation::CCrowdSimulation::__setIgnorance4Crowd(unsigned int vNumIgnorentAgent)
{
	std::vector<CAgent*> CrowdSet = m_AgentSet;
	for (unsigned int i=0; i<getNumGroups(); i++)
	{
		CGroup* pGroup = getGroup(i);
		__dumpGroupMember2CrowdSet(pGroup, CrowdSet);
	}

	std::map<int, int> EffectiveCrowdSetIndexMap;
	for (unsigned int i=0; i<CrowdSet.size(); ++i)
	{
		EffectiveCrowdSetIndexMap.insert(std::pair<int, int>(i, i));
	}

	for (unsigned int i=0; i<vNumIgnorentAgent; ++i)
	{
		int Index = getIntRandom(0, EffectiveCrowdSetIndexMap.size()-1);
		_ASSERT(EffectiveCrowdSetIndexMap.count(Index) > 0);
		int AgentIndex = EffectiveCrowdSetIndexMap[Index];
		EffectiveCrowdSetIndexMap.erase(Index);

		std::map<int, int> NewEffectiveCrowdSetIndexMap;
		for (auto& Iter = EffectiveCrowdSetIndexMap.begin(); Iter != EffectiveCrowdSetIndexMap.end(); ++Iter)
		{
			NewEffectiveCrowdSetIndexMap.insert(std::pair<int, int>(NewEffectiveCrowdSetIndexMap.size(), (*Iter).second));
		}

		EffectiveCrowdSetIndexMap.clear();
		EffectiveCrowdSetIndexMap = NewEffectiveCrowdSetIndexMap;

		CAgent* pAgent = CrowdSet[AgentIndex];
		pAgent->setAwareness(false);
	}
}

//********************************************************************
//FUNCTION:
void hiveCrowdSimulation::CCrowdSimulation::__dumpGroupMember2CrowdSet(CGroup* vGroup, std::vector<CAgent*>& voCrowdSet)
{
	_ASSERT(vGroup);

	for (unsigned int i=0; i<vGroup->getNumSubgroup(); i++)
	{
		CSubgroup* pSubgroup = vGroup->fetchSubgroup(i);
		for (unsigned int k=0; k<pSubgroup->getNumSubgroupMembers(); k++)
		{
			CAgent* pAgent = pSubgroup->fetchAgent(k);
			_ASSERT(pAgent);
			voCrowdSet.push_back(pAgent);
		}
	}
}

#ifdef _DEBUG
//********************************************************************
//FUNCTION:
void hiveCrowdSimulation::CCrowdSimulation::dumpGroup4TestingSearchTask(CAgent* vAgentSrc, CAgent* vAgentDst, CGroup* voGroup)
{
	_ASSERT(vAgentDst);
	_ASSERT(vAgentSrc);
	_ASSERT(voGroup);

	unsigned int Index = m_pRVOSimulator->addAgent(vAgentSrc->getInitPosition());
	glm::vec2 GridId = m_pScene->getLeafNodeBySceneCoord(vAgentSrc->getInitPosition())->getCenter();
	initAgentAdditionalInfo(m_pRVOSimulator, Index, GridId, vAgentSrc);

	Index = m_pRVOSimulator->addAgent(vAgentDst->getInitPosition());
	GridId = m_pScene->getLeafNodeBySceneCoord(vAgentDst->getInitPosition())->getCenter();
	initAgentAdditionalInfo(m_pRVOSimulator, Index, GridId, vAgentDst);

	CSubgroup* pSubgroupSrc = new CSubgroup();
	pSubgroupSrc->addAgent(vAgentSrc);
	voGroup->addSubgroup2ExecTaskSet(pSubgroupSrc);

	CSubgroup* pSubgroupDst = new CSubgroup();
	pSubgroupDst->addAgent(vAgentDst);
	voGroup->addNormalSubgroup(pSubgroupSrc);
	voGroup->addNormalSubgroup(pSubgroupDst);
}
#endif