#pragma once
#include "SimulationExport.h"

class CGraph;
class CSceneNode;

class CROWD_SIMULATION_DLL_EXPORT CFindPath
{
public:
	CFindPath() {}
	virtual ~CFindPath() {}

	virtual bool findShortestPathV(const CGraph &vGraph, const CSceneNode &vStart, const CSceneNode &vEnd) = 0;
};
