#pragma once
#include "BaseGraph.h"

namespace hiveCrowdSimulation
{
	class CGraphWithoutCrowd : public CBaseGraph
	{
	public:
		CGraphWithoutCrowd();
		virtual ~CGraphWithoutCrowd();

	protected:
		virtual double _computeEdgeWeightV(const glm::vec2& vBegin, const glm::vec2& vEnd) const override;
	};
}