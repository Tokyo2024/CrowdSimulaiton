#pragma once
#include <vector>
#include <string>
#include <GLM/glm.hpp>
#include "FreeImage.h"
#include "common/HiveConfig.h"
#include "common/Singleton.h"

namespace hiveCrowdSimulation
{
	class CPrepareScene : public hiveCommon::CSingleton<CPrepareScene>
	{
	public:
		virtual ~CPrepareScene();

		void parseSceneImage(const std::string& vBitmapFile);
		int getSceneWidth() const {return m_Width;}
		int getSceneHeight() const {return m_Height;}
		char* getImageData() const {return m_pImageData;}
		glm::vec2 getExit(unsigned int vIndex) const;
		unsigned int getNumExit() const {return m_ExitSet.size();}
		
	protected:
		CPrepareScene();

	private:
		void __computeSampleSet(const glm::vec2& vCurPos, int vSampleRadius, int vSampleAngle, std::vector<glm::vec2>& voSamplePointSet);
		void __recognizeExit();
		bool __isEffectivePos(const glm::vec2& vPos);
		bool __isNecessary2ComputingSampleSet(const glm::vec2& vTargetPoint);

		RGBQUAD __readPixelColor(const glm::vec2& vPixelPos);
		glm::vec3 __transformColorFormat(const RGBQUAD& vColor);
		std::string __changeToUniformPicture(const std::string& vFileName);
		int __increatToUniformSize(int vRealSize);

		std::vector<glm::vec2> m_ExitSet;
		int m_Width;
		int m_Height;
		FIBITMAP* m_pImage;
		char* m_pImageData;

		friend class hiveCommon::CSingleton<CPrepareScene>;
	};
}