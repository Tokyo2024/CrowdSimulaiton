#include "SceneGrid.h"
#include <math.h>
#include "AgentConfig.h"

using namespace hiveCrowdSimulation;

hiveCrowdSimulation::CSceneGrid::CSceneGrid(const glm::vec2& vCoordinate, float vArea) : m_IsUpdate(true), m_Area(vArea), m_AvgSpeed(0.0), m_AvgDirection(glm::vec2(0.0, 0.0)), m_Coordinate(vCoordinate)
{
}

CSceneGrid::~CSceneGrid()
{
}

//*******************************************************************
//FUNCTION:
void CSceneGrid::addAgent(CAgent* vAgent)
{
	m_Crowd.push_back(vAgent);
	m_IsUpdate = true;
}

//*******************************************************************
//FUNCTION:
void CSceneGrid::deleteAgent(const CAgent* vAgent)
{
	//_ASSERT(m_Crowd.size() > 0);
	if (m_Crowd.size() == 0)
		return;

	bool CanDelete = false;
	for (unsigned int i=0; i<m_Crowd.size(); i++)
	{
		if (m_Crowd[i] == vAgent)
		{
			CanDelete = true;
			m_Crowd.erase(m_Crowd.begin() + i);
			m_IsUpdate = true;
			break;
		}
	}
	m_IsUpdate = true;
	_ASSERT(CanDelete == true);
}

//*******************************************************************
//FUNCTION:
float CSceneGrid::getAvgSpeed()
{
	if (m_IsUpdate) __updateInformationOfVelocity();
	return m_AvgSpeed;
}

//*******************************************************************
//FUNCTION:
const glm::vec2& CSceneGrid::getAvgMoveDirection()
{
	if (m_IsUpdate) __updateInformationOfVelocity();
	return m_AvgDirection;
}

//*******************************************************************
//FUNCTION:
void hiveCrowdSimulation::CSceneGrid::__updateInformationOfVelocity()
{
	m_AvgDirection = glm::vec2(0, 0);
	m_AvgSpeed     = 0.0;
	for (auto& Agent : m_Crowd)
	{
		m_AvgSpeed += Agent->getMaxSpeed();
		m_AvgDirection += Agent->getVelocity();
	}

	if (m_Crowd.size() > 0)
	{
		m_AvgSpeed /= m_Crowd.size();
		m_AvgDirection /= m_Crowd.size();
	}
	m_IsUpdate = false;
}

//*******************************************************************
//FUNCTION:
float hiveCrowdSimulation::CSceneGrid::getCrowdDensity() const
{
	return (m_Crowd.size() * 3.14 * CAgentConfig::getInstance()->getRadius()) / m_Area;
}

//********************************************************************
//FUNCTION:
void hiveCrowdSimulation::CSceneGrid::deleteCrowd()
{
	m_Crowd.clear();
	m_IsUpdate = true;
}