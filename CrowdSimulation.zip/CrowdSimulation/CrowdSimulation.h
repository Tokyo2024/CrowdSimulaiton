#pragma once
#include <vector>
#include <functional>
#include <GLM/glm.hpp>
#include "RVOSimulator.h"
#include "KNNSearch.h"

namespace hiveCrowdSimulation
{
	class CPathFinding;
	class CSubgroup;
	class CGroup;
	class CAgent;
	class CScene;
	class CKNNSearch;
	class CGraphWithoutCrowd;
	class CGraphWithCrowd;
	class CBaseGraph;
	class CPrepareScene;
	class CAgentConfig;
	class CCrowdSimulationConfig;
	class CBestNextFinding;
	class CSceneGrid;

	typedef std::function<void(const CSubgroup*, const CAgent*, glm::vec2&)> GroupForce;

	class CCrowdSimulation
	{
	public:
		CCrowdSimulation();
		~CCrowdSimulation();

		void setNumElapsedFrame(int vNumFrame) {m_NumElapsedFrame = vNumFrame;}
		void setPathFinding(CPathFinding* vPathFinding) {m_pPathFinding = vPathFinding;}
		void setGroupForce(GroupForce vGroupforce) {m_GroupForce = vGroupforce;}
		void setGraph(CGraphWithoutCrowd* vGraph, CGraphWithCrowd* vGraphWithCrowd);
		void setScene(CScene* vScene);
		void updateScene();

		void initAgentWithSpecifiedInfo(const glm::vec2& vPos, bool vIsAwareness, int vGroupID);
		void initCrowdDistribution(unsigned int vNumTotalAgent, unsigned int vNumIgnorantAgent, unsigned int vNumNotGroupMembers, unsigned int NumGroups, unsigned int voMinNumGroupMembers, unsigned int voMaxNumGroupMembers);
		void addCrowdDistributionAtSpecificArea(const glm::vec2& vCenter, int vRadius, unsigned int vNumNotGroupMembers, bool vIsAware);
		void initAgentAdditionalInfo(RVO::RVOSimulator* vRVOSimulator, unsigned int vIndex, const glm::vec2& vGridID, CAgent* vioAgent);
		void initSimulator();
		void advance();
		void addObstacleToRVO();
		bool isFinished();
		
		unsigned int addNoGroupMemberAgent(CAgent* vAgent);
		unsigned int getNumNoGroupMembers() const {return m_AgentSet.size();}
		unsigned int getNumGroups() const {return m_GroupSet.size();}
		unsigned int getNumAgent() const;

		CAgent* getNoGroupMembers(unsigned int vIndex) const;
		CGroup* getGroup(unsigned int vGroupIndex) const;
		RVO::RVOSimulator* getRVOSimulator() const {return m_pRVOSimulator;}
		const glm::vec2& getAgentPosition(unsigned int vAgentIndex) const;

		//********************************************************************
		//#ifdef _DEBUG
		void advance4TestGivingUp(bool& vIsGivingUp);
		void advance4TestClashing();
		void addGroup2GroupSet(CGroup* vGroup);
		void dumpGroup4TestingSearchTask(CAgent* vAgentSrc, CAgent* vAgentDst, CGroup* voGroup);
        // #endif

	private:
		void __findOtherWayOut4Agent(CAgent* vAgent);
		void __findOtherWayOut4Group(CGroup* vGroup);
		void __updateRoadMapForOneAgent(CAgent* vAgent, CKNNSearch* vKNNSearch);
		void __findOtherWayOut();
		void __updateRoadMap(); 

		bool __checkAround(CAgent* vAgent);  
		bool __checkAround(CSubgroup* vSubgroup);
		void __computeNavigationForKnewExit(CAgent* vAgent);
		void __computeNavigationForIgnorance(CAgent* vAgent, CKNNSearch* vKNNSearch);
		void __findNavigationCoordinate(CAgent* vAgent, glm::vec2& vNavigation);
		void __findNavigationCoordinate(CAgent* vAgent, glm::vec2& vNavigation, std::vector<glm::vec2>& voNavigationSet);
		
		void __dumpGroupInfo(int vNumOfAllGroupMembers, int vNumGroup, int voMinNumGroupMembers, int voMaxNumGroupMembers);
		void __initGroupDistribution(unsigned int vNumOfAllGroupMembers, unsigned int vNumGroup, unsigned int voMinNumGroupMembers, unsigned int voMaxNumGroupMembers);
		void __initNotGroupMemberDistribution(unsigned int vNumNotGroupMembers);
		void __initNotGroupMumberDistributionAtSpecificArea(const glm::vec2& vCenter, int vRadius, unsigned int vNumNotGroupMembers);
		void __setIgnorance4Crowd(unsigned int vNumIgnorentAgent);
		void __dumpGroupMember2CrowdSet(CGroup* vGroup, std::vector<CAgent*>& voCrowdSet);
		CAgent* __genRandomAgent(CSceneGrid*& voGrid);
		CAgent* __genRandomAgentAtSpecificArea(const glm::vec2& vCenter, int vRadius, CSceneGrid*& voGrid);
		void __genRectBySpecificPos(const glm::vec2& vCenter, int vRadius, glm::vec2& voMinPoint, glm::vec2& voMaxPoint);

		void __execFindingPathProcess();
		void __updateGroupInfo();
		void __initGroupMembers(unsigned int vGroupIndex);
		void __updateVelocityInfluencedByTarget();
		void __updateVelocityInfluencedByGroup();
		glm::vec2 __doInfluenceSpaceForIgnorance(CAgent* vAgent, CKNNSearch* vKNNSearch);
		glm::vec2 __computeVelocityInfluencedByTarget(const glm::vec2& vPos, std::vector<glm::vec2>& vioRoadMap);
		unsigned int __chooseExitForOneAgent(CAgent *vAgent);

	private:
		CKNNSearch*            m_pKnnSearch;
		CScene*                m_pScene;
		CPathFinding*          m_pPathFinding;
		CBestNextFinding*      m_pBestNextFinding;
		RVO::RVOSimulator*     m_pRVOSimulator;
		CGraphWithoutCrowd*    m_pGraphWithoutCrowd;
		CGraphWithCrowd*       m_pGraphWithCrowd;
		std::vector<glm::vec2> m_NavigationPointSet;
		std::vector<CAgent*>   m_AgentSet;
		std::vector<CGroup*>   m_GroupSet;
		GroupForce             m_GroupForce;
		int                    m_NumElapsedFrame;
		int                    m_NeighborNum;
	};
}