#include "RoadMap.h"
#include "Scene.h"

using namespace hiveCrowdSimulation;

CRoadMap::CRoadMap()
{
}

CRoadMap::~CRoadMap()
{
}

//*******************************************************************
//FUNCTION:
void CRoadMap::createRoadMap(const std::vector<glm::vec2>& vNavigationSet)
{
	__initRoadMapSet(vNavigationSet);
}

//*******************************************************************
//FUNCTION:
int CRoadMap::getRoadMapIndex(const glm::vec2& vPos) const
{
	for (unsigned int i=0; i<m_RoadMapSet.size(); i++)
	{
		if (vPos == m_RoadMapSet[i].Position) return i;
	}

	return -1;
}

//*******************************************************************
//FUNCTION:
void CRoadMap::__initRoadMapSet(const std::vector<glm::vec2>& vNavigationSet)
{
	SRouteMapVertex TempVertex;
	for (unsigned int i=0; i<vNavigationSet.size(); i++)
	{
		TempVertex.Position = vNavigationSet[i];
		m_RoadMapSet.push_back(TempVertex);
	}

// #ifdef _OPENMP
// #pragma omp parallel for
// #endif		
// 		for (unsigned int i=0; i<m_RoadMapSet.size(); ++i)
// 		{
// 			for (unsigned int k=0; k<m_RoadMapSet.size(); ++k)
// 			{
// 				if (m_pScene->isVisible(m_pScene->sceneCoord2ArrayCoord(m_RoadMapSet[i].Position), m_pScene->sceneCoord2ArrayCoord(m_RoadMapSet[k].Position), 5))
// 				{
// 					m_RoadMapSet[i].Neighbors.push_back(k);
// 				}
// 			}
// 
// 			m_RoadMapSet[i].DistToGoal.resize(m_RoadMapSet.size(), FLT_MAX);
// 		}

// #ifdef _OPENMP
// #pragma omp parallel for
// #endif
// 		/* Compute the distance to each of others for all vertices using Dijkstra's algorithm.*/
// 		for (unsigned int i=0; i<m_RoadMapSet.size(); ++i)
// 		{
// 			std::multimap<float, int> Q;
// 			std::vector<std::multimap<float, int>::iterator> PosInQ(m_RoadMapSet.size(), Q.end());
// 
// 			m_RoadMapSet[i].DistToGoal[i] = 0.0f;
// 			PosInQ[i] = Q.insert(std::make_pair(0.0f, i));
// 
// 			while (!Q.empty())
// 			{
// 				const int U = Q.begin()->second;
// 				Q.erase(Q.begin());
// 				PosInQ[U] = Q.end();
// 
// 				for (unsigned int k=0; k<m_RoadMapSet[U].Neighbors.size(); ++k)
// 				{
// 					unsigned int V = m_RoadMapSet[U].Neighbors[k];
// 					float Dist_UV = RVO::abs(m_RoadMapSet[V].Position - m_RoadMapSet[U].Position);
// 
// 					if (m_RoadMapSet[V].DistToGoal[i] > m_RoadMapSet[U].DistToGoal[i] + Dist_UV)
// 					{
// 						m_RoadMapSet[V].DistToGoal[i] = m_RoadMapSet[U].DistToGoal[i] + Dist_UV;
// 
// 						if (PosInQ[V] == Q.end())
// 						{
// 							PosInQ[V] = Q.insert(std::make_pair(m_RoadMapSet[V].DistToGoal[i], V));
// 						}
// 						else
// 						{
// 							Q.erase(PosInQ[V]);
// 							PosInQ[V] = Q.insert(std::make_pair(m_RoadMapSet[V].DistToGoal[i], V));
// 						}
// 					}
// 				}
// 			}
// 		}
}