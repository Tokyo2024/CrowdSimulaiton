#include "Subgroup.h"
#include <unordered_map>
#include "SimulationTools.h"
#include "IAgent.h"
#include "CrowdSimulationConfig.h"

using namespace hiveCrowdSimulation;

CSubgroup::CSubgroup() : m_DoTask(false), m_Necessary2MakeDecision(false), m_Task(NULL), m_IsAwareness(false)
{

}

CSubgroup::~CSubgroup()
{
	for (unsigned int i=0; i<m_TargetCandidates.size(); i++)
		delete m_TargetCandidates[i].second;
	
	if (m_Task)
		delete m_Task;
}

//*******************************************************************
//FUNCTION:
void CSubgroup::updateAwareness()
{
	for (auto Agent : m_AgentSet)
	{
		if (Agent->isAwareness())
		{
			m_IsAwareness = true;
			return ;
		}
	}
	m_IsAwareness = false;
}

//*******************************************************************
//FUNCTION:
void CSubgroup::addAgent(CAgent* vAgent)
{
	_ASSERT(vAgent);
	m_AgentSet.push_back(vAgent);
}

//*******************************************************************
//FUNCTION:
CAgent* CSubgroup::fetchAgent(unsigned int vIndex) const
{
	_ASSERT(vIndex < m_AgentSet.size());
	return m_AgentSet[vIndex];
}

//*******************************************************************
//FUNCTION:
void CSubgroup::exchangeInfo()
{
	for (unsigned int i=0; i<m_AgentSet.size()-1; ++i)
		for (unsigned int k=i+1; k<m_AgentSet.size(); ++k)
			m_AgentSet[i]->exchangeInfo(m_AgentSet[k]);
}

//*******************************************************************
//FUNCTION:
void CSubgroup::updateCenter()
{
	glm::vec2 Position;
	for (unsigned int i=0; i<m_AgentSet.size(); i++)
		Position += m_AgentSet[i]->getPosition();

	m_SubgroupCenter = Position/(float)m_AgentSet.size();
}

//*******************************************************************
//FUNCTION:
void CSubgroup::setToDoTask(STaskInfo* vTask)
{
	m_DoTask                          = true;
	m_Task                            = vTask;
	const CAgent* pTargetAgent        = m_Task->pTargetAgent;
	m_AgentSet[0]->setToDoTask(pTargetAgent);
}

//*******************************************************************
//FUNCTION:
void CSubgroup::finishTask()
{
	m_DoTask = false;
	delete m_Task;
	m_Task = NULL;
	m_AgentSet[0]->setToFinishTask();
}

//*******************************************************************
//FUNCTION:
bool CSubgroup::isAgentInThisSubgroup(const CAgent* vAgent) const
{
	return std::find(m_AgentSet.begin(), m_AgentSet.end(), vAgent) != m_AgentSet.end();
}

//*******************************************************************
//FUNCTION:
CSubgroup* CSubgroup::generateTask()
{
	m_TargetCandidates.clear();

	if (m_AgentSet.size() == 1)
		return NULL;

	for (unsigned int i=0; i<m_AgentSet.size(); ++i)
	{
		SCost2FindSomeone* pTargetCandidate = new SCost2FindSomeone();
		
		if (m_AgentSet[i]->generateTargetCandidate(pTargetCandidate, this))
			m_TargetCandidates.push_back(std::make_pair(m_AgentSet[i], pTargetCandidate));
	}

	if (m_TargetCandidates.size() == 0)
		return NULL;

	std::pair<CAgent*, SCost2FindSomeone*> AgentInfo2Find = __chooseCandidate();
	CAgent* pExecTaskAgent        = AgentInfo2Find.first;
	SCost2FindSomeone* pCost2Find = AgentInfo2Find.second;
	
	CSubgroup* pNewSubgroup = new CSubgroup(); 
	pNewSubgroup->addAgent(pExecTaskAgent);  

	STaskInfo* pTask = new STaskInfo(pCost2Find->pTargetAgent, 0, pCost2Find->Attention);
	pNewSubgroup->setToDoTask(pTask);

	m_AgentSet.erase(remove(m_AgentSet.begin(), m_AgentSet.end(), AgentInfo2Find.first), m_AgentSet.end()); //change subgroup members of this subgroup

	return pNewSubgroup;  
}

//*******************************************************************
//FUNCTION:
void CSubgroup::splitSubgroup(std::vector<CSubgroup*>& voSplitSubGroupSet)
{
	voSplitSubGroupSet.clear();

	std::vector<int> DisjointSet(m_AgentSet.size(), -1);

	for (int i=0; i<m_AgentSet.size(); ++i)
	{ 
		glm::vec2 TestPos = m_AgentSet[i]->getPosition();

		if (DisjointSet[i] == -1) DisjointSet[i] = i;

		for (int k=i+1; k<m_AgentSet.size(); ++k)
		{
			if (m_AgentSet[k]->isAgentDirectInSight(m_AgentSet[i]))
			{
				if (DisjointSet[k] == -1) DisjointSet[k] = i;
				else
				{
					int RootA = k;
					while (DisjointSet[RootA] != RootA) RootA = DisjointSet[RootA];

					int RootB = i;
					while (DisjointSet[RootB] != RootB) RootB = DisjointSet[RootB];

					if (RootA != RootB) DisjointSet[RootA] = RootB;

					DisjointSet[k] = RootB;
				}
			}
		}
	}

	std::unordered_map<int, int> IndexMap;
	for (int i=0; i<DisjointSet.size(); ++i)
	{
		int k = i;
		while (DisjointSet[k] != k) k = DisjointSet[k];
		DisjointSet[i] = k;
		if (IndexMap.find(k) == IndexMap.end())
		{
			IndexMap.insert(std::make_pair(k,0));
			IndexMap[k] = IndexMap.size()-1;
		}
	}

	voSplitSubGroupSet.resize(IndexMap.size(), NULL);
	if (IndexMap.size() == 1)
	{
		this->setNecessity2MakeDecision(false);
		voSplitSubGroupSet[0] = this;
		return;
	}

	for (int i=0; i<m_AgentSet.size(); ++i)
	{
		int Index = IndexMap[DisjointSet[i]];

		if (!voSplitSubGroupSet[Index]) voSplitSubGroupSet[Index] = new CSubgroup;

		voSplitSubGroupSet[Index]->addAgent(m_AgentSet[i]);
	}

	__judgeIfNecessary2MakeDecision(voSplitSubGroupSet);
}

//*******************************************************************
//FUNCTION:
bool CSubgroup::isAble2MergeThisSubgroupAndSetTaskFinishedIfNecessiry(CSubgroup* vSubGroup)
{
	bool IsVisible = false;
	for (unsigned int i=0; i<m_AgentSet.size(); ++i)
	{
		for (unsigned int k=0; k<vSubGroup->getNumSubgroupMembers(); ++k)
		{
			if (m_AgentSet[i]->isAgentDirectInSight(vSubGroup->fetchAgent(k)))
				IsVisible = true;
		}
	}

	if (!IsVisible)
		return false;
	
	bool IsOnTask = vSubGroup->getToDoState();

	if (IsVisible && !IsOnTask && !m_DoTask)
		return true;

	if (IsOnTask && this->isAgentInThisSubgroup(vSubGroup->getTargetAgent()))
	{
		vSubGroup->finishTask();
		return true;
	}
	if (m_DoTask && vSubGroup->isAgentInThisSubgroup(this->getTargetAgent()))
	{
		finishTask();
		return true;
	}

	return false;
}

//*******************************************************************
//FUNCTION:
void CSubgroup::updateFinishState(bool& voFlag)
{
	for (auto& Agent : m_AgentSet)
		Agent->updateFinishState(voFlag);
}

//*******************************************************************
//FUNCTION:
bool CSubgroup::reachTempGoal()
{
	for (auto& Agent : m_AgentSet)
	{
		if (!Agent->isReachedGoal(Agent->getTempGoal(), CCrowdSimulationConfig::getInstance()->getRadiusOfTempGoal()))
			return false;
	}
	return true;
}

//*******************************************************************
//FUNCTION:
const CAgent* CSubgroup::getTargetAgent() const
{
	_ASSERT(m_Task);
	return m_Task->pTargetAgent;
}

//*******************************************************************
//FUNCTION:
float CSubgroup::getAttention()
{
	_ASSERT(m_Task);
	return m_Task->Attention;
}

//*******************************************************************
//FUNCTION:
int CSubgroup::getTimeElapsed()
{
	_ASSERT(m_Task);
	return m_Task->TimeElapsed;
}

//*******************************************************************
//FUNCTION:
void CSubgroup::updateTimeElapsed()
{
	m_Task->TimeElapsed++;
}

//*******************************************************************
//FUNCTION:
void CSubgroup::setAttention(float vAttention)
{
	m_Task->Attention = vAttention;
}

//*******************************************************************
//FUNCTION:
void CSubgroup::__judgeIfNecessary2MakeDecision(std::vector<CSubgroup*>& voSplitSubgroupSet)
{
	if (voSplitSubgroupSet.size() == 1) voSplitSubgroupSet[0]->setNecessity2MakeDecision(false);

	std::vector<glm::vec2> CenterSet;
	for (auto Subgroup : voSplitSubgroupSet)
	{
		Subgroup->updateCenter();
		CenterSet.push_back(Subgroup->getSubgroupCenter());
	}

	std::vector<float> Distance2Goal;
	for (auto Center : CenterSet)
		Distance2Goal.push_back(glm::distance(Center, m_AgentSet[0]->getGoal()));

	float MaxDistance = Distance2Goal[0];
	int MaxIndex = 0;
	for (int i=0; i<Distance2Goal.size(); ++i)
	{
		if (MaxDistance < Distance2Goal[i])
		{
			MaxDistance = Distance2Goal[i];
			MaxIndex = i;
		}
		voSplitSubgroupSet[i]->setNecessity2MakeDecision(true);
	}
	voSplitSubgroupSet[MaxIndex]->setNecessity2MakeDecision(false);
}

//********************************************************************
//FUNCTION:
std::pair<CAgent*, SCost2FindSomeone*> CSubgroup::__chooseCandidate()
{
	int MaxAttention = FLT_MIN;
	int Index = 0;
	for (int i=0; i<m_TargetCandidates.size(); ++i)
	{
		if (m_TargetCandidates[i].second->Attention > MaxAttention)
		{
			Index = i;
			MaxAttention = m_TargetCandidates[i].second->Attention;
		}
	}
	return m_TargetCandidates[Index];
}

//********************************************************************
//FUNCTION:
glm::vec2 CSubgroup::getSubgroupCenter() const
{
	return m_SubgroupCenter;
}

#ifdef _DEBUG
//*******************************************************************
//FUNCTION:
void CSubgroup::setDefaultIntimacy()
{
	for (size_t i=0; i<m_AgentSet.size(); ++i)
	{
		for (size_t k=0; k<m_AgentSet.size(); ++k)
		{
			if (i != k)
			{
				SAgentRelationship* pRelationship = new SAgentRelationship();
				pRelationship->Intimacy = 0.01f;
				m_AgentSet[i]->addAgent2Relationship(m_AgentSet[k], pRelationship);
			}
		}
	}
}
#endif