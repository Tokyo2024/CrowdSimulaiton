#pragma once
#include <vector>
#include <string>
#include <glm.hpp>
#include "FreeImage.h"
#include "common/HiveConfig.h"
#include "common/Singleton.h"

namespace hiveCrowdSimulation
{
	class CSceneConfig : public hiveCommon::CSingleton<CSceneConfig>
	{
	public:
		virtual ~CSceneConfig();

		glm::vec2 getExit(unsigned int vIndex) const;
		unsigned int getNumExit() const {return m_ExitSet.size();}
		char* getImageData() const {return m_pImageData;}
		int getSceneWidth() const {return m_Width;}
		int getSceneHeight() const {return m_Height;}

		//Sprint_7
		void parseSceneImage(const std::string& vBitmapFile);

	protected:
		CSceneConfig();

	private:
		void __computeSampleSet(const glm::vec2& vCurPos, int vSampleRadius, int vSampleAngle, std::vector<glm::vec2>& voSamplePointSet);
		void __recognizeExit();
		bool __isEffectivePos(const glm::vec2& vPos);
		bool __isNecessary2ComputingSampleSet(const glm::vec2& vTargetPoint);
		RGBQUAD __readPixelColor(const glm::vec2& vPixelPos);
		glm::vec3 __transformColorFormat(const RGBQUAD& vColor);

	private:
		std::vector<glm::vec2> m_ExitSet;
		int m_Width;
		int m_Height;
		FIBITMAP* m_pImage;
		char* m_pImageData;

		friend class hiveCommon::CSingleton<CSceneConfig>;
	};
}