#pragma once
#include <string>
#include <vector>
#include <GLM/glm.hpp>
#include "common/HiveConfig.h"
#include "common/Singleton.h"

namespace hiveCrowdSimulation
{
	const std::string RADIUS         = "Radius";
	//const std::string RADIUSOFFSET   = "RadiusOffset";
	const std::string MAXSPEED       = "MaxSpeed";
	const std::string MAXNEIGHBORS   = "MaxNeighbors";
	const std::string NEIGHBORDIST   = "NeighborDist";
	const std::string TIMEHORIZON    = "TimeHorizon";
	const std::string TIMEHORIZONOBST = "TimeHorizonObst";
	const std::string AGENTINFO      = "AgentsInfo";
	const std::string AGENT          = "Agent";
	const std::string VISUABLERANGE  = "VisuableRange";

	class CAgentConfig : public hiveConfig::CHiveConfig, public hiveCommon::CSingleton<CAgentConfig>
	{
	public:
		virtual ~CAgentConfig();

		virtual bool parseV(const std::string& vAgentInfo);
		float getRadius()              const {return getAttribute<float>(RADIUS);}
		float getMaxSpeed()            const {return getAttribute<float>(MAXSPEED);}
		float getTimeHorizon()         const {return getAttribute<float>(TIMEHORIZON);}
		float getTimeHorizonObst()     const {return getAttribute<float>(TIMEHORIZONOBST);}
		float getNeighborDist()        const {return getAttribute<float>(NEIGHBORDIST);}
		unsigned int getMaxNeighbors() const {return getAttribute<int>(MAXNEIGHBORS);}
		unsigned int getVisualRange()  const {return getAttribute<int>(VISUABLERANGE);}

	protected:
		CAgentConfig();

	private:
		friend class hiveCommon::CSingleton<CAgentConfig>;
	};
}