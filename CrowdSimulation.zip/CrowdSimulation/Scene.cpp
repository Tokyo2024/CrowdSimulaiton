#include "Scene.h"
#include <boost/random.hpp>
#include <FreeImage.h>
#include "SimulationTools.h"
#include "AgentConfig.h"
#include "CrowdSimulationConfig.h"

using namespace hiveCrowdSimulation;

const int GridLength = 2;
int ScreenShotCount = 0;	//liangzi

CScene::CScene(int vPWidth, int vPHeight)
{
	_ASSERTE((vPHeight > 0) && (vPWidth > 0));
	m_SceneWidth  = vPWidth;
	m_SceneHeight = vPHeight;
}

CROWD_SIMULATION_DLL_EXPORT CScene::~CScene()
{
	delete m_pScenePixelInfo;

	for (auto& NodeGrid : m_LeafNode2SceneGridMap)
		delete NodeGrid.second;
}

//*******************************************************************
//FUNCTION:
CSceneGrid* CScene::fetchSceneGrid(const CQuadTreeNode<SNode>* vNode)
{
	return m_LeafNode2SceneGridMap[vNode];
}

//*******************************************************************
//FUNCTION:
CSceneGrid* CScene::fetchSceneGrid(const glm::vec2& vPosition)
{
	const CQuadTreeNode<SNode>* pNode = getLeafNodeBySceneCoord(vPosition);
	_ASSERT(pNode);
	return fetchSceneGrid(pNode);
}

//*******************************************************************
//FUNCTION:
bool CScene::isVisible(glm::vec2 vEye, glm::vec2 vTarget, float vRadius)
{
	if (isPosExceedBorder(vEye) || isPosExceedBorder(vTarget))
		return false;
	if (getLeafNodeBySceneCoord(vEye)->getExtraInfo().Passability == NOPASS || getLeafNodeBySceneCoord(vTarget)->getExtraInfo().Passability == NOPASS)
		return false;

	if (!(fabs(vEye.x - vTarget.x) <= vRadius && fabs(vEye.y - vTarget.y) <= vRadius))
		return false;

	std::vector<glm::vec2> GridCroods;
	computeGridCoordBetweenTwoGrids(vEye, vTarget, GridCroods);
	std::vector<const CQuadTreeNode<SNode>*> NodeSet;
	SStraightLine Line = SStraightLine(vEye, vTarget);
	for (auto& Coord : GridCroods)
		dumpRectangleIntersect2Line(Line, m_BaseNodeSet[Coord.y][Coord.x], NodeSet);

	for (auto Node : NodeSet)
	{
		if (Node->getExtraInfo().Passability == NOPASS)
		{
			return false;
		}
	}

	return true;
}

//********************************************************************
//FUNCTION:
void CScene::computeGridCoordBetweenTwoGrids(const glm::vec2& vCoordA, const glm::vec2& vCoordB, std::vector<glm::vec2>& voResult) const
{
	_ASSERT(vCoordA.x < m_SceneWidth && vCoordA.y < m_SceneHeight);
	_ASSERT(vCoordB.x < m_SceneWidth && vCoordB.y < m_SceneHeight);

	glm::vec2 ArrayCoordA = glm::vec2(floor(vCoordA.x / m_BaseGridWidth), floor(vCoordA.y / m_BaseGridHeight));
	glm::vec2 ArrayCoordB = glm::vec2(floor(vCoordB.x / m_BaseGridWidth), floor(vCoordB.y / m_BaseGridHeight));

	const float UnitArrayLength = 1.0;

	SStraightLine Line = SStraightLine(vCoordA, vCoordB);

	float MinX = 0.0f, MaxX = 0.0f;
	float MinY = 0.0f, MaxY = 0.0f;
	__compareTwoNumber(vCoordA.x, vCoordB.x, MaxX, MinX);
	__compareTwoNumber(vCoordA.y, vCoordB.y, MaxY, MinY);
	float YBefore = vCoordA.x == MinX ? vCoordA.y : vCoordB.y;

	__compareTwoNumber(ArrayCoordA.x, ArrayCoordB.x, MaxX, MinX);
		
	for (float CoordX=MinX+UnitArrayLength; CoordX<= MaxX+1; CoordX=CoordX+UnitArrayLength)
	{
		float TempCoordX = CoordX * m_BaseGridWidth;
		float CoordY = Line.computeCorrespondingY(TempCoordX);

		float TempMinY = floor(((YBefore > CoordY ? CoordY : YBefore) > MinY ? (YBefore > CoordY ? CoordY : YBefore) : MinY) / m_BaseGridHeight);
		float TempMaxY = ceil(((YBefore > CoordY ? YBefore : CoordY) > MaxY ? MaxY : (YBefore > CoordY ? YBefore : CoordY)) / m_BaseGridHeight);

		for (; TempMinY<TempMaxY; TempMinY++)
		{
			voResult.push_back(glm::vec2(CoordX - UnitArrayLength, TempMinY));
		}
		YBefore = CoordY;
	}
}

//********************************************************************
//FUNCTION:
void CScene::__compareTwoNumber(float vA, float vB, float& voMax, float& voMin) const
{
	voMin = vA < vB ? vA : vB;
	voMax = vA < vB ? vB : vA;
}

//sprint 7
//********************************************************************
//FUNCTION:
void CScene::setPixelInfo(char* vPixelInfo)
{
	_ASSERT(vPixelInfo && !m_pScenePixelInfo);
	m_pScenePixelInfo = vPixelInfo;
}

//********************************************************************
//FUNCTION:
void CScene::setBaseAndMinDeep(int vBaseDeep, int vMinDeep)
{
	_ASSERT(vBaseDeep > 0);
	_ASSERT(vMinDeep > 0);
	_ASSERT(vBaseDeep < vMinDeep);
	_ASSERT(std::pow(2, vMinDeep) <= m_SceneWidth);
	_ASSERT(std::pow(2, vMinDeep) <= m_SceneHeight);
	m_BaseDeep = vBaseDeep;
	m_MinDeep  = vMinDeep; 
}

//********************************************************************
//FUNCTION:
void CScene::initBaseNodeSizeAndMinNodeSize()
{
	m_BaseGridWidth  = m_SceneWidth;
	m_BaseGridHeight = m_SceneHeight;
	for (int i=0; i<m_BaseDeep; ++i)
	{
		m_BaseGridWidth  /= 2;
		m_BaseGridHeight /= 2;
	}

	m_MinGridWidth = m_SceneWidth;
	m_MinGridHeight = m_SceneHeight;
	for (int i=0; i<m_MinDeep; ++i)
	{
		m_MinGridWidth  /= 2;
		m_MinGridHeight /= 2;
	}
}

//*******************************************************************
//FUNCTION: 
void CScene::initTree()
{
	SNode Data;
	m_pRootNode->setData(Data);
	m_pRootNode->setRectangle(glm::u32vec4(0, 0, m_SceneWidth, m_SceneHeight));
	/*m_BaseNodeSet.resize(ceil((float)m_SceneHeight / m_BaseGridHeight));
	for (size_t i=0; i<m_BaseNodeSet.size(); ++i)
	m_BaseNodeSet[i].resize(ceil((float)m_SceneWidth / m_BaseGridWidth));*/
	m_BaseNodeSet.resize(floor(m_SceneHeight / m_BaseGridHeight));
	for (size_t i=0; i<m_BaseNodeSet.size(); ++i)
		m_BaseNodeSet[i].resize(floor(m_SceneWidth / m_BaseGridWidth));
}

//*******************************************************************
//FUNCTION:
void CScene::createBaseNode()
{
	__createBaseNode(m_pRootNode);
}

//*******************************************************************
//FUNCTION:
void CScene::buildTreeForBaseNode()
{
	for (size_t i=0; i<m_BaseNodeSet.size(); ++i)
		for (size_t k=0; k<m_BaseNodeSet[i].size(); ++k)
			__createFinalTree(m_BaseNodeSet[i][k]);
}

//*******************************************************************
//FUNCTION:
void CScene::encode4Node()
{
	if (!m_pRootNode->isLeafNode())
	{
		for (size_t i=0; i<MAXCHILDNUM; ++i)
			__encode4Node(m_pRootNode->getChildByIndex(i), m_pRootNode->getExtraInfo().Code, i);
	}
 	else
 	{
 		glm::vec2 Center = glm::vec2(m_pRootNode->getMinX() + (m_pRootNode->getMaxX() - m_pRootNode->getMinX()) / 2, m_pRootNode->getMinY() + (m_pRootNode->getMaxY() - m_pRootNode->getMinY()) / 2);
 		float Area = m_pRootNode->getWidth() * m_pRootNode->getHeight();
		CSceneGrid* pGrid = new CSceneGrid(Center, Area);
		m_pRootNode->setCenter(Center);
 		m_LeafNode2SceneGridMap.insert(std::make_pair(m_pRootNode, pGrid));
 	}
}

//********************************************************************
//FUNCTION:
float CScene::getIntRandomXInScene(int vMin, int vMax)
{
	if (vMin <= CAgentConfig::getInstance()->getRadius())
		vMin = CAgentConfig::getInstance()->getRadius();
	if (vMax >= m_SceneWidth - CAgentConfig::getInstance()->getRadius())
		vMax = m_SceneWidth - CAgentConfig::getInstance()->getRadius();
	return getIntRandom(vMin, vMax);
}

//********************************************************************
//FUNCTION:
float CScene::getIntRandomYInScene(int vMin, int vMax)
{
	if (vMin <= 2 * CAgentConfig::getInstance()->getRadius())
		vMin = 2 * CAgentConfig::getInstance()->getRadius();
	if (vMax >= m_SceneHeight - 2 * CAgentConfig::getInstance()->getRadius())
		vMax = m_SceneHeight - 2 * CAgentConfig::getInstance()->getRadius();
	return getIntRandom(vMin, vMax);
}

//********************************************************************
//FUNCTION:
bool CScene::isCoordinateInPassableSceneGrid(const glm::vec2& vCoordinate, CSceneGrid*& voSceneGrid)
{
	const CQuadTreeNode<SNode>* pNode = getLeafNodeBySceneCoord(vCoordinate);
	voSceneGrid = m_LeafNode2SceneGridMap[pNode];
	return pNode->getExtraInfo().Passability == PASS ? true : false;
}

//********************************************************************
//FUNCTION:
void CScene::dumpNoPassableLeafNodes(std::vector<const CQuadTreeNode<SNode>*>& voNodeSet) const
{
	for (auto& NodeAndGrid : m_LeafNode2SceneGridMap)
		if (NodeAndGrid.first->getExtraInfo().Passability == NOPASS)
			voNodeSet.push_back(NodeAndGrid.first);
}

//*******************************************************************
//FUNCTION:
void CScene::__encode4Node(CQuadTreeNode<SNode>* vNode, const std::vector<char>& vCode, unsigned int vIndex)
{
	_ASSERT(vNode && vIndex < MAXCHILDNUM && vIndex >= MINCHILDNUM);
	vNode->fetchExtraInfo().Code = vCode;
	vNode->fetchExtraInfo().Code.push_back(vIndex);

	if (!vNode->isLeafNode())
	{
		for (size_t i=0; i<MAXCHILDNUM; ++i)
			__encode4Node(vNode->getChildByIndex(i), vNode->getExtraInfo().Code, i);
	}
	else
	{
		glm::vec2 Center = glm::vec2(vNode->getMinX() + (vNode->getMaxX() - vNode->getMinX()) / 2, vNode->getMinY() + (vNode->getMaxY() - vNode->getMinY()) / 2);
		float Area = vNode->getWidth() * vNode->getHeight();
		CSceneGrid* pGrid = new CSceneGrid(Center, Area);
		vNode->setCenter(Center);
		m_LeafNode2SceneGridMap.insert(std::make_pair(vNode, pGrid));
	}
}

//*******************************************************************
//FUNCTION:
void CScene::__createBaseNode(CQuadTreeNode<SNode>* vParent)
{
	glm::vec2 Center = glm::vec2(vParent->getMinX() + (vParent->getMaxX() - vParent->getMinX()) / 2, vParent->getMinY() + (vParent->getMaxY() - vParent->getMinY()) / 2);
	if (vParent->getWidth() <= m_BaseGridWidth || vParent->getHeight() <= m_BaseGridHeight)	//liangzi
	{
		vParent->setCenter(Center);
		int Y = (int)(Center.x / m_BaseGridWidth);
		int X = (int)(Center.y / m_BaseGridHeight);
		m_BaseNodeSet[X][Y] = vParent;
		return ;
	}
	else
	{
		vParent->divideNode(Center);
		for (int i=0; i<MAXCHILDNUM; ++i)
			__createBaseNode(vParent->getChildByIndex(i));
	}
}

//********************************************************************
//FUNCTION:
bool CScene::__getPixel(unsigned int vIndexI, unsigned int vIndexK) const
{
	_ASSERT(vIndexI<m_SceneWidth || vIndexK<m_SceneHeight);
	return (bool)m_pScenePixelInfo[vIndexK * (int)m_SceneWidth + vIndexI];
}

//*******************************************************************
//FUNCTION:
EPassibility CScene::__createFinalTree(CQuadTreeNode<SNode>* vParent)
{
	if (vParent->getWidth() <= m_MinGridWidth || vParent->getHeight() <= m_MinGridHeight)
	{
		vParent->fetchExtraInfo().Passability = __isMinLeafNodePassable(vParent->getRectangle());
		return vParent->getExtraInfo().Passability;
	}
	else
	{
		glm::vec2 Center = glm::vec2(vParent->getMinX() + (vParent->getMaxX() - vParent->getMinX()) / 2, vParent->getMinY() + (vParent->getMaxY() - vParent->getMinY()) / 2);

		vParent->divideNode(Center);
		std::vector<EPassibility> PassibilitySet;
		for (int i=0; i<MAXCHILDNUM; ++i)
			PassibilitySet.push_back(__createFinalTree(vParent->getChildByIndex(i)));
		
		EPassibility FinalFlag = PassibilitySet[0];
		if (FinalFlag == ORPASS)
		{
			vParent->fetchExtraInfo().Passability = ORPASS;
			return ORPASS;
		}
		for (size_t i=1; i<PassibilitySet.size(); ++i)
		{
			if (FinalFlag != PassibilitySet[i] || PassibilitySet[i] == ORPASS)
			{
				vParent->fetchExtraInfo().Passability = ORPASS;
				return ORPASS;
			}
		}
		if (FinalFlag == PASS)
		{
			for (size_t i=0; i<MAXCHILDNUM; ++i)
				vParent->deleteChild(i);
			vParent->fetchExtraInfo().Passability = FinalFlag;
			return PASS;
		}
		if (FinalFlag == NOPASS)
		{
			for (size_t i=0; i<MAXCHILDNUM; ++i)
				vParent->deleteChild(i);
			
			vParent->fetchExtraInfo().Passability = FinalFlag;
			return NOPASS;
		}
	}
}

//*******************************************************************
//FUNCTION:
EPassibility CScene::__isMinLeafNodePassable(const glm::u32vec4& vRange) const
{
	int Pass = 0;
	int Nopass = 0;
	for (size_t i=vRange.x; i<vRange.z; ++i)
		for (size_t k=vRange.y; k<vRange.w; ++k)
			__getPixel(i, k) ? Pass++ : Nopass++;

	return Pass >= Nopass ? PASS : NOPASS;
}

//*******************************************************************
//FUNCTION:
CQuadTreeNode<SNode>* CScene::__getNodeByCode(const std::vector<char>& vCode) const
{
	CQuadTreeNode<SNode>* pNode = m_pRootNode;
	size_t i=0; 
	while (i<vCode.size())
	{
		if (pNode->getChildByIndex(vCode[i])->isLeafNode())
			return pNode->getChildByIndex(vCode[i]);
		else
			pNode = pNode->getChildByIndex(vCode[i]);
		i++;
	}

	return NULL;
}

//*******************************************************************
//FUNCTION:
void CScene::findAdjNode(const CQuadTreeNode<SNode>* vSrcNode, std::vector<CQuadTreeNode<SNode>*>& voAdjNode)
{
	__determineDirCodeSet();
	__compAdjCodeAndFindAdjNodeByCode(vSrcNode->getExtraInfo().Code, voAdjNode);
}

//*******************************************************************
//FUNCTION:
void CScene::__determineDirCodeSet()
{
	m_EastSet.insert(1);
	m_EastSet.insert(3);

	m_WestSet.insert(0);
	m_WestSet.insert(2);

	m_SouthSet.insert(2);
	m_SouthSet.insert(3);

	m_NorthSet.insert(0);
	m_NorthSet.insert(1);
}

//*******************************************************************
//FUNCTION:
void CScene::__compAdjCodeAndFindAdjNodeByCode(const std::vector<char>& vCode, std::vector<CQuadTreeNode<SNode>*>& voAdjNode)
{
	std::vector<char> TargetCode;
	CQuadTreeNode<SNode>* pAdjNode = NULL;

	pAdjNode = __compEastAdjCodeAndFindNode(vCode, TargetCode) ? __getNodeByCode(TargetCode) : NULL;
	__push2AdjSetIfNodeNotNull(pAdjNode, voAdjNode);

	pAdjNode = __compWestAdjCodeAndFindNode(vCode, TargetCode) ? __getNodeByCode(TargetCode) : NULL;
	__push2AdjSetIfNodeNotNull(pAdjNode, voAdjNode);

	pAdjNode = __compSouthAdjCodeAndFindNode(vCode, TargetCode) ? __getNodeByCode(TargetCode) : NULL;
	__push2AdjSetIfNodeNotNull(pAdjNode, voAdjNode);

	pAdjNode = __compNorthAdjCodeAndFindNode(vCode, TargetCode) ? __getNodeByCode(TargetCode) : NULL;
	__push2AdjSetIfNodeNotNull(pAdjNode, voAdjNode);
	
	std::vector<char> TempCode;

	//W->N
	if (__compWestAdjCodeAndFindNode(vCode, TempCode))
	{
		pAdjNode = __compNorthAdjCodeAndFindNode(TempCode, TargetCode) ? __getNodeByCode(TargetCode) : NULL;	
		__push2AdjSetIfNodeNotNull(pAdjNode, voAdjNode);
	}

	//E->N
	if (__compEastAdjCodeAndFindNode(vCode, TempCode))
	{
		pAdjNode = __compNorthAdjCodeAndFindNode(TempCode, TargetCode) ? pAdjNode = __getNodeByCode(TargetCode) : NULL;		
		__push2AdjSetIfNodeNotNull(pAdjNode, voAdjNode);
	}

	//W->S
	if (__compWestAdjCodeAndFindNode(vCode, TempCode))
	{
		pAdjNode = __compSouthAdjCodeAndFindNode(TempCode, TargetCode) ? pAdjNode = __getNodeByCode(TargetCode) : NULL;		
		__push2AdjSetIfNodeNotNull(pAdjNode, voAdjNode);
	}

	//E->S
	if (__compEastAdjCodeAndFindNode(vCode, TempCode))
	{
		pAdjNode = __compSouthAdjCodeAndFindNode(TempCode, TargetCode) ? pAdjNode = __getNodeByCode(TargetCode) : NULL;	
		__push2AdjSetIfNodeNotNull(pAdjNode, voAdjNode);
	}
}

//*******************************************************************
//FUNCTION:
bool CScene::__compEastAdjCodeAndFindNode(const std::vector<char>& vCode, std::vector<char>& voTargetCode)
{
	if ((vCode[vCode.size()-1] == 0 || vCode[vCode.size()-1] == 2) && __changeLastLoc(GOEAST, vCode, voTargetCode))
		return true;

	if ((vCode[vCode.size()-1] == 1 || vCode[vCode.size()-1] == 3) && __changeSpecifiedLoc(GOEAST, vCode, voTargetCode))
		return true;

	return false;
}

//*******************************************************************
//FUNCTION:
bool CScene::__compWestAdjCodeAndFindNode(const std::vector<char>& vCode, std::vector<char>& voTargetCode)
{
	if ((vCode[vCode.size()-1] == 1 || vCode[vCode.size()-1] == 3) && __changeLastLoc(GOWEST, vCode, voTargetCode))
		return true;

	if ((vCode[vCode.size()-1] == 0 || vCode[vCode.size()-1] == 2) && __changeSpecifiedLoc(GOWEST, vCode, voTargetCode))
		return true;

	return false;
}

//*******************************************************************
//FUNCTION:
bool CScene::__compSouthAdjCodeAndFindNode(const std::vector<char>& vCode, std::vector<char>& voTargetCode)
{
	if ((vCode[vCode.size()-1] == 0 || vCode[vCode.size()-1] == 1) && __changeLastLoc(GOSOUTH, vCode, voTargetCode))
		return true;

	if ((vCode[vCode.size()-1] == 2 || vCode[vCode.size()-1] == 3) && __changeSpecifiedLoc(GOSOUTH, vCode, voTargetCode))
		return true;

	return false;
}

//*******************************************************************
//FUNCTION:
bool CScene::__compNorthAdjCodeAndFindNode(const std::vector<char>& vCode, std::vector<char>& voTargetCode)
{
	if ((vCode[vCode.size()-1] == 2 || vCode[vCode.size()-1] == 3) && __changeLastLoc(GONORTH, vCode, voTargetCode))
		return true;

	if ((vCode[vCode.size()-1] == 0 || vCode[vCode.size()-1] == 1) && __changeSpecifiedLoc(GONORTH, vCode, voTargetCode))
		return true;

	return false;
}

//*******************************************************************
//FUNCTION:
bool CScene::__changeLastLoc(char vGoDirection, const std::vector<char>& vSrcCodeSet, std::vector<char>& voTargetCodeSet)
{
	voTargetCodeSet.clear();
	voTargetCodeSet = vSrcCodeSet;
	char Tmp = voTargetCodeSet[voTargetCodeSet.size()-1];
	Tmp += vGoDirection;
	
	if (Tmp >= 0 && Tmp < 4)
	{
		voTargetCodeSet[voTargetCodeSet.size()-1] = Tmp;
		return true;
	}
	else
		return false;
}

//*******************************************************************
//FUNCTION:
bool CScene::__changeSpecifiedLoc(char vGoDirection, const std::vector<char>& vSrcCode, std::vector<char>& voTargetCode)
{
	voTargetCode.clear();

	int Index = -1;

	switch (vGoDirection)
	{
	case GOEAST:
		Index = __findLastIndexElemNotInSet(m_EastSet, vSrcCode);
		break;
	case GOWEST:
		Index = __findLastIndexElemNotInSet(m_WestSet, vSrcCode);
		break;
	case GOSOUTH:
		Index = __findLastIndexElemNotInSet(m_SouthSet,vSrcCode);
		break;
	case GONORTH:
		Index = __findLastIndexElemNotInSet(m_NorthSet, vSrcCode);
		break;
	default:
		break;
	}

	if (Index >= 0)
	{
		char Tmp = vSrcCode[Index];
		Tmp += vGoDirection;
		if (Index > 0)
		{
			for (size_t i=0; i<=Index-1; ++i)
				voTargetCode.push_back(vSrcCode[i]);
		}
		voTargetCode.push_back(Tmp);

		for (size_t i=Index+1; i<vSrcCode.size(); ++i)
			voTargetCode.push_back(vSrcCode[i] - vGoDirection);
	} 
	return Index>=0;
}

//*******************************************************************
//FUNCTION:
int CScene::__findLastIndexElemNotInSet(const std::set<char>& vSet, const std::vector<char>& vCode) const
{
	int i=vCode.size()-1;
	for (; i>=0; --i)
	{
		if (vSet.count(vCode[i]) == 0)
			return i;
	}

	return i;
}

//*******************************************************************
//FUNCTION:
void CScene::__push2AdjSetIfNodeNotNull(CQuadTreeNode<SNode>* vNode, std::vector<CQuadTreeNode<SNode>*>& voAdjNode) const
{
	if (vNode != NULL && vNode->getExtraInfo().Passability != NOPASS)
		voAdjNode.push_back(vNode);
}

//*******************************************************************
//FUNCTION:
const CQuadTreeNode<SNode>* CScene::getLeafNodeBySpecifiedIndex(unsigned int vIndex) const
{
	_ASSERT(vIndex<m_LeafNode2SceneGridMap.size());
	std::map<const CQuadTreeNode<SNode>*, CSceneGrid*>::const_iterator Iter = m_LeafNode2SceneGridMap.begin();
	int i=0;
	while (i != vIndex)
	{
		Iter++;
		i++;
	}
	return Iter->first;
}

//*******************************************************************
//FUNCTION:
void CScene::dumpPassableLeafNodes(std::vector<const CQuadTreeNode<SNode>*>& voNodeSet) const
{
	voNodeSet.clear();
	for (auto& NodeAndGrid : m_LeafNode2SceneGridMap)
		if (NodeAndGrid.first->getExtraInfo().Passability == PASS)
			voNodeSet.push_back(NodeAndGrid.first);
}

//*******************************************************************
//FUNCTION:
const CQuadTreeNode<SNode>* CScene::__getLeafNodeBySceneCoordFromOnNode(const CQuadTreeNode<SNode>* vParent, const glm::vec2& vScenePos) const
{
	return vParent->isCoordinationInMyRange(vScenePos) ? vParent->getChildByCoordinate(vScenePos) : NULL;
}

//*******************************************************************
//FUNCTION:
bool CScene::__isSegmentAndRectangleIntersect(const SStraightLine& vLine, const CQuadTreeNode<SNode>* vNode)
{
	int NodeMinX = vNode->getMinX();
	int NodeMaxX = vNode->getMaxX();
	int NodeMinY = vNode->getMinY();
	int NodeMaxY = vNode->getMaxY();
	float Y1 = vLine.computeCorrespondingY(NodeMinX);
	float Y2 = vLine.computeCorrespondingY(NodeMaxX);
	float X1 = vLine.computeCorrespondingX(NodeMinY);
	float X2 = vLine.computeCorrespondingX(NodeMaxY);
	float LineMaxX = vLine.getMaxX();
	float LineMaxY = vLine.getMaxY();
	float LineMinX = vLine.getMinX();
	float LineMinY = vLine.getMinY();

	/*if ((X1 == X2 && X1 == NodeMinX) || (X1 == X2 && X1 == NodeMaxX) || (Y1 == Y2 && Y1 == NodeMinY) || (Y1 == Y2 && Y1 == NodeMaxY))
		return false;*/

	int CountOfIntersection = 0;
	if (Y1 == -1 && vLine.PointA.x >= NodeMinX && vLine.PointA.x < NodeMaxX)
		CountOfIntersection++;
	if (X1 == -1 && vLine.PointA.y >= NodeMinY && vLine.PointA.y < NodeMaxY)
		CountOfIntersection++;
	if (Y1 >= NodeMinY && Y1 <= NodeMaxY)
		CountOfIntersection++;
	if (Y2 >= NodeMinY && Y2 <= NodeMaxY)
		CountOfIntersection++;
	if (X1 >= NodeMinX && X1 <= NodeMaxX)
		CountOfIntersection++;
	if (X2 >= NodeMinX && X2 <= NodeMaxX)
		CountOfIntersection++;

	if (vLine.getSlope() < 0)
	{
		if (X1 == NodeMinX && Y1 == NodeMinY)
			return false;
		if (X2 == NodeMaxX && Y2 == NodeMaxY)
			return false;
	}
	if (vLine.getSlope() > 0)
	{
		if (X1 == NodeMinX && Y2 == NodeMaxY)
			return false;
		if (X2 == NodeMaxX && Y1 == NodeMinY)
			return false;
	}
// 
// 	if ((int)Y1 == NodeMinY && Y2 < NodeMinY)
// 		CountOfIntersection--;
// 	if ((int)Y1 == NodeMaxY && Y2 > NodeMaxY)
// 		CountOfIntersection--;
// 	if ((int)Y2 == NodeMinY && Y1 < NodeMinY)
// 		CountOfIntersection--;
// 	if ((int)Y2 == NodeMaxY && Y1 > NodeMaxY)
// 		CountOfIntersection--;

	if (CountOfIntersection >= 2)
		return (NodeMinX <= LineMaxX && NodeMinY <= LineMaxY && NodeMaxX >= LineMinX && NodeMaxY >= LineMinY);
	else
		return false;
}

//********************************************************************
//FUNCTION:
void CScene::dumpRectangleIntersect2Line(const SStraightLine& vLine, const CQuadTreeNode<SNode>* vNode, std::vector<const CQuadTreeNode<SNode>*>& voNodeSet)
{
	if (vNode->isLeafNode())
		voNodeSet.push_back(vNode);
	else
	{
		for (size_t i=0; i<MAXCHILDNUM; ++i)
		{
			const CQuadTreeNode<SNode>* pNode = vNode->getChildByIndex(i);
			if (__isSegmentAndRectangleIntersect(vLine, pNode))
				dumpRectangleIntersect2Line(vLine, pNode, voNodeSet);
		}
	}
}

//********************************************************************
//FUNCTION:
const CQuadTreeNode<SNode>* CScene::getLeafNodeBySceneCoord(const glm::vec2& vSceneCoord) const 
{ 
	if (isPosExceedBorder(vSceneCoord))
		return NULL;
	int Y = floor(vSceneCoord.x / m_BaseGridWidth);
	int X = floor(vSceneCoord.y / m_BaseGridHeight);

	_ASSERT(Y >=0 && Y < m_BaseNodeSet[X].size());
	return __getLeafNodeBySceneCoordFromOnNode(m_BaseNodeSet[X][Y], vSceneCoord);
}

//********************************************************************
//FUNCTION:
void CScene::dumpAllLeafNode(std::vector<const CQuadTreeNode<SNode>*>& voLeafNodeSet) const
{
	for (auto& NodeAndGrid : m_LeafNode2SceneGridMap)
		voLeafNodeSet.push_back(NodeAndGrid.first);
}

//********************************************************************
//FUNCTION:
bool CScene::isPosExceedBorder(const glm::vec2& vPos) const
{
	return vPos.x >= m_SceneWidth || vPos.y >= m_SceneHeight || vPos.x < 0 || vPos.y < 0;
}

//********************************************************************
//FUNCTION:
void CScene::dumpNodeInSight(glm::vec2 vEye, float vViewableDistance, std::vector<const CQuadTreeNode<SNode>*>& voResult)
{
	std::vector<const CQuadTreeNode<SNode>*> BaseNodeSet;

	int MinX = vEye.x - (int)vViewableDistance;
	int MinY = vEye.y - (int)vViewableDistance;
	int MaxX = vEye.x + (int)vViewableDistance;
	int MaxY = vEye.y + (int)vViewableDistance;
	if (MinX < 0)
		MinX = 1;
	if (MinY < 0)
		MinY = 1;
	if (MaxX >= m_SceneWidth)
		MaxX = m_SceneWidth - 1;
	if (MaxY >= m_SceneHeight)
		MaxY = m_SceneHeight - 1;

	glm::vec2 LeftUpPoint    = glm::vec2(MinX, MinY);
	glm::vec2 RightUpPoint   = glm::vec2(MaxX, MinY);
	glm::vec2 LeftDownPoint  = glm::vec2(MinX, MaxY);
	glm::vec2 RightDownPoint = glm::vec2(MaxX, MaxY);

	int Index1 = 0;
	int Index2 = 0;

	
	SStraightLine UpLine = SStraightLine(LeftUpPoint, RightUpPoint);
	Index1 = LeftUpPoint.y / m_BaseGridHeight;
	for (Index2 = LeftUpPoint.x / m_BaseGridWidth; Index2 <= RightUpPoint.x / m_BaseGridWidth; ++Index2)
		BaseNodeSet.push_back(m_BaseNodeSet[Index1][Index2]);
	for (auto BaseNode : BaseNodeSet)
		dumpRectangleIntersect2Line(UpLine, BaseNode, voResult);
	BaseNodeSet.clear();
	
	SStraightLine DownLine = SStraightLine(LeftDownPoint, RightDownPoint);
	Index1 = LeftDownPoint.y / m_BaseGridHeight;
	for (Index2 = LeftDownPoint.x / m_BaseGridWidth; Index2 <= RightDownPoint.x / m_BaseGridWidth; ++Index2)
		BaseNodeSet.push_back(m_BaseNodeSet[Index1][Index2]);
	for (auto BaseNode : BaseNodeSet)
		dumpRectangleIntersect2Line(DownLine, BaseNode, voResult);
	BaseNodeSet.clear();
	
	SStraightLine LeftLine = SStraightLine(LeftUpPoint, LeftDownPoint);
	Index2 = LeftUpPoint.x / m_BaseGridWidth;
	for (Index1 = LeftUpPoint.y / m_BaseGridHeight; Index1 <= LeftDownPoint.y / m_BaseGridHeight; ++Index1)
		BaseNodeSet.push_back(m_BaseNodeSet[Index1][Index2]);
	for (auto BaseNode : BaseNodeSet)
		dumpRectangleIntersect2Line(LeftLine, BaseNode, voResult);
	BaseNodeSet.clear();
	
	SStraightLine RightLine = SStraightLine(RightUpPoint, RightDownPoint);
	Index2 = RightUpPoint.x / m_BaseGridWidth;
	for (Index1 = RightUpPoint.y / m_BaseGridHeight; Index1 <= RightDownPoint.y / m_BaseGridHeight; ++Index1)
		BaseNodeSet.push_back(m_BaseNodeSet[Index1][Index2]);
	for (auto BaseNode : BaseNodeSet)
		dumpRectangleIntersect2Line(RightLine, BaseNode, voResult);
	BaseNodeSet.clear();

	const CQuadTreeNode<SNode>* pNode = getLeafNodeBySceneCoord(vEye);
	while (find(voResult.begin(), voResult.end(), pNode) != voResult.end())
	{
		voResult.erase(find(voResult.begin(), voResult.end(), pNode));
	}

	/*for (auto Node : voResult)
	{
	if (!isVisible(vEye, Node->getExtraInfo->getCenter(), vViewableDistance))
	{
	while (find(voResult.begin(), voResult.end(), Node) != voResult.end())
	{
	voResult.erase(find(voResult.begin(), voResult.end(), Node));
	}
	}
	}*/

	//�������ɵĽ����1.�������Ƿ��ͨ�У�2.�ų�Eye��������3.������Eye�Ƿ�ֱ�ӿɼ�
}

void CScene::getLeafNodeFromOnNode(const CQuadTreeNode<SNode>* vParent, std::vector<const CQuadTreeNode<SNode>*>& voNodeSet) const
{
	if (vParent->isLeafNode())
		voNodeSet.push_back(vParent);
	else
	{
		for (unsigned int i=0; i<MAXCHILDNUM; ++i)
			getLeafNodeFromOnNode(vParent->getChildByIndex(i), voNodeSet);
	}
}

//********************************************************************
//FUNCTION:
int CScene::getBaseNodeSizeOfY() const
{
	return m_BaseNodeSet.size();
}

//********************************************************************
//FUNCTION:
int CScene::getBaseNodeSizeOfX() const
{
	_ASSERT(m_BaseNodeSet.size()>0);

	return m_BaseNodeSet[0].size();
}