#include "BestNextFinding.h"
#include "Scene.h"
#include "BaseGraph.h"

hiveCrowdSimulation::CBestNextFinding::CBestNextFinding(void)
{
}

hiveCrowdSimulation::CBestNextFinding::~CBestNextFinding(void)
{
}

//*******************************************************************
//FUNCTION:
glm::vec2 hiveCrowdSimulation::CBestNextFinding::fetchBestNext(const glm::vec2& vStart, const glm::vec2& vEnd, CScene* vScene, const CBaseGraph* vGraphWithOutCrowd, const CBaseGraph* vGraphWithCrowd, float vViewRange, std::vector<glm::vec2>& voRoad)
{
	_ASSERT(vScene);
	_ASSERT(vGraphWithOutCrowd);
	_ASSERT(vGraphWithCrowd);

	std::vector<const CQuadTreeNode<SNode>*> TempNodeInSight;
	std::vector<glm::vec2> NodeInSight;
	const CQuadTreeNode<SNode>* pStartNode = vScene->getLeafNodeBySceneCoord(vStart);
	const CQuadTreeNode<SNode>* pEndNode = vScene->getLeafNodeBySceneCoord(vEnd);
	glm::vec2 Start = pStartNode->getCenter(); 
	glm::vec2 End   = pEndNode->getCenter(); 

	if (Start == End)
	{
		voRoad.push_back(vEnd);
		return vEnd;
	}

	if (glm::distance(Start, End) < vViewRange && vScene->isVisible(Start, End, glm::distance(Start, End)))
	{
		vViewRange = glm::distance(Start, End);
	}
	vScene->dumpNodeInSight(Start, vViewRange, TempNodeInSight);

	for (auto Node : TempNodeInSight)
	{
		if (Node->getExtraInfo().Passability == PASS)
		{
			NodeInSight.push_back(Node->getCenter());
		}
	}

	glm::vec2 BestNext;
	std::vector<glm::vec2> TempRoad;
	float MinCost = FLT_MAX;
	for (auto& Node : NodeInSight)
	{
		if (Node == End)
		{
			voRoad.clear();
			m_pPathFindingAlgorithm->findShortestPathV(vGraphWithCrowd, Start, Node, voRoad);
			BestNext = Node;
			voRoad.erase(voRoad.begin());
			break;
		}
		TempRoad.clear();
		m_pPathFindingAlgorithm->findShortestPathV(vGraphWithCrowd, Start, Node, TempRoad);
		float CostBefore = m_pPathFindingAlgorithm->getTotalCost();
		m_pPathFindingAlgorithm->findShortestPathV(vGraphWithOutCrowd, Node, End);
		float CostAfter = m_pPathFindingAlgorithm->getTotalCost();
		float TempCost = CostBefore + CostAfter;
		//test
		//std::cout << Node.x << ", " << Node.y << ": " << TempCost << std::endl << std::endl;
		if (TempCost < MinCost)
		{
			MinCost = TempCost;
			BestNext = Node;
			voRoad = TempRoad;
		}
	}

	if (voRoad.size() == 0)
		voRoad.push_back(vEnd);

	return BestNext;
}

//*******************************************************************
//FUNCTION:
glm::vec2 hiveCrowdSimulation::CBestNextFinding::fetchBestNext(const glm::vec2& vStart, const glm::vec2& vEnd, CScene* vScene, const CBaseGraph* vGraphWithOutCrowd, const CBaseGraph* vGraphWithCrowd, float vViewRange, std::vector<glm::vec2>& voRoad, std::vector<glm::vec2>& voPathAfter)
{
	std::vector<const CQuadTreeNode<SNode>*> TempNodeInSight;
	std::vector<glm::vec2> NodeInSight;
	glm::vec2 Start = vScene->getLeafNodeBySceneCoord(vStart)->getCenter(); 
	glm::vec2 End   = vScene->getLeafNodeBySceneCoord(vEnd)->getCenter();   
	vScene->dumpNodeInSight(Start, vViewRange, TempNodeInSight);

	for (auto Node : TempNodeInSight)
	{
		if (Node->getExtraInfo().Passability == PASS)
		{
			NodeInSight.push_back(Node->getCenter());
		}
	}

	glm::vec2 BestNext;
	std::vector<glm::vec2> TempRoad;
	std::vector<glm::vec2> TempPathAfter;
	float MinCost = FLT_MAX;
	for (auto& Node : NodeInSight)
	{
		if (Node == End)
		{
			voRoad.clear();
			m_pPathFindingAlgorithm->findShortestPathV(vGraphWithCrowd, Start, Node, voRoad);
			BestNext = Node;
			break;
		}
		TempRoad.clear();
		TempPathAfter.clear();
		m_pPathFindingAlgorithm->findShortestPathV(vGraphWithCrowd, Start, Node, TempRoad);
		float CostBefore = m_pPathFindingAlgorithm->getTotalCost();
		m_pPathFindingAlgorithm->findShortestPathV(vGraphWithOutCrowd, Node, End , TempPathAfter);
		float CostAfter = m_pPathFindingAlgorithm->getTotalCost();
		float TempCost = CostBefore + CostAfter;
		if (TempCost < MinCost)
		{
			MinCost = TempCost;
			BestNext = Node;
			voRoad = TempRoad;
			voPathAfter = TempPathAfter;
		}
	}

	return BestNext;
}