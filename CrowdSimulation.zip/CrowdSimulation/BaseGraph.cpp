#include "BaseGraph.h"
#include "Scene.h"

using namespace hiveCrowdSimulation;

CBaseGraph::CBaseGraph()
{
}

CBaseGraph::~CBaseGraph()
{
}

//*******************************************************************
//FUNCTION:
void CBaseGraph::genGraph(CScene* vScene)
{
	_ASSERT(vScene);

	std::vector<const CQuadTreeNode<SNode>*> PassableLeafNodeSet;
	vScene->dumpPassableLeafNodes(PassableLeafNodeSet);
	for (size_t i=0; i<PassableLeafNodeSet.size(); ++i)
		__addNode(PassableLeafNodeSet[i]->getCenter());

	for (unsigned int i=0; i<m_Node2IndexVec.size(); i++)
		__findAndAddEdgesForAGrid(vScene, m_Node2IndexVec[i].second);
}

//*******************************************************************
//FUNCTION:
void CBaseGraph::__addNode(glm::vec2 vGrid)
{
	GRAPHVERTEX Index = m_Graph.addVertex(vGrid);
	m_Node2IndexVec.push_back(std::make_pair(Index, vGrid));
}

//*******************************************************************
//FUNCTION:
void CBaseGraph::__findAndAddEdgesForAGrid(CScene* vScene, glm::vec2& vGrid)
{
	const CQuadTreeNode<SNode>* pNode = vScene->getLeafNodeBySceneCoord(vGrid);
	std::vector<CQuadTreeNode<SNode>*> AdjactNodeSet;
	vScene->findAdjNode(pNode, AdjactNodeSet);

	for (size_t i=0; i<AdjactNodeSet.size(); ++i)
	{
		if (pNode->getExtraInfo().Code.size() > AdjactNodeSet[i]->getExtraInfo().Code.size())
			__addEdge(AdjactNodeSet[i]->getCenter(), vGrid, _computeEdgeWeightV(AdjactNodeSet[i]->getCenter(), vGrid));
		__addEdge(vGrid, AdjactNodeSet[i]->getCenter(), _computeEdgeWeightV(vGrid, AdjactNodeSet[i]->getCenter()));
	}
}

//*******************************************************************
//FUNCTION:
void CBaseGraph::__addEdge(const glm::vec2& vBeginNode, const glm::vec2& vEndNode, double vWeight)
{
	_ASSERT(vWeight > 0.0);

	GRAPHVERTEX BeginNodeIndex = __node2Index(vBeginNode);
	GRAPHVERTEX EndNodeIndex   = __node2Index(vEndNode);
	m_Graph.addEdge(BeginNodeIndex, EndNodeIndex, vWeight);
}

//*******************************************************************
//FUNCTION:
GRAPHVERTEX CBaseGraph::__node2Index(const glm::vec2& vTargetNode) const
{
	for (unsigned int i=0; i<m_Node2IndexVec.size(); i++)
		if (vTargetNode == (m_Node2IndexVec[i].second))
			return m_Node2IndexVec[i].first;

	return -1;
}

//*******************************************************************
//FUNCTION:
glm::vec2 CBaseGraph::__index2Node(const GRAPHVERTEX& vTargetIndex) const
{
	for (unsigned int i=0; i<m_Node2IndexVec.size(); i++)
		if (vTargetIndex == m_Node2IndexVec[i].first)
			return m_Node2IndexVec[i].second;

	return glm::vec2(0, 0);
}

//*******************************************************************
//FUNCTION:
double CBaseGraph::getEdgeWeight(const glm::vec2& vBeginNode, const glm::vec2& vEndNode) const
{
	return m_Graph.getEdgeWeight(__node2Index(vBeginNode), __node2Index(vEndNode));
}

//*******************************************************************
//FUNCTION:
void CBaseGraph::updateEdgeWeight(const glm::vec2& vBeginNode, const glm::vec2& vEndNode, double vEdgeWeight)
{
	_ASSERT(vEdgeWeight > 0.0);
	m_Graph.updateEdgeWeight(__node2Index(vBeginNode), __node2Index(vEndNode), vEdgeWeight);
}

//*******************************************************************
//FUNCTION:
void CBaseGraph::deleteNode(const glm::vec2& vTargetNode)
{
	for (unsigned int i=0; i<m_Node2IndexVec.size(); i++)
	{
		if (vTargetNode == m_Node2IndexVec[i].second)
		{
			m_Graph.deleteVertex(__node2Index(vTargetNode));
			m_Node2IndexVec.erase(m_Node2IndexVec.begin() + i); 
			break;
		}
	}
}

//*******************************************************************
//FUNCTION:
void CBaseGraph::getAdjacentNodeSet(const glm::vec2& vTargetNode, std::vector<glm::vec2>& voAdjacentNodeSet) const
{
	std::vector<GRAPHVERTEX> AdjacentNodeSet;
	GRAPHVERTEX Index = __node2Index(vTargetNode);
	if (Index<0) return;
	m_Graph.dumpAdjacentVertexSet(Index, AdjacentNodeSet);

	for (unsigned int i=0; i<AdjacentNodeSet.size(); i++)
		voAdjacentNodeSet.push_back(__index2Node(AdjacentNodeSet[i]));
}

//*******************************************************************
//FUNCTION:
void CBaseGraph::findShortestPathUseDijkstra(const glm::vec2& vBeginNode, const glm::vec2& vEndNode, double& voLength, std::vector<glm::vec2>& voResult)
{
	std::vector<GRAPHVERTEX> PathVertexSet;
    voLength = m_Graph.findShortestPath(__node2Index(vBeginNode), __node2Index(vEndNode), PathVertexSet);
	
	for (unsigned int i=0; i<PathVertexSet.size(); i++)
		voResult.push_back(__index2Node(PathVertexSet[i]));
}

//*******************************************************************
//FUNCTION:
double CBaseGraph::getCostOfSource2TargetPoint(const glm::vec2& vBeginNode, const glm::vec2& vEndNode) const
{
	return abs(vBeginNode.x - vEndNode.x) + abs(vBeginNode.y - vEndNode.y);
}