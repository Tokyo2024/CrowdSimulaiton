#include "GroupForce.h"
#include "SubGroup.h"
#include "IAgent.h"
#include "SimulationTools.h"

using namespace hiveCrowdSimulation;

CGroupForce::CGroupForce(void)
{
}

CGroupForce::~CGroupForce(void)
{
}

//*******************************************************************
//FUNCTION:
void CGroupForce::computeGroupForceByGroupCenter(const CSubgroup* vSubgroup, const CAgent* vTargetAgent, glm::vec2& voForce)
{
	_ASSERT(vSubgroup);
	_ASSERT(vTargetAgent);
	glm::vec2 CenterPos = vSubgroup->getSubgroupCenter();

	voForce = (glm::vec2(CenterPos - vTargetAgent->getPosition()));
}

//*******************************************************************
//FUNCTION:
void CGroupForce::computeGroupForceByRoulette(const CSubgroup* vSubgroup, const CAgent* vTargetAgent, glm::vec2& voForce)
{
	_ASSERT(vSubgroup);
	_ASSERT(vTargetAgent);

	std::vector<float> ProbabilitySet; // Inverse of distance

	for (unsigned int i=0; i<vSubgroup->getNumSubgroupMembers(); i++)
	{
		CAgent* pTempAgent = vSubgroup->fetchAgent(i);
		ProbabilitySet.push_back(glm::distance(vTargetAgent->getPosition(), pTempAgent->getPosition()));
	}

	unsigned int AgentIndex = choseByRoulette(ProbabilitySet);
	CAgent* pChoseAgent = vSubgroup->fetchAgent(AgentIndex);
	voForce = glm::vec2((pChoseAgent->getPosition(), vTargetAgent->getPosition())/glm::distance(pChoseAgent->getPosition(), vTargetAgent->getPosition()));
}

//*******************************************************************
//FUNCTION:
void CGroupForce::computeGroupForceByDistance(const CSubgroup* vSubgroup, const CAgent* vTargetAgent, glm::vec2& voForce)
{
	_ASSERT(vSubgroup);
	_ASSERT(vTargetAgent);

	float MinDistance = FLT_MAX;
	glm::vec2 MinDistPos;
	
	for (unsigned int i=0; i<vSubgroup->getNumSubgroupMembers(); i++)
	{
		CAgent* pTempAgent = vSubgroup->fetchAgent(i);
		if (pTempAgent==vTargetAgent) continue;
		float Distance = glm::distance(pTempAgent->getPosition(), vTargetAgent->getPosition());
		if (Distance < MinDistance)
		{
			MinDistance = Distance;
			MinDistPos  = pTempAgent->getPosition();
		}
	}

	voForce = glm::vec2((MinDistPos - vTargetAgent->getPosition())/MinDistance);
}

//*******************************************************************
//FUNCTION:
void CGroupForce::computeGroupForceByIntimacy(const CSubgroup* vSubgroup, const CAgent* vTargetAgent, glm::vec2& voForce)
{
	float MaxIntimacy = FLT_MIN;
	glm::vec2 MaxIntimacyPos;
		
	for (unsigned int i=0; i<vSubgroup->getNumSubgroupMembers(); i++)
	{
		CAgent* pTempAgent = vSubgroup->fetchAgent(i);
		if (pTempAgent == vTargetAgent) continue;
		float TempIntimacy = vTargetAgent->getIntimacy(pTempAgent);
		if (MaxIntimacy < TempIntimacy)
		{
			MaxIntimacy    = TempIntimacy;
			MaxIntimacyPos = pTempAgent->getPosition();
		}
	}
	
	voForce = glm::normalize(glm::vec2((MaxIntimacyPos-vTargetAgent->getPosition())));
}
