#pragma once
#include <vector>
#include <set>
#include <GLM/glm.hpp>
#include "SceneGrid.h"
#include "QuadTree.h"
#include "SimulationExport.h"

namespace hiveCrowdSimulation
{
	const int GOEAST  = 1;
	const int GOWEST  = -1;
	const int GOSOUTH = 2;
	const int GONORTH = -2;

	enum EPassibility
	{
		PASS   = 0,
		NOPASS = 1,
		ORPASS = 2
	};

	struct SNode
	{
		std::vector<char> Code;
		EPassibility      Passability;
		SNode() {}
		SNode(const std::vector<char>& vCode, EPassibility vPassibility)
		{
			Code = vCode;
			Passability = vPassibility;
		}
	};

	struct SStraightLine
	{
		glm::vec2 PointA;
		glm::vec2 PointB;

		SStraightLine() {}
		SStraightLine(const glm::vec2& vPointA, const glm::vec2& vPointB) : PointA(vPointA), PointB(vPointB) {}

		float computeCorrespondingY(float vX) const
		{
			if (PointA.x == PointB.x)
				return -1;
			return (vX - PointB.x) / (PointA.x - PointB.x) * (PointA.y - PointB.y) + PointB.y;
		}

		float computeCorrespondingX(float vY) const
		{
			if (PointA.y == PointB.y)
				return -1;
			return (vY - PointB.y) / (PointA.y - PointB.y) * (PointA.x - PointB.x) + PointB.x;
		}

		float getSlope() const {return (PointA.y - PointB.y) / (PointA.x - PointB.x);}
		float getMaxX() const {return PointA.x > PointB.x ? PointA.x : PointB.x;}
		float getMinX() const {return PointA.x < PointB.x ? PointA.x : PointB.x;}
		float getMaxY() const {return PointA.y > PointB.y ? PointA.y : PointB.y;}
		float getMinY() const {return PointA.y < PointB.y ? PointA.y : PointB.y;}
	};

	class CScene : public CQuadTree<SNode>
	{
	public:
		CScene(int vPWidth, int vPHeight);
		CROWD_SIMULATION_DLL_EXPORT ~CScene();

		void dumpNodeInSight(glm::vec2 vEye, float vViewableDistance, std::vector<const CQuadTreeNode<SNode>*>& voResult);
		void dumpAllLeafNode(std::vector<const CQuadTreeNode<SNode>*>& voLeafNodeSet) const;
		void dumpPassableLeafNodes(std::vector<const CQuadTreeNode<SNode>*>& voNodeSet) const;
		void dumpNoPassableLeafNodes(std::vector<const CQuadTreeNode<SNode>*>& voNodeSet) const;
		const CQuadTreeNode<SNode>* getLeafNodeBySpecifiedIndex(unsigned int vIndex) const;
		
		void findAdjNode(const CQuadTreeNode<SNode>* vSrcNode, std::vector<CQuadTreeNode<SNode>*>& voAdjNode);
		float getSceneWidth() const  {return m_SceneWidth;}
		float getSceneHeight() const {return m_SceneHeight;}

		void setPixelInfo(char* vPixelInfo);
		void setBaseAndMinDeep(int vBaseDeep, int vMinDeep);
		void initBaseNodeSizeAndMinNodeSize();

		void initTree();
		void createBaseNode();
		void buildTreeForBaseNode();
		void encode4Node();

		void dumpRectangleIntersect2Line(const SStraightLine& vLine, const CQuadTreeNode<SNode>* vNode, std::vector<const CQuadTreeNode<SNode>*>& voNodeSet);
		float getIntRandomXInScene(int vMin, int vMax);
		float getIntRandomYInScene(int vMin, int vMax);
		bool isCoordinateInPassableSceneGrid(const glm::vec2& vCoordinate, CSceneGrid*& voSceneGrid);
		
		CSceneGrid* fetchSceneGrid(const CQuadTreeNode<SNode>* vNode);
		CSceneGrid* fetchSceneGrid(const glm::vec2& vPosition);
		bool isPosExceedBorder(const glm::vec2& vPos) const;		
		bool isVisible(glm::vec2 vEye, glm::vec2 vTarget, float vRadius);
		int getBaseNodeSizeOfY() const;
		int getBaseNodeSizeOfX() const;
		void computeGridCoordBetweenTwoGrids(const glm::vec2& vArrayCoordA, const glm::vec2& vArrayCoordB, std::vector<glm::vec2>& vResult) const; 
		virtual const CQuadTreeNode<SNode>* getLeafNodeBySceneCoord(const glm::vec2& vSceneCoord) const override;
		const CQuadTreeNode<SNode>* getBaseNode(int vX, int vY) const {return m_BaseNodeSet[vX][vY];}
		void getLeafNodeFromOnNode(const CQuadTreeNode<SNode>* vParent, std::vector<const CQuadTreeNode<SNode>*>& voNodeSet) const;

	private:
		void __encode4Node(CQuadTreeNode<SNode>* vNode, const std::vector<char>& vCode, unsigned int vIndex);
		void __createBaseNode(CQuadTreeNode<SNode>* vParent);
		void __determineDirCodeSet();
		void __push2AdjSetIfNodeNotNull(CQuadTreeNode<SNode>* vNode, std::vector<CQuadTreeNode<SNode>*>& voAdjNode) const;
		void __compAdjCodeAndFindAdjNodeByCode(const std::vector<char>& vCode, std::vector<CQuadTreeNode<SNode>*>& voAdjNode);
		void __setMinNodeSize(int vWidth, int vHeight) {m_MinGridWidth = vWidth, m_MinGridHeight = vHeight;}
		bool __compEastAdjCodeAndFindNode(const std::vector<char>& vCode, std::vector<char>& voTargetCode);
		bool __compWestAdjCodeAndFindNode(const std::vector<char>& vCode, std::vector<char>& voTargetCode);
		bool __compSouthAdjCodeAndFindNode(const std::vector<char>& vCode, std::vector<char>& voTargetCode);
		bool __compNorthAdjCodeAndFindNode(const std::vector<char>& vCode, std::vector<char>& voTargetCode);
		bool __changeLastLoc(char vGoDirection, const std::vector<char>& vSrcCodeSet, std::vector<char>& voTargetCodeSet);
		bool __changeSpecifiedLoc(char vGoDirection, const std::vector<char>& vSrcCode, std::vector<char>& voTargetCode);
		int  __findLastIndexElemNotInSet(const std::set<char>& vSet, const std::vector<char>& vCode) const;
		EPassibility __createFinalTree(CQuadTreeNode<SNode>* vParent);
		EPassibility __isMinLeafNodePassable(const glm::u32vec4& vRange) const;
		CQuadTreeNode<SNode>* __getNodeByCode(const std::vector<char>& vCode) const;
		const std::vector<char>& __getTreeNodeCode(CQuadTreeNode<SNode>* vNode) const {return vNode->getExtraInfo().Code;}  
		bool __getPixel(unsigned int vIndexI, unsigned int vIndexK) const;
		bool __isSegmentAndRectangleIntersect(const SStraightLine& vLine, const CQuadTreeNode<SNode>* vNode); //�޸�
		const CQuadTreeNode<SNode>* __getLeafNodeBySceneCoordFromOnNode(const CQuadTreeNode<SNode>* vParent, const glm::vec2& vScenePos) const;

	private:		
		void __compareTwoNumber(float vA, float vB, float& voMax, float& voMin) const;

	private:
		char* m_pScenePixelInfo;
		std::map<const CQuadTreeNode<SNode>*, CSceneGrid*> m_LeafNode2SceneGridMap;
		std::vector<std::vector<CQuadTreeNode<SNode>*>> m_BaseNodeSet;
		int	m_BaseDeep;
		int m_MinDeep;
		int m_BaseGridWidth;
		int m_BaseGridHeight;
		int m_MinGridWidth;
		int m_MinGridHeight;
		int m_SceneWidth;
		int m_SceneHeight;
		std::set<char> m_EastSet;
		std::set<char> m_WestSet;
		std::set<char> m_SouthSet;
		std::set<char> m_NorthSet;
	};
}