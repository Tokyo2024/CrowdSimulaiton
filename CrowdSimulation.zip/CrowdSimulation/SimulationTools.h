#pragma once
#include <ctime>
#include <string>
#include <vector>
#include <map>
#include <GLM/glm.hpp>
#include <boost/random.hpp>

namespace hiveCrowdSimulation
{
	class CAgent;
	//const float M_PI    = 3.1415926f;
	const int MAXNUMGROUPCOLOR    = 5;
	const int MAXNUMSUBGROUPCOLOR = 4;
	const glm::vec3 GroupColorArray[MAXNUMGROUPCOLOR][MAXNUMSUBGROUPCOLOR] = 
	{{glm::vec3(50, 50, 0), glm::vec3(200, 200, 10), glm::vec3(250, 20, 20), glm::vec3(0, 200, 30)},
	{glm::vec3(0, 0, 150), glm::vec3(0, 0, 200), glm::vec3(0, 0, 250), glm::vec3(0, 30, 30)},
	{glm::vec3(0, 100, 100), glm::vec3(2, 100, 10), glm::vec3(2, 20, 20), glm::vec3(2, 30, 30)},
	{glm::vec3(100, 10, 100), glm::vec3(180, 10, 180), glm::vec3(200, 10, 200), glm::vec3(250, 10, 250)},};
	const glm::vec3 ExeTaskGroupColor[MAXNUMGROUPCOLOR] = {glm::vec3(255, 255, 255), glm::vec3(0, 0, 100), glm::vec3(180, 0, 0), glm::vec3(100, 100, 0), glm::vec3(0, 255, 255)};
	
	const float OFFSETX = 2.0f;
	const float OFFSETY = 0.1f;
	const float LOWPOSSIBILITY  = 500.0;
	const float HIGHPOSSIBILITY = 1000.0;
	static time_t TotalTime   = 0;
	static boost::mt19937_64 Engine;
	static std::vector<glm::vec3> GroupColorPool;

	void         initSeed(time_t vSeed);
	time_t       setSeed();
	//void         setSrandSeed(int vSeed) {}
	float        dot(const glm::vec2& vVectorA, const glm::vec2& vVectorB);
	float        guassDistributionFunc(const glm::vec2& vMean, const glm::mat2x2& vVarianceMat, const glm::vec2& vData);
	float        exceGuassDistributionFunc(const std::vector<glm::vec2>& vDataSet, const glm::vec2& vData);
	void         writeAgentInfo2File(const CAgent* vAgent, std::ofstream& vioFileStream);
	void         computeMeanAndVariance(const std::vector<glm::vec2>& vDataSet, glm::vec2& voMean, glm::mat2x2& voVarianceMat);
	unsigned int choseByRoulette(const std::vector<float>& vProbability);
	const glm::vec2 rotateVector(const glm::vec2& vVector, float vAngle);
	void         computeRectDiagonal(const glm::vec2& vCenter, float vRadius, glm::vec2& voLeftUpPoint, glm::vec2& voRightDownPoint);

	int getIntRandom(int vMin, int vMax);
	float getFloatRandom(float vMin, float vMax);

	int getNum(int vNum); //�����ƽ��Ķ�������
}