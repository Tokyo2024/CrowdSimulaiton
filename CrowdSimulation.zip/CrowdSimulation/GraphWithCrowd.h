#pragma once
#include "BaseGraph.h"

namespace hiveCrowdSimulation
{
	class CGraphWithCrowd : public CBaseGraph
	{
	public:
		CGraphWithCrowd(CScene* vScene);
		virtual ~CGraphWithCrowd();

		void updateGraph();
		void updateGraph4SpecifiedGrid(const glm::vec2& vGridCenter);

	protected:
		virtual double _computeEdgeWeightV(const glm::vec2& vBegin, const glm::vec2& vEnd) const override;

	private:
		void __updateTwoWayEdgeWeight(const glm::vec2& vTarget);

	private:
		CScene* m_pScene;
	};
}