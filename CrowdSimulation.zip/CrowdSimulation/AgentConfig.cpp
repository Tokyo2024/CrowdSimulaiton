#include "common/ConfigParser.h"
#include "AgentConfig.h"

using namespace hiveCrowdSimulation;

CAgentConfig::CAgentConfig()
{
	defineAttribute(RADIUS,          hiveConfig::ATTRIBUTE_FLOAT);
	//defineAttribute(RADIUSOFFSET,   hiveConfig::ATTRIBUTE_FLOAT);
	defineAttribute(MAXSPEED,        hiveConfig::ATTRIBUTE_FLOAT);
	defineAttribute(MAXNEIGHBORS,    hiveConfig::ATTRIBUTE_INT);
	defineAttribute(NEIGHBORDIST,    hiveConfig::ATTRIBUTE_FLOAT);
	defineAttribute(TIMEHORIZON,     hiveConfig::ATTRIBUTE_FLOAT);
	defineAttribute(TIMEHORIZONOBST, hiveConfig::ATTRIBUTE_FLOAT);
	defineAttribute(AGENTINFO,       hiveConfig::ATTRIBUTE_SUBCONFIG);
	defineAttribute(AGENT,           hiveConfig::ATTRIBUTE_VEC4F);
	defineAttribute(VISUABLERANGE,   hiveConfig::ATTRIBUTE_INT);
}

CAgentConfig::~CAgentConfig()
{
}

//*******************************************************************
//FUNCTION:
bool CAgentConfig::parseV(const std::string& vAgentInfo)
{
	return hiveConfig::hiveParseConfig(vAgentInfo, hiveConfig::CONFIG_XML, this);
}