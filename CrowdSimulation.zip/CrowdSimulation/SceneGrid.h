#pragma once
#include <vector>
#include <GLM/glm.hpp>
#include "IAgent.h"

namespace hiveCrowdSimulation
{
	class CSceneGrid
	{
	public:
		CSceneGrid(const glm::vec2& vCoordinate, float vArea);
		~CSceneGrid();

		bool  isUpdate()   const {return m_IsUpdate;}
		bool  operator == (const CSceneGrid& vGrid) const {return m_Coordinate == vGrid.getCoordinate();}
		const glm::vec2& getCoordinate() const {return m_Coordinate;} 
		const glm::vec2& getAvgMoveDirection();
		float getAvgSpeed();
		float getCrowdDensity() const;
		void  addAgent(CAgent* vAgent);
		void  deleteAgent(const CAgent* vAgent);
		void  deleteCrowd();

	private:
		void __updateInformationOfVelocity();

	private:            
		bool                 m_IsUpdate;
		float                m_AvgSpeed;
		float                m_Area;
		glm::vec2            m_Coordinate;
		glm::vec2            m_AvgDirection;
		std::vector<CAgent*> m_Crowd;
	};
}