#pragma once
#include <vector>
#include <queue>
#include <GLM/glm.hpp>
#include "Agent.h"
#include "Common.h"

namespace hiveCrowdSimulation
{
	class CScene;
	class CSubgroup;
	class CAgent
	{
	public:
		CAgent(const glm::vec2& vDirection, float vSpeed, const glm::vec2& vPosition, CScene* vScene);
		~CAgent();

		int getIndex() const {return m_Index;}
		void setIndex(int vIndex) {m_Index = vIndex;}

		void setInitSpeed(float vSpeed)                          {m_InitialSpeed = vSpeed;}
		void setGroupID(unsigned int vID)                        {m_GroupID = vID;}
		void setIsReachGoal();
		void setAwareness(bool vAwareness)                       {m_IsAwareness = vAwareness;}
		void setHasFoundExit(bool vFlag)                         {m_HasFoundExit = vFlag;}
		void setGridID(const glm::vec2& vGridID)                 {m_GridID = vGridID;}
		void setTempGoal(const glm::vec2 &vGoal)                 {m_TempGoal = vGoal;}
		void setRadius(float vRadius)                            {m_pRVOAgent->setRadius(vRadius);}
		void setMaxSpeed(float voMaxSpeed)                       {m_pRVOAgent->setMaxSpeed(voMaxSpeed);}
		void setPosition(const glm::vec2& vPos)                  {m_pRVOAgent->setPosition(vPos);}
		void setGoalPos(const glm::vec2& vGoalPos)               {m_pRVOAgent->setGoalPos(vGoalPos); m_GoalPosition = vGoalPos;}
		void setVelocity(const glm::vec2& vVelocity)             {m_pRVOAgent->setVelocity(vVelocity);}
		void setPreferedVelocity(const glm::vec2& vPrefVelocity) {m_pRVOAgent->setPrefVelocity(vPrefVelocity);}
		void setAbility(float vAbility)                          {m_Ability = vAbility;}
		void setRVOAgent(RVO::Agent* vAgent);

		unsigned int getGlobalTime()        const {return m_pRVOAgent->getGlobalTime();}
		int   getGroupID()                  const {return m_GroupID;}
		float getAbility()                  const {return m_Ability;}
		float getMaxSpeed()                 const {return m_pRVOAgent->getMaxSpeed();}
		float getRadius()                   const {return m_pRVOAgent->getRadius();}
		float getIntimacy(const CAgent* vAgent) const;
		float computeDifficulty(const CAgent* vAgent);

		const glm::vec2& getVelocity()     const {return m_pRVOAgent->getVelocity();}
		const glm::vec2& getPrefVelocity() const {return m_pRVOAgent->getPrefVelocity();}
		const glm::vec2& getInitPosition() const {return m_InitialPosition;}
		const glm::vec2& getPosition()     const {return m_pRVOAgent->getPosition();}
		const glm::vec2& getGoal()         const {return m_pRVOAgent->getGoalPos();}
		const glm::vec2& getGridID()       const {return m_GridID;} 
		const glm::vec2& getTempGoal()     const {return m_TempGoal;}

		bool getIsReachGoal() const {return m_IsReachGoal;}
		bool isAwareness()    const {return m_IsAwareness;}
		bool hasFoundExit()   const {return m_HasFoundExit;}
		bool isReachedGoal(const glm::vec2& vGoal, float vRadius) const;
		bool isBelongedGroup() const {return m_GroupID > -1;} 
		bool isAgentDirectInSight(const CAgent* vAgent);
		bool generateTargetCandidate(SCost2FindSomeone* voCandidate, CSubgroup* vSubgroup);
		
		void setToFinishTask();
		void setToDoTask(const CAgent* vAgent);
		void exchangeInfo(const CAgent* vAgent);
		void updateFinishState(bool& voFlag);
		void addAgent2Relationship(const CAgent* vAgent, SAgentRelationship* vRelationship);
		void updateRoadmap(const std::vector<glm::vec2>& vRoadmap) {m_Roadmap = vRoadmap;}
		void dumpRoadMap(std::vector<glm::vec2>& voAgentRoadMap) const {voAgentRoadMap = m_Roadmap;}

		glm::vec2 computeIgnoranceVelocity(const std::vector<glm::vec2>& vPosition, const std::vector<glm::vec2>& vVelocity);
		bool operator == (CAgent* vAgent) {return m_pRVOAgent->getPosition() == vAgent->getPosition();}
		SAgentRelationship* fetchRelationship(const CAgent* vAgent) const;
		bool isReachExit() {return m_HasFoundExit;}
		void setReachExitsStatus(bool vIsReachExit);

	private:
		bool hiveCrowdSimulation::CAgent::__isExistRelationshipWithAgent(const CAgent* vAgent) const;
		void  __generateInfluenceMatrix(const std::vector<glm::vec2>& vPosition, const std::vector<glm::vec2>& vVelocity);

		glm::vec2 __computeDirectionInflunecedByExternal();

		float __computeWeight(const glm::vec2& vPosition, const glm::vec2& vVelocity, const glm::vec2& vAverageVelocity);
		float __computeWeightOfDistance(const glm::vec2& vPosition) const;
		float __computeWeightOfVelocity(const glm::vec2& vVelocity, const glm::vec2& vAverageVelocity) const;
		float __computeWeightOfPosition(const glm::vec2& vPosition, const glm::vec2& vAverageVelocity) const;
		float __computeAttention(const CAgent* vAgent, float vTotalIntimacy);
		float __computeCrowdDensity();
	
	private:
		int                    m_Index;
		bool                   m_IsAwareness;
		bool                   m_HasFoundExit;
		bool                   m_IsReachGoal;
		float                  m_InitialSpeed;
		float                  m_Ability;
		int                    m_GroupID;
		CScene*                m_pScene;
		RVO::Agent*            m_pRVOAgent;
		glm::vec2              m_TempGoal;
		glm::vec2              m_GroupForce;
		glm::vec2              m_GridID;
		glm::vec2              m_GoalPosition;
		glm::vec2              m_InitialDirection;
		glm::vec2              m_InitialPosition;
		std::vector<glm::vec2> m_Martix;
		std::vector<glm::vec2> m_Roadmap;
		std::map<const CAgent*, SAgentRelationship*> m_AgentRelationshipSet;
		bool                    m_IsReachExit;
	};
}