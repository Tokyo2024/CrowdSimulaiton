#pragma once
#include <vector>
#include <unordered_map>
#include "Common.h"

namespace hiveCrowdSimulation
{
	class CAgent;
	class CSubgroup;

	class CGroup
	{
	public:
		CGroup(void);
		~CGroup(void);

		void initRelationship();				
		void addGroupMember(CAgent* vAgent);
		void setGroupSize(int vSize) {m_NumGroupMembers = vSize;}
		void updateStatus(); 
		void updateFinishState(bool& voFlag);

		int getNumGroupMembers() const {return m_NumGroupMembers;}
		int getNumSubgroup() const {return m_SubgroupSet.size();}

		CSubgroup* fetchSubgroup(unsigned int vIndex) const;
		CSubgroup* fetchSearchingSubgroup(unsigned int vIndex) const;

		//********************************************************************
        #ifdef _DEBUG
		void clearSubgroupSet();
		void clearTaskSet();
		void addNormalSubgroup(CSubgroup* vSubgroup);
		void addSubgroup2ExecTaskSet(CSubgroup* vSub);
		void updateStatus4TestGivingUp(bool& vIsGivingUp);
		int  getTaskSize() const {return m_ExeFindingTaskSubgroupSet.size();}
		void fetchExeTaskAgent(std::vector<CAgent*>& voAgentSet) const;
		#endif

	private:
		void __updateAttention(CSubgroup* vExeFindingTaskSubgroup);
		void __taskUpdatedDueToGiveUp();
		void __taskUpdatedDueToFinished();

		void __updateAwareness();
		void __updateSubgroupCenter();
		void __updateTaskSet();
		void __splitSubgroup();
		void __mergeSubgroup();
		void __exchangeInfoBetweenAgent();
		void __makeDecision();

	private:								 							 
		std::vector<CSubgroup*> m_SubgroupSet;
		std::vector<CSubgroup*> m_ExeFindingTaskSubgroupSet;
		int                     m_NumGroupMembers;	

		friend class CFramework;
	};
}