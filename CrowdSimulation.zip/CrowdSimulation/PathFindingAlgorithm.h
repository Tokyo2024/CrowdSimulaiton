#pragma once
#include <vector>
#include <GLM/glm.hpp>

namespace hiveCrowdSimulation
{
	class CBaseGraph;
	class CPathFindingAlgorithm
	{
	public:
		CPathFindingAlgorithm(void) {}
		virtual ~CPathFindingAlgorithm(void) {}

		virtual bool findShortestPathV(const CBaseGraph* vGraph, const glm::vec2& vStart, const glm::vec2& vEnd, std::vector<glm::vec2>& voSceneGridCoordSet) {return false;}
		virtual bool findShortestPathV(const CBaseGraph* vGraph, const glm::vec2& vStart, const glm::vec2& vEnd) {return false;}
		virtual float getTotalCost() {return -1;}
		void setAlgorithmCreationSig(const std::string& vSig) {m_AlgorithmCreationSig = vSig;}

	private:
		std::string m_AlgorithmCreationSig;
	};
}