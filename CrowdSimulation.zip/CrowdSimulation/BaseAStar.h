#pragma once
#include "SimulationExport.h"
#include "SceneGrid.h"

class CBaseGraph;

struct SPoint
{
	CSceneGrid Node;

	float G;
	float H;
	float F;

	CSceneGrid Parent;

	SPoint() 
	{
		G = 0;
		H = 0;
		F = 0;
	}
};

class CROWD_SIMULATION_DLL_EXPORT CBaseAStar
{
public:
	CBaseAStar() {}
	virtual ~CBaseAStar() {}

	virtual bool findShortestPathV(const CBaseGraph& vGraph, const CSceneGrid& vStart, const CSceneGrid& vEnd) = 0;
};


