#pragma once
#include <GLM/glm.hpp>

namespace hiveCrowdSimulation
{
	class CAgent;
	class CSceneGrid;
	class CScene;

	class CAgentGenerator
	{
	public:
		CAgentGenerator();
		~CAgentGenerator();

	    CAgent* genAgentAtFixedSceneGrid(CScene* vScene, const glm::vec2& vGridCoord, const glm::vec2& vSpeedRange);
		CAgent* genAgentAtFixedCoordinate(CScene* vScene, const glm::vec2& vCoordinate);
	};
}