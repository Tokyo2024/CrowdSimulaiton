#pragma once
#include <vector>
#include <GLM/glm.hpp>

namespace hiveCrowdSimulation
{
	enum EOrientation
	{
		NorthWest = 0,
		NorthEast = 1,
		SouthWest = 2,
		SouthEast = 3
	};

	const int MAXCHILDNUM = 4;
	const int MINCHILDNUM = 0;

	template<class TNodeExtraInfo>
	class CQuadTreeNode
	{
	public:
		CQuadTreeNode(void);
		CQuadTreeNode(glm::u32vec4 vRect);
		CQuadTreeNode(const TNodeExtraInfo& vData, glm::u32vec4 vRect);
		~CQuadTreeNode(void);

		int getChildSize() {return m_Children.size();}
		bool isCoordinationInMyRange(glm::vec2 vCoordination) const;
		bool isLeafNode() const;
		bool addChild(CQuadTreeNode<TNodeExtraInfo>* vChild, unsigned int vIndex);
		void deleteChild(unsigned int vIndex);
		void divideNode(glm::vec2 vCenter);
		void clearChild();
		void setCenter(glm::vec2 vCenter);
		void setData(TNodeExtraInfo vData);
		void setRectangle(glm::u32vec4 vRectangle);

		glm::vec2    getCenter() const;
		glm::u32vec4 getRectangle() const;
		
		TNodeExtraInfo& fetchExtraInfo() /*const*/;
		const TNodeExtraInfo& getExtraInfo() const;

		CQuadTreeNode<TNodeExtraInfo>* getChildByIndex(unsigned int vIndex) const;
		const CQuadTreeNode<TNodeExtraInfo>* getChildByCoordinate(glm::vec2 vCoordination) const;
		
		int getMinX() const   {return m_Rect.x;}
		int getMinY() const   {return m_Rect.y;}
		int getMaxX() const   {return m_Rect.z;}
		int getMaxY() const   {return m_Rect.w;}
		int getWidth() const  {return m_Rect.z - m_Rect.x;}
		int getHeight() const {return m_Rect.w - m_Rect.y;}

	private:
		TNodeExtraInfo m_Data;
		glm::u32vec4   m_Rect; // (Xmin, Ymin, Xmax, Ymax)
		glm::vec2      m_Center;
		std::vector<CQuadTreeNode<TNodeExtraInfo>*> m_Children;
	};

	template<class TNodeExtraInfo>
	TNodeExtraInfo& CQuadTreeNode<TNodeExtraInfo>::fetchExtraInfo() /*const*/
	{
		return m_Data;
	}

	template<class TNodeExtraInfo>
	glm::vec2 CQuadTreeNode<TNodeExtraInfo>::getCenter() const
	{
		return m_Center;
	}

	template<class TNodeExtraInfo>
	void CQuadTreeNode<TNodeExtraInfo>::setCenter(glm::vec2 vCenter)
	{
		m_Center = vCenter;
	}

	template<class TNodeExtraInfo>
	glm::u32vec4 CQuadTreeNode<TNodeExtraInfo>::getRectangle() const
	{
		return m_Rect;
	}

	template<class TNodeExtraInfo>
	void CQuadTreeNode<TNodeExtraInfo>::setData(TNodeExtraInfo vData)
	{
		m_Data = vData;
	}

	template<class TNodeExtraInfo>
	void CQuadTreeNode<TNodeExtraInfo>::setRectangle(glm::u32vec4 vRectangle)
	{
		m_Rect = vRectangle;
	}

	template<class TNodeExtraInfo>
	const TNodeExtraInfo& CQuadTreeNode<TNodeExtraInfo>::getExtraInfo() const 
	{
		return m_Data;
	}

	template<class TNodeExtraInfo>
	bool CQuadTreeNode<TNodeExtraInfo>::isCoordinationInMyRange(glm::vec2 vCoordination) const
	{
		if (vCoordination.x >= m_Rect.x && vCoordination.x < m_Rect.z && vCoordination.y >= m_Rect.y && vCoordination.y < m_Rect.w)
		{
			return true;
		}
		return false;
	}

	template<class TNodeExtraInfo>
	CQuadTreeNode<TNodeExtraInfo>::CQuadTreeNode(glm::u32vec4 vRect) : m_Rect(vRect)
	{
		m_Children.resize(MAXCHILDNUM);
	}

	template<class TNodeExtraInfo>
	void CQuadTreeNode<TNodeExtraInfo>::divideNode(glm::vec2 vCenter)
	{
		m_Center = vCenter;

		CQuadTreeNode<TNodeExtraInfo>* pNode;

		glm::u32vec4  RangeInNorthWest = glm::u32vec4(m_Rect.x, m_Rect.y, m_Center.x, m_Center.y);	
		glm::u32vec4  RangeInNorthEast = glm::u32vec4(m_Center.x, m_Rect.y, m_Rect.z, m_Center.y);
		glm::u32vec4  RangeInSouthWest = glm::u32vec4(m_Rect.x, m_Center.y, m_Center.x, m_Rect.w);
		glm::u32vec4  RangeInSouthEast = glm::u32vec4(m_Center.x, m_Center.y, m_Rect.z, m_Rect.w);

		pNode = new CQuadTreeNode<TNodeExtraInfo>(RangeInNorthWest);
		addChild(pNode, NorthWest);
		pNode = new CQuadTreeNode<TNodeExtraInfo>(RangeInNorthEast);
		addChild(pNode, NorthEast);
		pNode = new CQuadTreeNode<TNodeExtraInfo>(RangeInSouthWest);
		addChild(pNode, SouthWest);
		pNode = new CQuadTreeNode<TNodeExtraInfo>(RangeInSouthEast);
		addChild(pNode, SouthEast);
	}

	template<class TNodeExtraInfo>
	CQuadTreeNode<TNodeExtraInfo>::CQuadTreeNode(const TNodeExtraInfo& vData, glm::u32vec4 vRect) : m_Data(vData), m_Rect(vRect)
	{
		m_Children.resize(MAXCHILDNUM);
	}

	template<class TNodeExtraInfo>
	const CQuadTreeNode<TNodeExtraInfo>* CQuadTreeNode<TNodeExtraInfo>::getChildByCoordinate(glm::vec2 vCoordination) const
	{
		if (isLeafNode())
		{
			const CQuadTreeNode<TNodeExtraInfo>* pTempNode = this;
			return pTempNode;
		}
		if (vCoordination.x < m_Center.x)
		{
			if (vCoordination.y < m_Center.y)
			{
				return m_Children[NorthWest]->getChildByCoordinate(vCoordination);
			}
			else
				return m_Children[SouthWest]->getChildByCoordinate(vCoordination);
		}
		else
		{
			if (vCoordination.y < m_Center.y)
			{
				return m_Children[NorthEast]->getChildByCoordinate(vCoordination);
			}
			else
				return m_Children[SouthEast]->getChildByCoordinate(vCoordination);
		}
	}

	template<class TNodeExtraInfo>
	CQuadTreeNode<TNodeExtraInfo>* CQuadTreeNode<TNodeExtraInfo>::getChildByIndex(unsigned int vIndex) const
	{
		return m_Children[vIndex];
	}

	template<class TNodeExtraInfo>
	void CQuadTreeNode<TNodeExtraInfo>::deleteChild(unsigned int vIndex)
	{
		delete m_Children[vIndex];
		m_Children[vIndex] = NULL;
	}

	template<class TNodeExtraInfo>
	bool CQuadTreeNode<TNodeExtraInfo>::isLeafNode() const
	{
		for (auto& Child : m_Children)
		{
			if (Child)
			{
				return false;
			}
		}
		return true;
	}

	template<class TNodeExtraInfo>
	void CQuadTreeNode<TNodeExtraInfo>::clearChild()
	{
		for (size_t i=0; i<m_Children.size(); ++i)
		{
			delete m_Children[i];
			m_Children[i] = NULL;
		}
	}

	template<class TNodeExtraInfo>
	CQuadTreeNode<TNodeExtraInfo>::~CQuadTreeNode(void)
	{
	}

	template<class TNodeExtraInfo>
	CQuadTreeNode<TNodeExtraInfo>::CQuadTreeNode(void)
	{
		m_Children.resize(MAXCHILDNUM);
	}

	template<class TNodeExtraInfo>
	bool CQuadTreeNode<TNodeExtraInfo>::addChild(CQuadTreeNode* vChild, unsigned int vIndex)
	{
		if (vIndex >= MAXCHILDNUM || vIndex < MINCHILDNUM || !vChild)
		{
			return false;
		}
		if (m_Children[vIndex])
			delete m_Children[vIndex];

		m_Children[vIndex] = vChild;
		return true;
	}
}