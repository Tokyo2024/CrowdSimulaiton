#include "common/ConfigParser.h"
#include "SceneConfig.h"
#include "SimulationTools.h"

const int ExitLength = 10;
const int ThreholdPixel = 4;
const float Angel = 30;
const float M_PI = 3.1415926f;

using namespace hiveCrowdSimulation;

CSceneConfig::CSceneConfig()
{
	m_pImage = NULL;
	m_pImageData = NULL;
	m_Width = 0;
	m_Height = 0;
}

CSceneConfig::~CSceneConfig()
{
}

//********************************************************************
//FUNCTION:
glm::vec2 hiveCrowdSimulation::CSceneConfig::getExit(unsigned int vIndex) const
{
	_ASSERT(vIndex < getNumExit());

	return m_ExitSet[vIndex];
}

//********************************************************************
//FUNCTION:
void hiveCrowdSimulation::CSceneConfig::parseSceneImage(const std::string& vBitmapFile)
{
	_ASSERT(!vBitmapFile.empty());
	FreeImage_Initialise(TRUE);

	FREE_IMAGE_FORMAT Fif = FreeImage_GetFIFFromFilename(vBitmapFile.c_str());
	_ASSERT(Fif != FIF_UNKNOWN);
	m_pImage = FreeImage_Load(FIF_BMP, vBitmapFile.c_str(), BMP_DEFAULT);
	_ASSERT(m_pImage);

	m_pImage = FreeImage_ConvertTo8Bits(m_pImage);
	m_Width  = FreeImage_GetWidth(m_pImage);
	m_Height = FreeImage_GetHeight(m_pImage);
	m_pImageData = (char*)malloc(sizeof(char) * m_Width * m_Height);
	memcpy(m_pImageData, FreeImage_GetBits(m_pImage), m_Width * m_Height);

	__recognizeExit();
	FreeImage_Unload(m_pImage);
	FreeImage_DeInitialise();
}

////********************************************************************
////FUNCTION:
//bool* hiveCrowdSimulation::CSceneConfig::fetchSceneInfo(const std::string& vBitmapFile, int& voPWidth, int& voPHeight)
//{
//	//_ASSERT(!vBitmapFile.empty());
//	//FreeImage_Initialise(TRUE);
//	//FIBITMAP* pBitmap = FreeImage_Load(FIF_BMP, vBitmapFile.c_str(), BMP_DEFAULT);
//	//pBitmap   = FreeImage_ConvertTo8Bits(pBitmap);
//	//voPWidth  = FreeImage_GetWidth(pBitmap);
//	//voPHeight = FreeImage_GetHeight(pBitmap);
//	//bool* pBuffer = (bool*)malloc(sizeof(bool) * voPWidth * voPHeight);
//	//memcpy(pBuffer, FreeImage_GetBits(pBitmap), voPWidth * voPHeight);
//
//	//__setExit(glm::vec2(300, 100));
//	//__setExit(glm::vec2(400, 400));
//
//	//FreeImage_DeInitialise();
//
//	//return pBuffer;
//}

//********************************************************************
//FUNCTION:
void hiveCrowdSimulation::CSceneConfig::__recognizeExit()
{
	for (int i=0; i<m_Width; ++i)
	{
		for (int k=0; k<m_Height; ++k)
		{
			RGBQUAD CurrentPixelColor = __readPixelColor(glm::vec2(i, k));
			glm::vec3 CurrentPixelParsedColor = __transformColorFormat(CurrentPixelColor);
			if (CurrentPixelParsedColor != glm::vec3(255, 255, 255) && CurrentPixelParsedColor != glm::vec3(0, 0, 0))
			{
				//compute sample point set
				if (__isNecessary2ComputingSampleSet(glm::vec2(i, k)))
				{
					std::vector<glm::vec2> SamplePointSet;
					__computeSampleSet(glm::vec2(i, k), ExitLength, Angel, SamplePointSet);
					int NumEffectiveSamplePoint = 0;
					for (auto& SamplePoint : SamplePointSet)
					{
						RGBQUAD SamplePointColor = __readPixelColor(SamplePoint);
						glm::vec3 ParsedColor = __transformColorFormat(SamplePointColor);
						if (ParsedColor == CurrentPixelParsedColor)
						{
							++NumEffectiveSamplePoint;
						}
					}
					if (NumEffectiveSamplePoint == ThreholdPixel)
					{
						m_ExitSet.push_back(glm::vec2(i, k));
					}
				}
			}
		}
	}
}

//********************************************************************
//FUNCTION:
bool hiveCrowdSimulation::CSceneConfig::__isEffectivePos(const glm::vec2& vPos)
{
	return vPos.x >=0 && vPos.x < m_Width && vPos.y >=0 && vPos.y < m_Height;
}

//********************************************************************
//FUNCTION:
bool hiveCrowdSimulation::CSceneConfig::__isNecessary2ComputingSampleSet(const glm::vec2& vTargetPoint)
{
	_ASSERT(m_pImage);
	_ASSERT(__isEffectivePos(vTargetPoint));

	glm::vec2 LeftPoint = glm::vec2(vTargetPoint.x-1, vTargetPoint.y);
	glm::vec2 TopPoint  = glm::vec2(vTargetPoint.x, vTargetPoint.y-1);
	RGBQUAD TargetPointColor = __readPixelColor(vTargetPoint);
	glm::vec3 TargetPointParsedColor = __transformColorFormat(TargetPointColor);

	if (__isEffectivePos(LeftPoint))
	{
		RGBQUAD LeftPointColor = __readPixelColor(LeftPoint);
		glm::vec3 LeftPointParsedColor = __transformColorFormat(LeftPointColor);
		if (TargetPointParsedColor == LeftPointParsedColor)
		{
			return false;
		}
	}

	if (__isEffectivePos(TopPoint))
	{
		RGBQUAD TopPointColor = __readPixelColor(TopPoint);
		glm::vec3 TopPointParsedColor = __transformColorFormat(TopPointColor);
		if (TargetPointParsedColor == TopPointParsedColor)
		{
			return false;
		}
	}

	return true;
}

//********************************************************************
//FUNCTION:
RGBQUAD hiveCrowdSimulation::CSceneConfig::__readPixelColor(const glm::vec2& vPixelPos)
{
	_ASSERT(m_pImage);

	int ColorDepth = FreeImage_GetBPP(m_pImage);
	RGBQUAD Color;
	if (ColorDepth==16 || ColorDepth==24 || ColorDepth==32)
	{
		if (!FreeImage_GetPixelColor(m_pImage, vPixelPos.x, vPixelPos.y, &Color))
			printf("read fail.\n");
	}
	else if(ColorDepth==1 || ColorDepth==4 || ColorDepth==8)
	{
		BYTE Index;
		if (!FreeImage_GetPixelIndex(m_pImage, vPixelPos.x, vPixelPos.y, &Index))
			printf("read fail.\n");
		else
		{
			RGBQUAD* pPalette = (RGBQUAD*)FreeImage_GetPalette(m_pImage);
			Color = pPalette[Index];
		}
	}

	return Color;
}

//********************************************************************
//FUNCTION:
void hiveCrowdSimulation::CSceneConfig::__computeSampleSet(const glm::vec2& vCurPos, int vSampleRadius, int vSampleAngle, std::vector<glm::vec2>& voSamplePointSet)
{
	for (double Angle = 0.0; Angle <= 90.0; Angle+=vSampleAngle)
	{
		double Radian = Angle * M_PI / 180.0f;
		voSamplePointSet.push_back(vCurPos + glm::vec2(vSampleRadius*std::cos(Radian), vSampleRadius*std::sin(Radian)));
	}
}

//********************************************************************
//FUNCTION:
glm::vec3 hiveCrowdSimulation::CSceneConfig::__transformColorFormat(const RGBQUAD& vColor)
{
	return glm::vec3(vColor.rgbBlue, vColor.rgbGreen, vColor.rgbRed);
}