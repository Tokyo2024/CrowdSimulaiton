#include "Group.h"
#include <unordered_map>
#include "IAgent.h"
#include "Subgroup.h"
#include "SimulationTools.h"
#include "CrowdSimulationConfig.h"

using namespace hiveCrowdSimulation;

CGroup::CGroup(void)
{
 	CSubgroup* FirstSubgroup = new CSubgroup();
 	m_SubgroupSet.push_back(FirstSubgroup);
	m_NumGroupMembers = 0;
}

CGroup::~CGroup(void)
{
	for (unsigned int i=0; i<m_SubgroupSet.size(); ++i)
	{
		for (unsigned int k=0; k<m_SubgroupSet[i]->getNumSubgroupMembers(); ++k)
		{
			delete m_SubgroupSet[i]->fetchAgent(k);
		}
		delete m_SubgroupSet[i];
	}
}

//*******************************************************************
//FUNCTION:
void CGroup::initRelationship()
{
	_ASSERT(m_SubgroupSet.size() == 1); //a group only has one subgroup at begin.
	for (unsigned int i=0; i<m_NumGroupMembers-1; ++i)
		for (unsigned int k=i+1; k<m_NumGroupMembers; ++k)
		{
			SAgentRelationship* pRelationshipA = new SAgentRelationship();
			SAgentRelationship* pRelationshipB = new SAgentRelationship();
			pRelationshipA->Intimacy = getFloatRandom(0.0f, 1.0f);
			pRelationshipB->Intimacy = getFloatRandom(0.0f, 1.0f);
			CAgent* pAgentA = m_SubgroupSet[0]->fetchAgent(i);
			CAgent* pAgentB = m_SubgroupSet[0]->fetchAgent(k);
			pAgentA->addAgent2Relationship(pAgentB, pRelationshipA);
			pAgentB->addAgent2Relationship(pAgentA, pRelationshipB);
		}
}

//*******************************************************************
//FUNCTION:
void CGroup::addGroupMember(CAgent* vAgent)
{
	_ASSERT(m_SubgroupSet.size()>0);
	m_SubgroupSet[0]->addAgent(vAgent);
}

//*******************************************************************
//FUNCTION:
void CGroup::__updateSubgroupCenter()
{
	for (auto& Subgroup : m_SubgroupSet)
		Subgroup->updateCenter();
}

//********************************************************************
//FUNCTION:
void CGroup::__taskUpdatedDueToGiveUp()
{
	for (auto& FindingSubgroup : m_ExeFindingTaskSubgroupSet)
	{
		__updateAttention(FindingSubgroup);
		if (FindingSubgroup->getAttention() < 0.0) 
		{
			FindingSubgroup->finishTask();
			//Test
			std::cout << "Giving up." << std::endl;
		}
		const CAgent* pAgent = FindingSubgroup->fetchAgent(0);
		if (pAgent->isReachedGoal(pAgent->getGoal(), CCrowdSimulationConfig::getInstance()->getRadiusOfTempGoal()))
		{
			FindingSubgroup->finishTask();
		}
	}
}

//********************************************************************
//FUNCTION:
void CGroup::__taskUpdatedDueToFinished()
{
	if (m_ExeFindingTaskSubgroupSet.size() == 0)
		return ;
	
	int TaskSetSize = m_ExeFindingTaskSubgroupSet.size();
	for (int i=0; i<TaskSetSize-1; ++i)
		for (int k=i+1; k<TaskSetSize; ++k)
		{
			if (m_ExeFindingTaskSubgroupSet[i]->fetchAgent(0)->isAgentDirectInSight(m_ExeFindingTaskSubgroupSet[k]->fetchAgent(0)) && m_ExeFindingTaskSubgroupSet[i]->getTargetAgent() == m_ExeFindingTaskSubgroupSet[k]->getTargetAgent() && m_ExeFindingTaskSubgroupSet[i]->getToDoState() && m_ExeFindingTaskSubgroupSet[k]->getToDoState())
				m_ExeFindingTaskSubgroupSet[i]->getAttention() > m_ExeFindingTaskSubgroupSet[k]->getAttention() ? m_ExeFindingTaskSubgroupSet[k]->finishTask() : m_ExeFindingTaskSubgroupSet[i]->finishTask();														
		}
}

//*******************************************************************
//FUNCTION:
void CGroup::__updateAwareness()
{
	for (auto Subgroup : m_SubgroupSet)
		Subgroup->updateAwareness();
}

//*******************************************************************
//FUNCTION:
void CGroup::__updateTaskSet()
{
	__taskUpdatedDueToGiveUp();
	__taskUpdatedDueToFinished();

	std::vector<CSubgroup*> TempTaskSet;
	for (auto& TaskSubgroup : m_ExeFindingTaskSubgroupSet)
	{
		if (TaskSubgroup->getToDoState())
			TempTaskSet.push_back(TaskSubgroup);		
	}
	m_ExeFindingTaskSubgroupSet = TempTaskSet;
}

//*******************************************************************
//FUNCTION:
void CGroup::__splitSubgroup()
{
	std::vector<CSubgroup*> TempSubGroupSet;
	std::vector<CSubgroup*> SplitSubGroupSet;
	for (unsigned int i=0; i<m_SubgroupSet.size(); ++i)
	{
		m_SubgroupSet[i]->splitSubgroup(SplitSubGroupSet);
		TempSubGroupSet.insert(TempSubGroupSet.end(), SplitSubGroupSet.begin(), SplitSubGroupSet.end());
		if (SplitSubGroupSet.size() > 1)
			delete m_SubgroupSet[i];
	}
	m_SubgroupSet = TempSubGroupSet;
}

//*******************************************************************
//FUNCTION:
void CGroup::__mergeSubgroup()
{
	if (m_SubgroupSet.size() == 1)
		return ;
	
	std::vector<CSubgroup*> TaskSubGroupSet;
	std::vector<int> DisjointSet(m_SubgroupSet.size(), -1);
	for (unsigned int i=0; i<m_SubgroupSet.size()-1; ++i)
	{
		if (DisjointSet[i] == -1)
			DisjointSet[i] = i;
		for (unsigned int k=i+1; k<m_SubgroupSet.size(); ++k)
		{
			if (DisjointSet[k] == -1)
				DisjointSet[k] = k;
			if (m_SubgroupSet[i]->isAble2MergeThisSubgroupAndSetTaskFinishedIfNecessiry(m_SubgroupSet[k]))
			{
				if (DisjointSet[k] == -1)
					DisjointSet[k] = i;
				else
				{
					int RootA = k;
					while (DisjointSet[RootA] != RootA) RootA = DisjointSet[RootA];

					int RootB = i;
					while (DisjointSet[RootB] != RootB) RootB = DisjointSet[RootB];

					if (RootA != RootB)
						DisjointSet[RootA] = RootB;
					
					DisjointSet[k] = RootB;	
				}
			}			
		}
	}

	std::unordered_map<int, int> IndexMap;
	for (int i=0; i<DisjointSet.size(); ++i)
	{
		if (DisjointSet[i] == -1)
			continue;
		
		int k = i;		
		while (DisjointSet[k] != k) k = DisjointSet[k];
		DisjointSet[i] = k;

		if (IndexMap.find(k) == IndexMap.end())
		{
			IndexMap.insert(std::make_pair(k, 0));
			IndexMap[k] = IndexMap.size()-1;
		}
	}

	if (IndexMap.size() == m_SubgroupSet.size())
		return ;
	
	std::vector<CSubgroup*> MergedGroupSet(IndexMap.size(), NULL);
	for (int i=0; i<m_SubgroupSet.size(); ++i)
	{
		if (DisjointSet[i] == -1)
			continue;
		
		int Index = IndexMap[DisjointSet[i]];

		if (!MergedGroupSet[Index])
		{
			if (m_SubgroupSet[i]->getToDoState())
			{
				MergedGroupSet[Index] = m_SubgroupSet[i];
				continue;
			}
			MergedGroupSet[Index] = new CSubgroup();
			MergedGroupSet[Index]->setSubgroupState(true);
		}
		for (unsigned int k=0; k<m_SubgroupSet[i]->getNumSubgroupMembers(); ++k)
			MergedGroupSet[Index]->addAgent(m_SubgroupSet[i]->fetchAgent(k));
		
		if (m_SubgroupSet[i]->isNecessary2MakeDecision())
			MergedGroupSet[Index]->setNecessity2MakeDecision(true);
		
		
		delete m_SubgroupSet[i];
	}
	MergedGroupSet.insert(MergedGroupSet.end(), TaskSubGroupSet.begin(), TaskSubGroupSet.end());
	m_SubgroupSet = MergedGroupSet;

	if (m_ExeFindingTaskSubgroupSet.size() > 0)
	{
		m_ExeFindingTaskSubgroupSet.clear();
		for (auto& Subgroup : m_SubgroupSet)
		{
			if (Subgroup->getToDoState())
				m_ExeFindingTaskSubgroupSet.push_back(Subgroup);
		}
	}
}

//*******************************************************************
//FUNCTION:
void CGroup::__exchangeInfoBetweenAgent()
{
	for (unsigned int i=0; i<m_SubgroupSet.size(); ++i)
		m_SubgroupSet[i]->exchangeInfo();
}

//*******************************************************************
//FUNCTION:
void CGroup::__makeDecision()
{
	for (unsigned int i=0; i<m_SubgroupSet.size(); ++i)
	{
		if (m_SubgroupSet[i]->isNecessary2MakeDecision())
		{
			CSubgroup* pSubgroup = m_SubgroupSet[i]->generateTask();
			if (pSubgroup)
			{
				m_ExeFindingTaskSubgroupSet.push_back(pSubgroup);
				m_SubgroupSet.push_back(pSubgroup);
			}
			m_SubgroupSet[i]->setNecessity2MakeDecision(false);
		}
	}
}

//*******************************************************************
//FUNCTION:
void CGroup::__updateAttention(CSubgroup* vExeFindingTaskSubgroup)
{
	float Coefficient = 0.01f;	//1
	vExeFindingTaskSubgroup->updateTimeElapsed();

	_ASSERT(vExeFindingTaskSubgroup->getNumSubgroupMembers()>0);

	CAgent* pSrcAgent = vExeFindingTaskSubgroup->fetchAgent(0);
	float CurAttention = vExeFindingTaskSubgroup->getAttention();
	float CurDifficulty = pSrcAgent->computeDifficulty(vExeFindingTaskSubgroup->getTargetAgent());
	float CurTimeElapsed = vExeFindingTaskSubgroup->getTimeElapsed();
	CurAttention = CurAttention - Coefficient * CurTimeElapsed * CurDifficulty;
	vExeFindingTaskSubgroup->setAttention(CurAttention);
}

//********************************************************************
//FUNCTION:
void CGroup::updateStatus()
{
	__updateSubgroupCenter();
	__updateTaskSet(); 
	__splitSubgroup(); 
	__mergeSubgroup();
	__updateAwareness();
	__exchangeInfoBetweenAgent();
	__makeDecision();
}

//*******************************************************************
//FUNCTION:
void CGroup::updateFinishState(bool& voFlag)
{
	for (auto& Subgroup : m_SubgroupSet)
		Subgroup->updateFinishState(voFlag);
}

//********************************************************************
//FUNCTION:
CSubgroup* CGroup::fetchSubgroup(unsigned int vIndex) const
{
	_ASSERT(vIndex < m_SubgroupSet.size());
	return m_SubgroupSet[vIndex];
}

//********************************************************************
//FUNCTION:
CSubgroup* CGroup::fetchSearchingSubgroup(unsigned int vIndex) const
{
	_ASSERT(vIndex < m_ExeFindingTaskSubgroupSet.size());
	return m_ExeFindingTaskSubgroupSet[vIndex];
}

//********************************************************************
//FUNCTION:
void CGroup::clearSubgroupSet()
{
	for (auto& Subgroup : m_SubgroupSet)
		delete Subgroup;
	m_SubgroupSet.clear();
}

//********************************************************************
//FUNCTION:
void CGroup::clearTaskSet()
{
	for (auto& Task : m_ExeFindingTaskSubgroupSet)
		delete Task;

	m_ExeFindingTaskSubgroupSet.clear();
}

//********************************************************************
//FUNCTION:
void CGroup::addNormalSubgroup(CSubgroup* vSubgroup)
{
	_ASSERT(vSubgroup);
	m_SubgroupSet.push_back(vSubgroup);
}

//********************************************************************
//FUNCTION:
void CGroup::addSubgroup2ExecTaskSet(CSubgroup* vSub)
{
	_ASSERT(vSub);
	m_ExeFindingTaskSubgroupSet.push_back(vSub);
}

//********************************************************************
//FUNCTION:
void CGroup::fetchExeTaskAgent(std::vector<CAgent*>& voAgentSet) const
{
	for (auto& Sub : m_ExeFindingTaskSubgroupSet)
		for (unsigned int i=0; i<Sub->getNumSubgroupMembers(); ++i)
			voAgentSet.push_back(Sub->fetchAgent(i));
}