#include "IAgent.h"
#include <algorithm>
#include <math.h>
#include <boost/random.hpp>
#include "opencv2/opencv.hpp"
#include "RVOSimulator.h"
#include "AgentConfig.h"
#include "CrowdSimulationConfig.h"
#include "PrepareScene.h"
#include "SimulationTools.h"
#include "Scene.h"
#include "SubGroup.h"

using namespace hiveCrowdSimulation;

CAgent::CAgent(const glm::vec2& vDirection, float vSpeed, const glm::vec2& vPosition, CScene* vScene) : m_InitialDirection(vDirection), m_InitialSpeed(vSpeed), m_InitialPosition(vPosition), m_HasFoundExit(false), m_IsAwareness(true), m_pRVOAgent(NULL), m_GroupForce(glm::vec2(0, 0)), m_pScene(vScene), m_IsReachGoal(false), m_GroupID(-1), m_Ability(1.0) //1
{
}

CAgent::~CAgent()
{
	for (auto& AgentRelationship : m_AgentRelationshipSet)
	{
		delete AgentRelationship.second;
	}
	delete m_pRVOAgent;
}

//*******************************************************************
//FUNCTION:
void CAgent::setRVOAgent(RVO::Agent* vAgent)
{
	m_pRVOAgent = vAgent;
	m_pRVOAgent->setVelocity(m_InitialDirection);
	m_pRVOAgent->setMaxSpeed(m_InitialSpeed);
	m_pRVOAgent->setPosition(m_InitialPosition);
	m_pRVOAgent->setReachExit(false);
}

//*******************************************************************
//FUNCTION:
bool CAgent::isReachedGoal(const glm::vec2& vGoal, float vRadius) const
{
	return glm::distance(getPosition(), vGoal) < vRadius;
}

//*******************************************************************
//FUNCTION:
void CAgent::__generateInfluenceMatrix(const std::vector<glm::vec2>& vPosition, const std::vector<glm::vec2>& vVelocity)
{
	m_Martix.clear();
	glm::vec2 AverageVelocity = glm::vec2(0, 0);
	for (auto& Velocity : vVelocity)
		AverageVelocity += Velocity;
	
	AverageVelocity /= vVelocity.size();
	for (unsigned int i=0; i<vPosition.size(); ++i)
		m_Martix.push_back(glm::normalize(vPosition[i] - getPosition()) * __computeWeight(vPosition[i], vVelocity[i], AverageVelocity));	
}

//*******************************************************************
//FUNCTION:
float CAgent::__computeWeightOfDistance(const glm::vec2& vPosition) const
{
	return CCrowdSimulationConfig::getInstance()->getWeightOfDistance() / glm::distance(getPosition(), vPosition);
}

//*******************************************************************
//FUNCTION:
float CAgent::__computeWeightOfVelocity(const glm::vec2& vVelocity, const glm::vec2& vAverageVelocity) const
{
	return exp((-glm::distance(vVelocity, vAverageVelocity)) / CCrowdSimulationConfig::getInstance()->getWeightOfVelocity());
}

//*******************************************************************
//FUNCTION:
float CAgent::__computeWeightOfPosition(const glm::vec2& vPosition, const glm::vec2& vAverageVelocity) const
{
	glm::vec2 AverageVelocity = vAverageVelocity == glm::vec2(0, 0) ? vAverageVelocity : glm::normalize(vAverageVelocity);
	glm::vec2 Position        = glm::normalize(vPosition - getPosition());
	
	return exp(-glm::distance(Position, AverageVelocity) / CCrowdSimulationConfig::getInstance()->getWeightOfPosition());
}

//*******************************************************************
//FUNCTION:
float CAgent::__computeWeight(const glm::vec2& vPosition, const glm::vec2& vVelocity, const glm::vec2& vAverageVelocity)
{
	float WeightG =  m_IsAwareness ? CCrowdSimulationConfig::getInstance()->getWeightOfAwareness() : CCrowdSimulationConfig::getInstance()->getWeightOfIgnorance();
	return WeightG * __computeWeightOfDistance(vPosition) * __computeWeightOfVelocity(vVelocity, vAverageVelocity) * __computeWeightOfPosition(vPosition, vAverageVelocity);
}

//*******************************************************************
//FUNCTION:
glm::vec2 CAgent::__computeDirectionInflunecedByExternal()
{
// 	unsigned int i=0;
// 	for (; i<m_Martix.size(); ++i)
// 	{
// 		PointSet[i * 2 + 0] = m_Martix[i].x;
// 		PointSet[i * 2 + 1] = m_Martix[i].y;
// 	}
// 	for (i=i * 2 + 0; i<12; ++i)
// 	{
// 		PointSet[i] = 0;
// 	}
//	CvMat* pSamples[1];
//	CvMat* pSample = cvCreateMat(m_Martix.size(), 2, CV_32FC1);
//	CvMat* pCovMat = cvCreateMat(2, 2, CV_32FC1);
//	CvMat* pMeanMat = cvCreateMat(1, 2, CV_32FC1);
//	cvSetData(pSample, (void *)PointSet, pSample->step);
//	pSamples[0] = pSample;
//	cvCalcCovarMatrix((const CvArr**)pSamples, m_Martix.size(), pCovMat, pMeanMat, CV_COVAR_SCALE + CV_COVAR_NORMAL + CV_COVAR_ROWS);
	/*float ProVectorData[2][2] = { {0, 0}, {0, 0} };
	CvMat ProVector = cvMat(2, 2, CV_32FC1, ProVectorData);
	float ProValueData[2] = {0.0, 0.0};
	CvMat ProValue = cvMat(2, 1, CV_32FC1, ProValueData);
	CvMat* SrcMatrix = pCovMat;
	cvEigenVV(SrcMatrix, &ProVector, &ProValue, 1.0e-6F);

	cvReleaseMat(pSamples);
	cvDecRefData(&pSample);
	cvReleaseMat(&pCovMat);
	cvReleaseMat(&pMeanMat);
	cvDecRefData(&SrcMatrix);*/

		
	cv::Mat CovMat, MeanMat;
// 	cv::Mat Sample(6, 2, CV_32FC1, PointSet);
// 	CovMat.create(2, 2, CV_32FC1);
// 	MeanMat.create(1, 2, CV_32FC1);
	cv::Mat_<float> Sample[6];
	int i=0;
	for (; i<m_Martix.size(); ++i)
	{
		Sample[i].create(1, 2);
		Sample[i](0, 0) = m_Martix[i].x;
		Sample[i](0, 1) = m_Martix[i].y;
	}
	for (; i<6; ++i)
	{
		Sample[i].create(1, 2);
		Sample[i](0, 0) = 0;
		Sample[i](0, 1) = 0;
	}
	cv::calcCovarMatrix(Sample, 6, CovMat, MeanMat, CV_COVAR_NORMAL);

	cv::Mat ProVector;
	cv::Mat ProValue;
	cv::eigen(CovMat, ProValue, ProVector);
	float* p = ProVector.ptr<float>(0);
// 	float a = ProVector.at<float>(0, 0);
// 	float b = ProVector.at<float>(0, 1);
	float a = p[0];
	float b = p[1];

	return glm::normalize(glm::vec2(a, b));
}

//*******************************************************************
//FUNCTION:
float CAgent::__computeAttention(const CAgent* vAgent, float vTotalIntimacy)
{
	_ASSERT(vTotalIntimacy != 0);
	return m_Ability * (getIntimacy(vAgent) / vTotalIntimacy) / computeDifficulty(vAgent);
}

//*******************************************************************
//FUNCTION:
float CAgent::computeDifficulty(const CAgent* vAgent)
{   
	auto RelationshipIter = m_AgentRelationshipSet.find(vAgent);
	if (RelationshipIter != m_AgentRelationshipSet.end())
	{
		SAgentRelationship* pRelationship = RelationshipIter->second;
		return glm::distance(getPosition(), pRelationship->LastPosition) * (1+__computeCrowdDensity());
	}	
}

//*******************************************************************
//FUNCTION:
void CAgent::updateFinishState(bool& voFlag)
{
	unsigned int k=0;
	for (; k<CPrepareScene::getInstance()->getNumExit(); ++k)
	{
		if (isReachedGoal(CPrepareScene::getInstance()->getExit(k), CCrowdSimulationConfig::getInstance()->getRadiusOfGoal()))
		{
			setIsReachGoal();
			setReachExitsStatus(true);//by mawanfeng
			setPosition(CPrepareScene::getInstance()->getExit(k));
			setVelocity(glm::vec2(0.0, 0.0));
			break;
		}
	}
	if (k == CPrepareScene::getInstance()->getNumExit())
	{
		voFlag = false;
		setReachExitsStatus(false);
	}
}

//*******************************************************************
//FUNCTION:
float CAgent::__computeCrowdDensity()
{
	float Sum = 0.0f;
	float NumOfGrid = 0.0f;
	
	const CQuadTreeNode<SNode>* pNode = m_pScene->getLeafNodeBySceneCoord(getPosition());
	CSceneGrid* pGrid = m_pScene->fetchSceneGrid(pNode);
	
	if (pNode->getExtraInfo().Passability == PASS)
	{
		Sum = pGrid->getCrowdDensity();
		NumOfGrid = pNode->getWidth() * pNode->getHeight();
	}
	
	return Sum / NumOfGrid;
}

//*******************************************************************
//FUNCTION:
glm::vec2 CAgent::computeIgnoranceVelocity(const std::vector<glm::vec2>& vPosition, const std::vector<glm::vec2>& vVelocity)
{
 	__generateInfluenceMatrix(vPosition, vVelocity);
 	glm::vec2 VelocityByExternal = __computeDirectionInflunecedByExternal();

	std::vector<float> IndexSet;
	std::vector<glm::vec2> DirectorySet;
	const CQuadTreeNode<SNode>* pNode = m_pScene->getLeafNodeBySceneCoord(getPosition());

	float Angle = 0.0f;
	const CQuadTreeNode<SNode>* pTempNode;
	while ((Angle += 10.0f) < 360.0f) //1
	{
		glm::vec2 Velocity = rotateVector(getVelocity(), Angle);
		glm::vec2 TempPosition = getPosition() + (Velocity + VelocityByExternal) * CCrowdSimulationConfig::getInstance()->getAdvanceTime();
		/*float Offset = CCrowdSimulationConfig::getInstance()->getAttribute<float>(OFFSET); 
		TempPosition = glm::vec2(std::max(Offset, std::min(TempPosition.x, m_pScene->getSceneWidth() - getRadius())), std::max(Offset, std::min(TempPosition.y, m_pScene->getSceneHeight() - getRadius())));*/
		if (TempPosition.x < 1 || TempPosition.x > m_pScene->getSceneWidth() - 1 || TempPosition.y < 1 || TempPosition.y > m_pScene->getSceneHeight() - 1) continue;
		pTempNode = m_pScene->getLeafNodeBySceneCoord(TempPosition);
		if (pNode == pTempNode) continue;
		if (pTempNode->getExtraInfo().Passability == PASS)
		{
			DirectorySet.push_back(Velocity);
			float Possbility = (Angle >= 270.0f) || (Angle <= 90.0f) ? 3.0 : 1.0;//magic number
			IndexSet.push_back(Possbility);
		}
	}

	int Index = choseByRoulette(IndexSet);
	return DirectorySet[Index] + VelocityByExternal;	
}

//*******************************************************************
//FUNCTION:
bool CAgent::isAgentDirectInSight(const CAgent* vAgent)
{
	if (glm::distance(getPosition(), vAgent->getPosition()) < CAgentConfig::getInstance()->getNeighborDist())
		return m_pScene->isVisible(this->getPosition(), vAgent->getPosition(), CAgentConfig::getInstance()->getVisualRange());
	else
		return false;
}

//*******************************************************************
//FUNCTION:
void CAgent::exchangeInfo(const CAgent* vAnotherAgent)
{
	_ASSERT(vAnotherAgent);

	fetchRelationship(vAnotherAgent)->LastPosition   = vAnotherAgent->getPosition();
	fetchRelationship(vAnotherAgent)->LastCheckTime  = m_pRVOAgent->getGlobalTime();
	
	vAnotherAgent->fetchRelationship(this)->LastCheckTime = m_pRVOAgent->getGlobalTime();
	vAnotherAgent->fetchRelationship(this)->LastPosition  = getPosition();
	for (auto& AgentAndRelationship : m_AgentRelationshipSet)
	{
		if (AgentAndRelationship.first == vAnotherAgent)
			continue;

		if (AgentAndRelationship.second->LastCheckTime > vAnotherAgent->fetchRelationship(AgentAndRelationship.first)->LastCheckTime)
		{
			vAnotherAgent->fetchRelationship(AgentAndRelationship.first)->LastCheckTime = AgentAndRelationship.second->LastCheckTime;
			vAnotherAgent->fetchRelationship(AgentAndRelationship.first)->LastPosition  = AgentAndRelationship.second->LastPosition;
		}
		else
		{
			AgentAndRelationship.second->LastCheckTime = vAnotherAgent->fetchRelationship(AgentAndRelationship.first)->LastCheckTime;
			AgentAndRelationship.second->LastPosition  = vAnotherAgent->fetchRelationship(AgentAndRelationship.first)->LastPosition;
		}
	}
}

//*******************************************************************
//FUNCTION:
SAgentRelationship* CAgent::fetchRelationship(const CAgent* vAgent) const
{
	_ASSERT(vAgent);
	return m_AgentRelationshipSet.find(vAgent) != m_AgentRelationshipSet.end() ? m_AgentRelationshipSet.find(vAgent)->second : NULL;
}

//*******************************************************************
//FUNCTION:
void CAgent::setIsReachGoal()
{
	m_IsReachGoal = true; 
	setVelocity(glm::vec2(0, 0));
	m_Roadmap.clear();
	m_Roadmap.push_back(getGoal());
}

//*******************************************************************
//FUNCTION:
float CAgent::getIntimacy(const CAgent* vAgent) const
{
	_ASSERT(vAgent);

	SAgentRelationship* pRelationship = fetchRelationship(vAgent);
	_ASSERT(pRelationship);
	return pRelationship->Intimacy;
}

//*******************************************************************
//FUNCTION:
bool CAgent::generateTargetCandidate(SCost2FindSomeone* voCandidate, CSubgroup* vSubgroup)
{
	float MaxAttention = FLT_MIN;
	bool Flag = false;
	float TotalIntimacy = 0.0f;
	for (unsigned int i=0; i<vSubgroup->getNumSubgroupMembers(); ++i)
	{
		CAgent* pTempAgent = vSubgroup->fetchAgent(i);
		if (pTempAgent != this)
			TotalIntimacy += this->getIntimacy(pTempAgent);
	}
	for (auto AgentRelationship : m_AgentRelationshipSet)
	{
		const CAgent* pAgent = AgentRelationship.first;
		if (!(this->isAgentDirectInSight(pAgent) || vSubgroup->isAgentInThisSubgroup(pAgent) || glm::distance(getPosition(), getGoal()) >= glm::distance(pAgent->getPosition(), pAgent->getGoal()))) // || AgentRelationship.first->isAwareness())
		{
			float TempAttention = __computeAttention(AgentRelationship.first, TotalIntimacy);
			if (TempAttention > 0.0f && TempAttention > MaxAttention)
			{				
				voCandidate->pTargetAgent = AgentRelationship.first;
				voCandidate->Attention = TempAttention;
				Flag = true;
			}
		}
	}

	return Flag;
}

//*******************************************************************
//FUNCTION:
void CAgent::setToFinishTask()
{
	m_TempGoal = getPosition();
	setGoalPos(m_GoalPosition);
}

//*******************************************************************
//FUNCTION:
void CAgent::setToDoTask(const CAgent* vAgent)
{
//	m_TempGoal = getPosition();
	m_TempGoal = m_AgentRelationshipSet[vAgent]->LastPosition;
	m_GoalPosition = getGoal();
//	setGoalPos(m_AgentRelationshipSet[vAgent]->LastPosition);
}

//********************************************************************
//FUNCTION:
void CAgent::addAgent2Relationship(const CAgent* vAgent, SAgentRelationship* vRelationship)
{
	_ASSERT(vAgent);
	_ASSERT(vRelationship);
	if (!__isExistRelationshipWithAgent(vAgent))
		m_AgentRelationshipSet.insert(std::make_pair(vAgent, vRelationship));
	else
		m_AgentRelationshipSet[vAgent] = vRelationship;
}

//********************************************************************
//FUNCTION:
bool CAgent::__isExistRelationshipWithAgent(const CAgent* vAgent) const
{
	_ASSERT(vAgent);
	return m_AgentRelationshipSet.count(vAgent);
}

//*******************************************************************
//FUNCTION:
void CAgent::setReachExitsStatus(bool vIsReachExit)
{
	m_IsReachExit = vIsReachExit;
	m_pRVOAgent->setReachExit(vIsReachExit);
}