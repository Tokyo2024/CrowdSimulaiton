#pragma once
#include "common/Singleton.h"
#include "SimulationTools.h"
#include "Visualization.h"
#include "Scene.h"

namespace hiveCrowdSimulation
{
	class CGraphWithoutCrowd;
	class CSceneGrid;
	class CGraphWithCrowd;
	class CCrowdSimulation;
	class CBestNextFinding;
	class CAgent;
	class CSubgroup;
	class CGroup;

	using namespace hiveCrowdRendering;

	class CFramework : public hiveCommon::CSingleton<CFramework>
	{
	public:
		~CFramework();
		
		void displayingSimulationResultByOpenCV(const std::string& vRunConfig, const std::string& vSimulationResult);
		void displayingSimulationResultByOpenGL(const std::string& vSimulationInfo, const std::string& vSimulationResult);
		void initFramework(const std::string& vAgentInfo, const std::string& vSceneInfo, const std::string& vSimulationInfo);
		void runCrowdSimulation(bool vIsOutputPosInfo2File);

		void initAgentConfig(const std::string& vAgentInfo);
		void initSimulationConfig(const std::string& vSimulationInfo);
		void initVisualization(float vWidth, float vHeight, const glm::vec3& vBackColor);
		//Sprint_9
		void initVisualization(float vWidth, float vHeight, const std::string& vSceneModelPath);
		//end_9
		void initAgentAndSimulationConfig(const std::string& vSceneInfo, const std::string& vSimulationInfo);
		void writePositionInfo2File(const std::string& vFileName, const glm::vec2& vPos);

		void clearScreen();
		void display();
		void drawScene(bool vIsShowSceneGrid) const;
		void drawScene(CVisualization* vVisualize, const std::vector<const CQuadTreeNode<SNode>*> vTreeNodeSet, const glm::vec3& vPassColor, const glm::vec3& vObstacleColor);
		void drawPath(const std::vector<glm::vec2>& vPointSet, float vRadius, const glm::vec3& vColor) const;
		void drawPoint(const glm::vec2& vCoord, float vRadius, const glm::vec3& vColor, bool vIsFilled) const;
		void drawLine(const glm::vec2& vPointA, const glm::vec2& vPointB, float vLineThickness, const glm::vec3& vLineColor);
		void drawRectangle(const glm::vec2& vLeftTop, const glm::vec2& vRightBottom, const glm::vec3& vColor, bool vIsFilled) const;
		void drawRoadMapSet(const std::vector<std::vector<glm::vec2>>& vRoadSet, const glm::vec3& vColor) const;
		void displayExit() const;

		void computeGridCoordBetweenTwoGrids(const glm::vec2& vArrayCoordA, const glm::vec2& vArrayCoordB, std::vector<glm::vec2>& voResult) const;
		void deleteAgentFromGrid(const glm::vec2& vCoord);
		void executeKNNSearch(const std::vector<glm::vec2>& vDataSet, const glm::vec2& vData, unsigned int vNumOptimalNeighbor, std::vector<unsigned int>& voOptimalNeighborSet) const;
		void findShortestPathUseDijkstra(bool vIsCrowdDensityConsidered, const glm::vec2& vStart, const glm::vec2& vEnd, double& voLength, std::vector<glm::vec2>& voResults) const;
		void findShortestPath(bool vIsConsiderCrowdDensity, const glm::vec2& vStart, const glm::vec2& vEnd, std::vector<glm::vec2>& voSceneCoordSet) const;
		void genCrowdAndAdd2CrowdSimulation();
		void genCrowdAndAdd2CrowdSimulationAtSpecificArea(const glm::vec2& vCenter, unsigned int vRadius, unsigned int vNumNotGroupMembers, bool vIsAware);
		void parseAndGenScene(const std::string& vBitmapFile);
		void genGraph();
		void genGraph(bool vIsCrowdDensityConsidered);
		float getEdgeWeight(const glm::vec2& vScenePosA, const glm::vec2& vScenePosB);
		void initSimulator();
		bool testVisibility(const glm::vec2& vSource, const glm::vec2& vTarget, float vRadius);
		bool testPassibility(const glm::vec2& vGrid);
		void resetEdgeWeight(const glm::vec2& vPosA, const glm::vec2& vPosB, double vLength, bool vIsCrowdDensityConsidered);
		void updateGraphWithCrowd(const glm::vec2& vCoord);
		void updateGraphWithCrowd();

		double queryEdgeWeight(const glm::vec2& vPosA, const glm::vec2& vPosB, bool vIsCrowdDensityConsidered) const;
		void displayCrowdDistribution();
		void splitGroup(const std::vector<std::vector<glm::vec2>>& vGroupAgentPosSet, const std::string& vRunConfig, int& voNumSugroup);
		void mergeGroup(const std::vector<std::vector<glm::vec2>>& vGroupAgentPosSet, const std::string& vRunConfig, int& voNumSugroup);
		void startMakeDecision(const std::vector<glm::vec2>& vSubgroupPosSet, const glm::vec2& vLostPos, const std::vector<float>& vIntimacySet, const std::string& vRunConfig, int& voNumTask);
		void giveUpFindingLostAgent(const glm::vec2& vPosSrc, const glm::vec2& vPosDst, const std::string& vRunConfig, bool& voIsGivingUp);
		void finishFindingLostAgent(const glm::vec2& vPosSrc, const glm::vec2& vPosDst, const std::string& vRunConfig);
		void clashBetweenGroups(const glm::vec2& vGroupAPos, unsigned int vGroupASize, const glm::vec2& vGroupBPos, unsigned int vGroupBSize, const std::string& vRunConfig);

		CScene* getScene() const {return m_pScene;}
		hiveCrowdRendering::CVisualization* getVisualization() const {return m_pVisulization;}
		const CGraphWithCrowd* getGraphWithCrowd() const {return m_pGraphWithCrowd;}
		const CGraphWithoutCrowd* getGraphWithoutCrowd() const {return m_pGraphWithoutCrowd;}
		//Sprint_9
		void drawSphere(const glm::vec2& vCoord, float vRadius, const glm::vec3& vColor) const;
		void drawCylinder(const glm::vec2& vCoord, float vRadius, const glm::vec3& vColor) const;

	protected:
		CFramework();
		
		void _drawExeTaskGroupMember(const CGroup* vGroup, const glm::vec3& vExeColor) const;
		void _drawSubgroup(CSubgroup* vSubgroup, const glm::vec3& vSubgrooupColor) const;
		void _drawGroup(CGroup* vGroup, const glm::vec3& vGroupColor) const;
		void _drawGroup(CGroup* vGroup, const glm::vec3& vGroupColor, const glm::vec3& vExeTaskGroupMemberColor) const;
		void _drawGroup(CGroup* vGroup, const glm::vec3* vColors, const glm::vec3& vExeTaskGroupMemberColor) const;
		void _parseConfigFilesOpenCV(const std::string& vRunConfig);
		void _parseConfigFilesOpenGL(const std::string& vRunConfig);
		void _prepare(const std::string& vRunConfig);
		void _prepareProcess4FindingLostAgent(const glm::vec2& vPosSrc, const glm::vec2& vPosDst, const std::string& vRunConfig);
		void _prepareProcess4ClashBetweenGroups(const glm::vec2& vGroupAPos, unsigned int vGroupASize, const glm::vec2& vGroupBPos, unsigned int vGroupBSize, const std::string& vRunConfig);
		void _updateVisualScene();
		CAgent*	   _genAgent(const glm::vec2& vPos, CScene* vScene);
		CSubgroup* _genSubgroupWithPos(const std::vector<glm::vec2>& vSubgroupMemberPosSet);
		CGroup*    _initGroupWithPosData(const std::vector<std::vector<glm::vec2>>& vGroupAgentPosSet);

	private:
		bool                    m_IsScenePrepared;
		bool                    m_IsInit;
		CScene*                 m_pScene;
		CBestNextFinding*       m_pBestNextFinding;
		CCrowdSimulation*       m_pCrowdSimulation;
		CGraphWithCrowd*        m_pGraphWithCrowd;
		CGraphWithoutCrowd*     m_pGraphWithoutCrowd;
		hiveCrowdRendering::CVisualization* m_pVisulization;

		friend class hiveCommon::CSingleton<CFramework>;
	};
}