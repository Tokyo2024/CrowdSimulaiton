#pragma once
#include <string>
#include <GLM/glm.hpp>
#include "common/HiveConfig.h"
#include "common/Singleton.h"
#include "SimulationExport.h"

namespace hiveCrowdSimulation
{
	//Agent
	const std::string IAGENTCONFIG	   = "IAgentConfig";
	const std::string OFFSET           = "Offset";
	const std::string TIMESTEP         = "TimeStep";
	const std::string ADVANCETIME      = "AdvanceTime";
	const std::string RADIUSOFGOAL     = "RadiusOfGoal";
	const std::string RADIUSOFTEMPGOAL = "RadiusOfTempGoal";
	const std::string NEIGHBOURNUM	   = "NeighbourNum";
	const std::string PROCEEDINGTIME   = "ProceedingTime";

	//Group
	const std::string GROUPCONFIG			 = "GroupConfig";
	const std::string WEIGHTOFDISTANCE		 = "WeightOfDistance";
	const std::string WEIGHTOFVELOCITY		 = "WeightOfVelocity";
	const std::string WEIGHTOFPOSITION		 = "WeightOfPosition";
	const std::string WEIGHTOFAWARENESS		 = "WeightOfAwareness";
	const std::string WEIGHTOFIGNORANCE		 = "WeightOfIgnorance";
	const std::string FLOORLIMITMEMBERS		 = "FloorLimitOfMembers";
	const std::string UPPERLIMITMEMBERS		 = "UpperLimitOfMembers";
	const std::string GROUPFORCE			 = "GroupCohesionForce";
	const std::string WEIGHTOFTARGETFORCE	 = "WeightOfTargetForce";
	const std::string WEIGHTOFCOGESIONFORCE	 = "WeightOfGroupCohesionForce";
	const std::string WEIGHTOFGROUPAWARENESSFORCE  = "WeightOfGroupAwarenessForce";

	//Scene
	const std::string ISCENECONFIG			 = "ISceneConfig";
	const std::string DIMENSION              = "Dimension";
	const std::string BASENODEDEEP			 = "BaseNodeDeep";
	const std::string MINNODEDEEP			 = "MinNodeDeep";

	//Display
	const std::string DISPLAYCONFIG		= "DisplayConfig";
	const std::string BACKCOLOR         = "BGColor";
	const std::string EXITCOLOR         = "ExitColor";
	const std::string PASSABLECOLOR     = "PassableColor";
	const std::string OBSTACLECOLOR     = "ImpassableColor";
	const std::string AGENTCOLOR        = "AgentColor";
	const std::string ISSHOWSCENEGRID   = "IsShowSceneGrid";

	//Run
	const std::string RUNCONFIG				   = "RunConfig";
	const std::string NUMAGENT				   = "NumAgent";
	const std::string NUMGROUP                 = "NumGroup";
	const std::string AGENTSNOTBELONGEDTOGROUP = "AgentsNotBelongedToGroup";
	const std::string AWARENESSPERCENTAGE	   = "AwarenessPercentage";
	const std::string IGNORANCEPERCENTAGE	   = "IgnorancePercentage";
	const std::string SIMULATIONRESULTFILE	   = "SimulationResultFile";
	const std::string ISCROWDPOSSPECIFIED	   = "IsCrowdPosSpecified";
	const std::string PATHFINDINGALGORITHM	   = "PathFindingAlgorithm";
	//const std::string UPDATESCENETIME        = "UpdateSceneTime";

	//sprint 5:
	const std::string CROWDPOSFILE        = "CrowdPosFile";
	//const std::string BASENODEWIDTH       = "BaseNodeWidth";
	//const std::string BASENODEHEIGHT      = "BaseNodeHeight";
	//const std::string MINLEAFNODEWIDTH    = "MinLeafNodeWidth";
	//const std::string MINLEAFNODEHEIGHT   = "MinLeafNodeHeight";
	//const std::string COSTTHRESHOLD       = "CostThreshold";
	//const std::string DISTTHREHOLD        = "DistThrehold";

	//Sprint_9
	const std::string SCENEMODEL		  = "SceneModel";
	const std::string SCENEWIDTH		  = "SceneWidth";
	const std::string SCENEHEIGHT		  = "SceneHeight";
	const std::string AWAREAGENTMODEL	  = "AwareAgentModel";
	const std::string IGNOREAGENTMODEL	  = "IgnoreAgentModel";
	const std::string SCENEVERTEX		  = "SceneVertex";
	const std::string SCENEFRAG			  = "SceneFrag";
	const std::string AGENTVERTEX		  = "AgentVertex";
	const std::string AGENTFRAG			  = "AgentFrag";

	class CCrowdSimulationConfig : public hiveConfig::CHiveConfig, public hiveCommon::CSingleton<CCrowdSimulationConfig>
	{
	public:
		virtual ~CCrowdSimulationConfig();

		virtual bool parserV(const std::string& vCrowdSimulationInfo);

		float getOffset()						 const {return getAttribute<float>(OFFSET);}
		float getTimeStep()                      const {return getAttribute<float>(TIMESTEP);}
		float getAdvanceTime()                   const {return getAttribute<float>(ADVANCETIME);}
		float getRadiusOfGoal()                  const {return getAttribute<float>(RADIUSOFGOAL);}
		float getRadiusOfTempGoal()              const {return getAttribute<float>(RADIUSOFTEMPGOAL);}
		unsigned int getNeighbourNum()			 const {return getAttribute<int>(NEIGHBOURNUM);}
		unsigned int getProceedingTime()         const {return getAttribute<int>(PROCEEDINGTIME);}

		float getWeightOfDistance()			     const {return getAttribute<float>(WEIGHTOFDISTANCE);} 
		float getWeightOfVelocity()				 const {return getAttribute<float>(WEIGHTOFVELOCITY);} 
		float getWeightOfPosition()				 const {return getAttribute<float>(WEIGHTOFPOSITION);} 
		float getWeightOfAwareness()             const {return getAttribute<float>(WEIGHTOFAWARENESS);} 
		float getWeightOfIgnorance()             const {return getAttribute<float>(WEIGHTOFIGNORANCE);} 
		int   getFloorLimitMembers()			 const {return getAttribute<int>(FLOORLIMITMEMBERS);}
		int   getUpperLimitMembers()			 const {return getAttribute<int>(UPPERLIMITMEMBERS);}
		std::string getGroupForceType()			 const {return getAttribute<std::string>(GROUPFORCE);}
		std::string getPathFindingAlgorithm()	 const {return getAttribute<std::string>(PATHFINDINGALGORITHM);}
		float getWeightOfTargetForce()			 const {return getAttribute<float>(WEIGHTOFTARGETFORCE);}
		float getWeightOfGroupCohesionForce()	 const {return getAttribute<float>(WEIGHTOFCOGESIONFORCE);}
		float getWeightOfGroupAwarenessForce()	 const {return getAttribute<float>(WEIGHTOFGROUPAWARENESSFORCE);}

		float getDimension()                     const {return getAttribute<int>(DIMENSION);}
		int   getBaseNodeDeep()					 const {return getAttribute<int>(BASENODEDEEP);}
		int   getMinNodeDeep()					 const {return getAttribute<int>(MINNODEDEEP);}

		glm::vec3 getBackgroundColor() const;
		glm::vec3 getExitColor()	   const;
		glm::vec3 getPassableColor()   const;
		glm::vec3 getObstacleColor()   const;
		glm::vec3 getAgentColor()	   const;

		int   getAgentNum()                   const {return getAttribute<int>(NUMAGENT);}
		int   getGroupNum()					  const {return getAttribute<int>(NUMGROUP);}
		int   getAgentsNotBelongedToGroup()	  const {return getAttribute<int>(AGENTSNOTBELONGEDTOGROUP);}
		float getAwarenessPercentage()        const {return getAttribute<float>(AWARENESSPERCENTAGE);}
		float getIgnorancePercentage()        const {return getAttribute<float>(IGNORANCEPERCENTAGE);}
		std::string getSimulationResultFile() const {return getAttribute<std::string>(SIMULATIONRESULTFILE);}
		//unsigned int getUpdateSceneTime()        const {return getAttribute<int>(UPDATESCENETIME);}

		/*int getBaseNodeWidth()	   const {return getAttribute<int>(BASENODEWIDTH);}
		int getBaseNodeHeight()	   const {return getAttribute<int>(BASENODEHEIGHT);}
		int getMinLeafNodeWidth()  const {return getAttribute<int>(MINLEAFNODEWIDTH);}
		int getMinLeafNodeHeight() const {return getAttribute<int>(MINLEAFNODEHEIGHT);}*/

		int getSceneWidth()				  const {return getAttribute<int>(SCENEWIDTH);}
		int getSceneHeight()			  const {return getAttribute<int>(SCENEHEIGHT);}
		std::string getSceneModel()		  const {return getAttribute<std::string>(SCENEMODEL);}
		std::string getAwareAgentModel()  const {return getAttribute<std::string>(AWAREAGENTMODEL);}
		std::string getIgnoreAgentModel() const {return getAttribute<std::string>(IGNOREAGENTMODEL);}
		std::string getSceneVertex()	  const {return getAttribute<std::string>(SCENEVERTEX);}
		std::string getSceneFrag()		  const {return getAttribute<std::string>(SCENEFRAG);}
		std::string getAgentVertex()	  const {return getAttribute<std::string>(AGENTVERTEX);}
		std::string getAgentFrag()		  const {return getAttribute<std::string>(AGENTFRAG);}

	protected:
		CCrowdSimulationConfig();
		void _loadDefaultV() override;
		void _onLoadedV() override;
		void _defineAcceptableAttributeSet();

	private:
		glm::vec3 __fetchColor(const std::string& vName) const;
		friend class hiveCommon::CSingleton<CCrowdSimulationConfig>;
	};
}