#include "FrameWork.h"
#include <fstream>
#include "AgentConfig.h"
#include "RunConfig.h"
#include "Scene.h"
//#include "AStar.h"
#include "PathFindingAlgorithmFactoryData.h"
#include "Group.h"
#include "Subgroup.h"
#include "IAgent.h"
#include "Subgroup.h"
#include "QuadTree.h"
#include "QuadTreeNode.h"
#include "KNNSearch.h"
#include "PrepareScene.h"
#include "CrowdSimulationConfig.h"
#include "GraphWithoutCrowd.h"
#include "GraphWithCrowd.h"
#include "CrowdSimulation.h"
#include "VisualizationByOpenCV.h"
#include "VisualizationByOpenGL.h"
#include "AgentGenerator.h"
#include "SimulationTools.h"
#include "BestNextFinding.h"

using namespace hiveCrowdSimulation;

CFramework::CFramework() : m_IsInit(false), m_IsScenePrepared(false)
{
}

CFramework::~CFramework()
{
	delete m_pGraphWithoutCrowd;
	delete m_pGraphWithCrowd;
	delete m_pScene;
	delete m_pCrowdSimulation;
	delete m_pVisulization;
}

//*******************************************************************
//FUNCTION:
void CFramework::initFramework(const std::string& vAgentInfo, const std::string& vSceneInfo, const std::string& vSimulationInfo)
{
	_ASSERT(!vAgentInfo.empty() && !vSceneInfo.empty() && !vSimulationInfo.empty());
	initAgentConfig(vAgentInfo);
	initSimulationConfig(vSimulationInfo);
	parseAndGenScene(vSceneInfo);

	initSimulator();
	initVisualization(m_pScene->getSceneWidth(), m_pScene->getSceneHeight(), CCrowdSimulationConfig::getInstance()->getBackgroundColor());

	if (CCrowdSimulationConfig::getInstance()->getAttribute<bool>(ISCROWDPOSSPECIFIED))
	{
		std::string PosFile = CCrowdSimulationConfig::getInstance()->getAttribute<std::string>(CROWDPOSFILE);
		std::ifstream Fin(PosFile);
		unsigned int NumAgent = 0;
		Fin >> NumAgent;
		while (!Fin.eof())
		{
			glm::vec2 Pos;
			bool IsAwareness;
			int GroupID;
			Fin >> Pos.x >> Pos.y >> IsAwareness >> GroupID;
			_ASSERT(m_pCrowdSimulation);
			m_pCrowdSimulation->initAgentWithSpecifiedInfo(Pos, IsAwareness, GroupID);
		}
		Fin.close();
	}
	else
	{
		genCrowdAndAdd2CrowdSimulation();
	}

	genGraph();
	m_pCrowdSimulation->setGraph(m_pGraphWithoutCrowd, m_pGraphWithCrowd);
	m_IsInit = true;
}

//********************************************************************
//FUNCTION:
void CFramework::initSimulator()
{
	m_pCrowdSimulation = new CCrowdSimulation();
	m_pCrowdSimulation->setScene(m_pScene);	
	m_pCrowdSimulation->initSimulator();
	m_pCrowdSimulation->addObstacleToRVO();
}

//********************************************************************
//FUNCTION:
void hiveCrowdSimulation::CFramework::genCrowdAndAdd2CrowdSimulation()
{
	unsigned int NumTotalAgent      = CCrowdSimulationConfig::getInstance()->getAgentNum();
	unsigned int NumIgnorantAgent   = NumTotalAgent * CCrowdSimulationConfig::getInstance()->getIgnorancePercentage();
	unsigned int NumNotGroupMembers = CCrowdSimulationConfig::getInstance()->getAgentsNotBelongedToGroup();
	unsigned int NumGroups          = CCrowdSimulationConfig::getInstance()->getGroupNum();
	unsigned int MinNumGroupMembers = CCrowdSimulationConfig::getInstance()->getFloorLimitMembers();
	unsigned int MaxNumGroupMembers = CCrowdSimulationConfig::getInstance()->getUpperLimitMembers();

	m_pCrowdSimulation->initCrowdDistribution(NumTotalAgent, NumIgnorantAgent, NumNotGroupMembers, NumGroups, MinNumGroupMembers, MaxNumGroupMembers);
}

//********************************************************************
//FUNCTION:
void hiveCrowdSimulation::CFramework::genCrowdAndAdd2CrowdSimulationAtSpecificArea(const glm::vec2& vCenter, unsigned int vRadius, unsigned int vNumNotGroupMembers, bool vIsAware)
{
	_ASSERT(vRadius > 0);
	_ASSERT(vNumNotGroupMembers > 0);

	m_pCrowdSimulation->addCrowdDistributionAtSpecificArea(vCenter, vRadius, vNumNotGroupMembers, vIsAware);
}

//********************************************************************
//FUNCTION:
void hiveCrowdSimulation::CFramework::runCrowdSimulation(bool vIsOutputPosInfo2File)
{
	if (m_IsInit)
	{
		std::ofstream Fout;
		if (vIsOutputPosInfo2File)
		{
			Fout = std::ofstream(CCrowdSimulationConfig::getInstance()->getSimulationResultFile(), std::ios_base::app);
			Fout << m_pCrowdSimulation->getNumAgent() << std::endl;
		}

		GroupColorPool.clear();
		while (!m_pCrowdSimulation->isFinished())
		{
			m_pCrowdSimulation->advance();
			if (vIsOutputPosInfo2File)
			{
				for (unsigned int i=0; i<m_pCrowdSimulation->getNumNoGroupMembers(); ++i)
				{
					CAgent* pAgent = m_pCrowdSimulation->getNoGroupMembers(i);
					writeAgentInfo2File(pAgent, Fout);
				}

				for (unsigned int i=0; i<m_pCrowdSimulation->getNumGroups(); ++i)
				{
					CGroup* pGroup = m_pCrowdSimulation->getGroup(i);
					for (unsigned int k=0; k<pGroup->getNumSubgroup(); ++k)
					{
						CSubgroup* pSubgroup = pGroup->fetchSubgroup(k);
						for (unsigned int AgentIndex=0; AgentIndex<pSubgroup->getNumSubgroupMembers(); ++AgentIndex)
						{
							writeAgentInfo2File(pSubgroup->fetchAgent(AgentIndex), Fout);
						}
					}
				}
			}
			_updateVisualScene();
		}
		Fout.close();
	}
}

//********************************************************************
//FUNCTION:
void CFramework::drawScene(bool vIsShowSceneGrid) const
{
	_ASSERT(m_pScene && m_pVisulization);

	std::vector<const CQuadTreeNode<SNode>*> LeafNodeSet;
	m_pScene->dumpAllLeafNode(LeafNodeSet);
	CFramework::getInstance()->drawScene(m_pVisulization, LeafNodeSet, CCrowdSimulationConfig::getInstance()->getPassableColor(), CCrowdSimulationConfig::getInstance()->getObstacleColor());
}

//********************************************************************
//FUNCTION:
void CFramework::drawScene(CVisualization* vVisualize, const std::vector<const CQuadTreeNode<SNode>*> vTreeNodeSet, const glm::vec3& vPassColor, const glm::vec3& vObstacleColor)
{
	_ASSERT(vVisualize);

	for (auto& LeafNode : vTreeNodeSet)
	{
		EPassibility LeafNodePassInfo = LeafNode->getExtraInfo().Passability;
		glm::vec4 Rectangle = LeafNode->getRectangle();

		glm::vec3 Color = (LeafNodePassInfo == PASS) ? vPassColor : vObstacleColor;
		vVisualize->drawRectangle(glm::vec2(Rectangle.x, Rectangle.y), glm::vec2(Rectangle.z, Rectangle.w), Color, !CCrowdSimulationConfig::getInstance()->getAttribute<bool>(ISSHOWSCENEGRID));
	}
}

//********************************************************************
//FUNCTION:
void CFramework::resetEdgeWeight(const glm::vec2& vPosA, const glm::vec2& vPosB, double vLength, bool vIsCrowdDensityConsidered)
{
	vIsCrowdDensityConsidered ? m_pGraphWithCrowd->updateEdgeWeight(vPosA, vPosB, vLength) : m_pGraphWithoutCrowd->updateEdgeWeight(vPosA, vPosB, vLength);
}

//*******************************************************************
//FUNCTION:
void CFramework::_updateVisualScene()
{
	clearScreen();
	drawScene(CCrowdSimulationConfig::getInstance()->getAttribute<bool>(ISSHOWSCENEGRID));
	displayExit();
	displayCrowdDistribution();
	display();
}

//********************************************************************
//FUNCTION:
void CFramework::initVisualization(float vWidth, float vHeight, const glm::vec3& vBackColor)
{
	cv::Scalar BackColor = cv::Scalar(vBackColor.x, vBackColor.y, vBackColor.z);
	m_pVisulization      = new hiveCrowdRendering::CVisualizationByOpenCV(vWidth, vHeight, BackColor);
}

//********************************************************************
//FUNCTION:
void CFramework::initVisualization(float vWidth, float vHeight, const std::string& vSceneModelPath)
{
	m_pVisulization = new hiveCrowdRendering::CVisualizationByOpenGL(vWidth, vHeight, vSceneModelPath);
}

//********************************************************************
//FUNCTION:
void CFramework::clearScreen()
{
	_ASSERT(m_pVisulization);
	m_pVisulization->clearScene();
}

//********************************************************************
//FUNCTION:
void CFramework::display()
{
	_ASSERT(m_pVisulization);
	m_pVisulization->display();
}

//********************************************************************
//FUNCTION:
void CFramework::drawPath(const std::vector<glm::vec2>& vPointSet, float vRadius, const glm::vec3& vColor) const
{
	_ASSERT(m_pVisulization);
	for (auto& Point : vPointSet)
		m_pVisulization->drawPoint(Point, vRadius, vColor, true);
}

//********************************************************************
//FUNCTION:
void CFramework::genGraph(bool vIsCrowdDensityConsidered)
{
	_ASSERT(m_pScene);

	if (vIsCrowdDensityConsidered)
	{
		m_pGraphWithCrowd = new CGraphWithCrowd(m_pScene);
		m_pGraphWithCrowd->genGraph(m_pScene);
	}
	else
	{
		m_pGraphWithoutCrowd = new CGraphWithoutCrowd();
		m_pGraphWithoutCrowd->genGraph(m_pScene);
	}
}

//*******************************************************************
//FUNCTION:
void CFramework::genGraph()
{
	_ASSERT(m_pScene);

	m_pGraphWithCrowd = new CGraphWithCrowd(m_pScene);
	m_pGraphWithoutCrowd = new CGraphWithoutCrowd;
	m_pGraphWithCrowd->genGraph(m_pScene);
	m_pGraphWithoutCrowd->genGraph(m_pScene);
}

//*******************************************************************
//FUNCTION:
double CFramework::queryEdgeWeight(const glm::vec2& vPosA, const glm::vec2& vPosB, bool vIsCrowdDensityConsidered) const
{
	const CQuadTreeNode<SNode>* pNodeA = m_pScene->getLeafNodeBySceneCoord(vPosA);
	const CQuadTreeNode<SNode>* pNodeB = m_pScene->getLeafNodeBySceneCoord(vPosB);
	glm::vec2 NodeA = pNodeA->getCenter();
	glm::vec2 NodeB = pNodeB->getCenter();
	return vIsCrowdDensityConsidered ? m_pGraphWithCrowd->getEdgeWeight(NodeA, NodeB) : m_pGraphWithoutCrowd->getEdgeWeight(NodeA, NodeB);
}

//********************************************************************
//FUNCTION:
bool CFramework::testVisibility(const glm::vec2& vSource, const glm::vec2& vTarget, float vRadius)
{
	_ASSERT(m_pScene);
	return m_pScene->isVisible(vSource, vTarget, vRadius);
}

//********************************************************************
//FUNCTION:
void CFramework::findShortestPath(bool vIsConsiderCrowdDensity, const glm::vec2& vStart, const glm::vec2& vEnd, std::vector<glm::vec2>& voSceneCoordSet) const
{
	const CQuadTreeNode<SNode>* pNodeA = m_pScene->getLeafNodeBySceneCoord(vStart);
	const CQuadTreeNode<SNode>* pNodeB = m_pScene->getLeafNodeBySceneCoord(vEnd);
	glm::vec2 Start = pNodeA->getCenter();
	glm::vec2 End   = pNodeB->getCenter();
	CPathFindingAlgorithm* pPathFinding = dynamic_cast<CPathFindingAlgorithm*>(CPathFindingAlgorithmFactoryData::getInstance()->createPathFindingAlgorithm(CCrowdSimulationConfig::getInstance()->getPathFindingAlgorithm()));
	vIsConsiderCrowdDensity ? pPathFinding->findShortestPathV(m_pGraphWithCrowd, Start, End, voSceneCoordSet) : pPathFinding->findShortestPathV(m_pGraphWithoutCrowd, Start, End, voSceneCoordSet);
	delete pPathFinding;
}

//********************************************************************
//FUNCTION:
void CFramework::findShortestPathUseDijkstra(bool vIsCrowdDensityConsidered, const glm::vec2& vStart, const glm::vec2& vEnd, double& voLength, std::vector<glm::vec2>& voResults) const
{
	const CQuadTreeNode<SNode>* pNodeA = m_pScene->getLeafNodeBySceneCoord(vStart);
	const CQuadTreeNode<SNode>* pNodeB = m_pScene->getLeafNodeBySceneCoord(vEnd);
	glm::vec2 Start = pNodeA->getCenter();
	glm::vec2 End   = pNodeB->getCenter();
	vIsCrowdDensityConsidered ? m_pGraphWithCrowd->findShortestPathUseDijkstra(Start, End, voLength, voResults) : m_pGraphWithoutCrowd->findShortestPathUseDijkstra(Start, End, voLength, voResults);
}

//********************************************************************
//FUNCTION:
void CFramework::initAgentAndSimulationConfig(const std::string& vAgentInfo, const std::string& vSimulationInfo)
{
	_ASSERT(!vAgentInfo.empty() && !vSimulationInfo.empty());

	initAgentConfig(vAgentInfo);
	initSimulationConfig(vSimulationInfo);

	if (m_pCrowdSimulation == NULL)
		m_pCrowdSimulation = new CCrowdSimulation();

	m_pCrowdSimulation->initSimulator();
}

//********************************************************************
//FUNCTION:
void CFramework::computeGridCoordBetweenTwoGrids(const glm::vec2& vArrayCoordA, const glm::vec2& vArrayCoordB, std::vector<glm::vec2>& voResult) const
{
	_ASSERT(m_pScene);
	m_pScene->computeGridCoordBetweenTwoGrids(vArrayCoordA, vArrayCoordB, voResult);
}

//********************************************************************
//FUNCTION:
void CFramework::drawPoint(const glm::vec2& vCoord, float vRadius, const glm::vec3& vColor, bool vIsFilled) const
{
	_ASSERT(m_pVisulization);
	m_pVisulization->drawPoint(vCoord, vRadius, vColor, vIsFilled);
}

//********************************************************************
//FUNCTION:
void CFramework::drawLine(const glm::vec2& vPointA, const glm::vec2& vPointB, float vLineThickness, const glm::vec3& vLineColor)
{
	_ASSERT(m_pVisulization);
	m_pVisulization->drawLine(vPointA, vPointB, vLineColor, vLineThickness);
}

//********************************************************************
//FUNCTION:
void CFramework::drawRectangle(const glm::vec2& vLeftTop, const glm::vec2& vRightBottom, const glm::vec3& vColor, bool vIsFilled) const
{
	_ASSERT(m_pVisulization);
	m_pVisulization->drawRectangle(vLeftTop, vRightBottom, vColor, vIsFilled);
}

//********************************************************************
//FUNCTION:
void CFramework::drawRoadMapSet(const std::vector<std::vector<glm::vec2>>& vRoadSet, const glm::vec3& vColor) const
{
	for (unsigned int i=0; i<vRoadSet.size(); ++i)
	{
		for (unsigned int k=0; k<vRoadSet[i].size()-1; ++k)
		{
			m_pVisulization->drawPoint(vRoadSet[i][k], CAgentConfig::getInstance()->getRadius(), vColor, false);
		}
	}
}

//********************************************************************
//FUNCTION:
void CFramework::displayingSimulationResultByOpenCV(const std::string& vRunConfig, const std::string& vSimulationResult)
{
	_ASSERT(!vRunConfig.empty());
	_parseConfigFilesOpenCV(vRunConfig);

	_ASSERT(m_pScene);
	CFramework::getInstance()->initVisualization(m_pScene->getSceneWidth(), m_pScene->getSceneHeight(), CCrowdSimulationConfig::getInstance()->getBackgroundColor());
	std::ifstream Fin(vSimulationResult);
	unsigned int NumAgent = 0;
	Fin >> NumAgent;
	GroupColorPool.clear();

	while (!Fin.eof())
	{
		clearScreen();
		drawScene(false);
		for (unsigned int i=0; i<NumAgent; i++)
		{
			glm::vec2 Pos;
			bool IsAwareness;
			int GroupID;
			Fin >> Pos.x >> Pos.y >> IsAwareness >> GroupID;
			glm::vec3 AgentColor;
			if (GroupID >= 0)
			{
				if (GroupID >= GroupColorPool.size())
				{
					glm::vec3 TempGroupColor = glm::vec3(getFloatRandom(0.0, 255.0), getFloatRandom(0.0, 255.0), getFloatRandom(0.0, 255.0)); //1
					GroupColorPool.push_back(TempGroupColor);
				}
				AgentColor = GroupColorPool[GroupID];
			}
			else
			{
				AgentColor = CCrowdSimulationConfig::getInstance()->getAgentColor();
			}

			if (IsAwareness)
			{
				drawPoint(Pos, CAgentConfig::getInstance()->getRadius(), AgentColor, true);
			}
			else
			{
				glm::vec2 RectLeftUp, RectRightDown;
				computeRectDiagonal(Pos, CAgentConfig::getInstance()->getRadius(), RectLeftUp, RectRightDown);
				drawRectangle(RectLeftUp, RectRightDown, AgentColor, true);
			}
		}
		display();
	}
}

//********************************************************************
//FUNCTION:
void CFramework::displayingSimulationResultByOpenGL(const std::string& vRunConfig, const std::string& vSimulationResult)
{
	_ASSERT(!vRunConfig.empty());
	_parseConfigFilesOpenGL(vRunConfig);
	
	CFramework::getInstance()->initVisualization(1024, 1024, CCrowdSimulationConfig::getInstance()->getSceneModel());
	_ASSERT(m_pVisulization);
	
	std::ifstream Fin(vSimulationResult);
	unsigned int NumAgent = 0;
	Fin >> NumAgent;
	GroupColorPool.clear();

	while (!Fin.eof())
	{
		clearScreen();
		for (unsigned int i=0; i<NumAgent; i++)
		{
			glm::vec2 Pos;
			bool IsAwareness;
			int GroupID;
			Fin >> Pos.x >> Pos.y >> IsAwareness >> GroupID;
			glm::vec3 AgentColor;
			if (GroupID >= 0)
			{
				if (GroupID >= GroupColorPool.size())
				{
					glm::vec3 TempGroupColor = glm::vec3(getFloatRandom(0.0, 1.0), getFloatRandom(0.0, 1.0), getFloatRandom(0.0, 1.0));
					GroupColorPool.push_back(TempGroupColor);
				}
				AgentColor = GroupColorPool[GroupID];
			}
			else
				AgentColor = CCrowdSimulationConfig::getInstance()->getAgentColor();

			if (IsAwareness)
				drawCylinder(Pos, CAgentConfig::getInstance()->getRadius(), AgentColor);
			else
				drawSphere(Pos, CAgentConfig::getInstance()->getRadius(), AgentColor);
		}
		display();
	}
}

//********************************************************************
//FUNCTION:
void CFramework::initAgentConfig(const std::string& vAgentInfo)
{
	CAgentConfig::getInstance()->parseV(vAgentInfo);
}

//********************************************************************
//FUNCTION:
void CFramework::initSimulationConfig(const std::string& vSimulationInfo)
{
	CCrowdSimulationConfig::getInstance()->parserV(vSimulationInfo);
}

//********************************************************************
//FUNCTION:
void CFramework::executeKNNSearch(const std::vector<glm::vec2>& vDataSet, const glm::vec2& vData, unsigned int vNumOptimalNeighbor, std::vector<unsigned int>& voOptimalNeighborSet) const
{
	CKNNSearch* pKNNSearch = new CKNNSearch();
	pKNNSearch->initKNNSearch(vDataSet, CCrowdSimulationConfig::getInstance()->getDimension(), vNumOptimalNeighbor);
	pKNNSearch->executeKNN(vData, voOptimalNeighborSet);
	delete pKNNSearch;
}

//********************************************************************
//FUNCTION:
void CFramework::deleteAgentFromGrid(const glm::vec2& vCoord)
{
	_ASSERT(m_pScene);
	const CQuadTreeNode<SNode>* pNode = m_pScene->getLeafNodeBySceneCoord(vCoord);
	CSceneGrid* pGrid = m_pScene->fetchSceneGrid(pNode);
	pGrid->deleteCrowd();
}

//********************************************************************
//FUNCTION:
void CFramework::updateGraphWithCrowd(const glm::vec2& vCoord)
{
	_ASSERT(m_pGraphWithCrowd);
	_ASSERT(m_pScene);

	const CQuadTreeNode<SNode>* pNode = m_pScene->getLeafNodeBySceneCoord(vCoord);
	m_pGraphWithCrowd->updateGraph4SpecifiedGrid(pNode->getCenter());
}

//********************************************************************
//FUNCTION:
void CFramework::updateGraphWithCrowd()
{
	_ASSERT(m_pGraphWithCrowd);
	m_pGraphWithCrowd->updateGraph();
}

//********************************************************************
//FUNCTION:
float CFramework::getEdgeWeight(const glm::vec2& vScenePosA, const glm::vec2& vScenePosB)
{
	_ASSERT(m_pGraphWithCrowd);
	_ASSERT(m_pScene);

	glm::vec2 NodePosIndexA = m_pScene->getLeafNodeBySceneCoord(vScenePosA)->getCenter();
	glm::vec2 NodePosIndexB = m_pScene->getLeafNodeBySceneCoord(vScenePosB)->getCenter();

	return m_pGraphWithCrowd->getEdgeWeight(NodePosIndexA, NodePosIndexB);
}

//********************************************************************
//FUNCTION:
void CFramework::displayExit() const
{
	_ASSERT(m_pVisulization);

	for (unsigned int i=0; i<CPrepareScene::getInstance()->getNumExit(); ++i)
	{
		m_pVisulization->drawPoint(CPrepareScene::getInstance()->getExit(i), CAgentConfig::getInstance()->getRadius(), CCrowdSimulationConfig::getInstance()->getExitColor(), true);
	}
}

//*******************************************************************
//FUNCTION:
bool CFramework::testPassibility(const glm::vec2& vGrid)
{
	_ASSERT(m_pScene);
	return m_pScene->getLeafNodeBySceneCoord(vGrid)->getExtraInfo().Passability == PASS ? true : false;
}

//********************************************************************
//FUNCTION:
void CFramework::displayCrowdDistribution()
{
	_ASSERT(m_pCrowdSimulation);
	if (CCrowdSimulationConfig::getInstance()->getAgentNum() < 0)
		return;
	int NumGroup = m_pCrowdSimulation->getNumGroups();
	if (m_pCrowdSimulation->getNumGroups() != GroupColorPool.size())
	{
		for (unsigned int i=0; i<m_pCrowdSimulation->getNumGroups(); ++i)
		{
			GroupColorPool.push_back(glm::vec3(getFloatRandom(0.0, 255.0), getFloatRandom(0.0, 255.0), getFloatRandom(0.0, 255.0)));
		}
	}
	_ASSERT(NumGroup == GroupColorPool.size());
	for (unsigned int i=0; i<NumGroup; ++i)
	{
		CGroup* pGroup = m_pCrowdSimulation->getGroup(i);
		_drawGroup(pGroup, GroupColorPool[i], GroupColorPool[i]);
	}

	glm::vec3 Color = CCrowdSimulationConfig::getInstance()->getAgentColor();
	for (unsigned int i=0; i<m_pCrowdSimulation->getNumNoGroupMembers(); i++)
	{
		CAgent* pAgent = m_pCrowdSimulation->getNoGroupMembers(i);
		//test
		if (pAgent->getIndex() == 5)
		{
		if (pAgent->isAwareness())
		{
		drawPoint(pAgent->getPosition(), CAgentConfig::getInstance()->getRadius(), glm::vec3(0, 0, 255), true);
		continue;
		}
		else
		{
		glm::vec2 RectLeftUp, RectRightDown;
		hiveCrowdSimulation::computeRectDiagonal(pAgent->getPosition(), CAgentConfig::getInstance()->getRadius(), RectLeftUp, RectRightDown);
		drawRectangle(RectLeftUp, RectRightDown, glm::vec3(0, 0, 255), true);
		continue;
		}
		}
		if (pAgent->isAwareness())
		{
			drawPoint(pAgent->getPosition(), CAgentConfig::getInstance()->getRadius(), Color, true);
		}
		else
		{
			glm::vec2 RectLeftUp, RectRightDown;
			computeRectDiagonal(pAgent->getPosition(), CAgentConfig::getInstance()->getRadius(), RectLeftUp, RectRightDown);
			drawRectangle(RectLeftUp, RectRightDown, Color, true);
		}
	}
}

//********************************************************************
//FUNCTION:
CAgent* CFramework::_genAgent(const glm::vec2& vPos, CScene* vScene)
{
	_ASSERT(vScene);

	CAgent* pAgent = new CAgent(glm::vec2(), 2.0, vPos, vScene);
	pAgent->setRVOAgent(new RVO::Agent());
	pAgent->setPosition(vPos);

	return pAgent;
}

//********************************************************************
//FUNCTION:
CSubgroup* CFramework::_genSubgroupWithPos(const std::vector<glm::vec2>& vSubgroupMemberPosSet)
{
	_ASSERT(m_pScene);

	CSubgroup* pSubgroup = new CSubgroup();
	for (auto& Pos : vSubgroupMemberPosSet)
	{
		pSubgroup->addAgent(_genAgent(Pos, m_pScene));
	}

	return pSubgroup;
}

//********************************************************************
//FUNCTION:
CGroup* CFramework::_initGroupWithPosData(const std::vector<std::vector<glm::vec2>>& vGroupAgentPosSet)
{
	CGroup* pGroup = new CGroup();
	pGroup->clearSubgroupSet();

	for (unsigned int i=0; i<vGroupAgentPosSet.size(); i++)
	{
		CSubgroup* pSubgroup = _genSubgroupWithPos(vGroupAgentPosSet[i]);
		pGroup->addNormalSubgroup(pSubgroup);
	}

	return pGroup;
}

//********************************************************************
//FUNCTION:
void CFramework::splitGroup(const std::vector<std::vector<glm::vec2>>& vGroupAgentPosSet, const std::string& vRunConfig, int& voNumSugroup)
{
	_ASSERT(!vRunConfig.empty());

	_parseConfigFilesOpenCV(vRunConfig);
	CGroup* pGroup = _initGroupWithPosData(vGroupAgentPosSet);
	pGroup->__splitSubgroup();
	voNumSugroup = pGroup->getNumSubgroup();

	_ASSERT(m_pScene);
	initVisualization(m_pScene->getSceneWidth(), m_pScene->getSceneHeight(), CCrowdSimulationConfig::getInstance()->getBackgroundColor());
	drawScene(true);
	_drawGroup(pGroup, GroupColorArray[0], ExeTaskGroupColor[0]);
	m_pVisulization->display();

	delete pGroup;
}

//********************************************************************
//FUNCTION:
void CFramework::mergeGroup(const std::vector<std::vector<glm::vec2>>& vGroupAgentPosSet, const std::string& vRunConfig, int& voNumSugroup)
{
	_ASSERT(!vRunConfig.empty());

	_parseConfigFilesOpenCV(vRunConfig);
	CGroup* pGroup = _initGroupWithPosData(vGroupAgentPosSet);
	pGroup->__mergeSubgroup();
	voNumSugroup = pGroup->getNumSubgroup();

	_ASSERT(m_pScene);
	initVisualization(m_pScene->getSceneWidth(), m_pScene->getSceneHeight(), CCrowdSimulationConfig::getInstance()->getBackgroundColor());
	drawScene(true);
	_drawGroup(pGroup, GroupColorArray[0], ExeTaskGroupColor[0]);
	m_pVisulization->display();

	delete pGroup;
}

//********************************************************************
//FUNCTION:
void CFramework::_drawGroup(CGroup* vGroup, const glm::vec3& vGroupColor, const glm::vec3& vExeTaskGroupMemberColor) const
{
	_ASSERT(vGroup);

	for (unsigned int i=0; i<vGroup->getNumSubgroup(); i++)
	{
		CSubgroup* pSubgroup = vGroup->fetchSubgroup(i);
		for (unsigned int k=0; k<pSubgroup->getNumSubgroupMembers(); k++)
		{
			CAgent* pAgent = pSubgroup->fetchAgent(k);
			if (pAgent->isAwareness())
			{
				m_pVisulization->drawPoint(pAgent->getPosition(), CAgentConfig::getInstance()->getRadius(), vGroupColor, true);
			}
			else
			{
				glm::vec2 RectLeftUp, RectRightDown;
				computeRectDiagonal(pAgent->getPosition(), CAgentConfig::getInstance()->getRadius(), RectLeftUp, RectRightDown);
				m_pVisulization->drawRectangle(RectLeftUp, RectRightDown, vGroupColor, true);
			}
		}
	}
	_drawExeTaskGroupMember(vGroup, vExeTaskGroupMemberColor);
}

//********************************************************************
//FUNCTION:
void CFramework::_drawGroup(CGroup* vGroup, const glm::vec3* vColors, const glm::vec3& vExeTaskGroupMemberColor) const
{
	_ASSERT(vGroup);
	for (unsigned int i=0; i<vGroup->getNumSubgroup(); i++)
		_drawSubgroup(vGroup->fetchSubgroup(i), vColors[i]);

	_drawExeTaskGroupMember(vGroup, vExeTaskGroupMemberColor);
}

//********************************************************************
//FUNCTION:
void CFramework::_drawGroup(CGroup* vGroup, const glm::vec3& vGroupColor) const
{
	_ASSERT(vGroup);
	for (unsigned int i=0; i<vGroup->getNumSubgroup(); i++)
		_drawSubgroup(vGroup->fetchSubgroup(i), vGroupColor);
}

//********************************************************************
//FUNCTION:
void CFramework::_drawSubgroup(CSubgroup* vSubgroup, const glm::vec3& vSubgrooupColor) const
{
	_ASSERT(vSubgroup);

	for (unsigned int k=0; k<vSubgroup->getNumSubgroupMembers(); k++)
	{
		CAgent* pAgent = vSubgroup->fetchAgent(k);
		m_pVisulization->drawPoint(pAgent->getPosition(), CAgentConfig::getInstance()->getRadius(), vSubgrooupColor, true);
	}
}

//********************************************************************
//FUNCTION:
void CFramework::startMakeDecision(const std::vector<glm::vec2>& vSubgroupPosSet, const glm::vec2& vLostPos, const std::vector<float>& vIntimacySet, const std::string& vRunConfig, int& voNumTask)
{
	_ASSERT(!vRunConfig.empty());
	_ASSERT(vSubgroupPosSet.size() > 0);
	_ASSERT(vIntimacySet.size() > 0);

	_parseConfigFilesOpenCV(vRunConfig);
	CGroup* pGroup = new CGroup;
	pGroup->clearSubgroupSet();
	pGroup->clearTaskSet();

	CSubgroup* pSubgroup4LostAgent = new CSubgroup;
	CAgent* pLostAgent = _genAgent(vLostPos, m_pScene);
	pSubgroup4LostAgent->addAgent(pLostAgent);
	pGroup->addNormalSubgroup(pSubgroup4LostAgent);

	CSubgroup* pSubgroup = new CSubgroup;
	for (size_t i=0; i<vSubgroupPosSet.size(); ++i)
	{
		CAgent* pAgent = _genAgent(vSubgroupPosSet[i], m_pScene);//
		SAgentRelationship* pRelationship = new SAgentRelationship();
		pRelationship->Intimacy = vIntimacySet[i];
		pRelationship->LastPosition = vLostPos;
		pAgent->addAgent2Relationship(pLostAgent, pRelationship);
		pSubgroup->addAgent(pAgent);
	}
	pSubgroup->setDefaultIntimacy();

	pSubgroup->setNecessity2MakeDecision(true);
	pGroup->addNormalSubgroup(pSubgroup);

	pGroup->__makeDecision();
	voNumTask = pGroup->getTaskSize();

	_ASSERT(m_pScene);
	initVisualization(m_pScene->getSceneWidth(), m_pScene->getSceneHeight(), CCrowdSimulationConfig::getInstance()->getBackgroundColor());
	drawScene(true);
	_drawGroup(pGroup, GroupColorArray[0], ExeTaskGroupColor[0]);
	m_pVisulization->display();

	delete pGroup;
}

//********************************************************************
//FUNCTION:
void CFramework::_prepareProcess4FindingLostAgent(const glm::vec2& vPosSrc, const glm::vec2& vPosDst, const std::string& vRunConfig)
{
	_ASSERT(!vRunConfig.empty());
	_prepare(vRunConfig);
	genGraph();
	m_pCrowdSimulation->setGraph(m_pGraphWithoutCrowd, m_pGraphWithCrowd);

	_ASSERT(m_pScene);

	float DefaultSpeed = CAgentConfig::getInstance()->getMaxSpeed();
	glm::vec2 DefaultDirection = glm::vec2(getIntRandom(-1, 1), getIntRandom(-1, 1));

	CAgent* pAgentDst  = new CAgent(DefaultDirection, DefaultSpeed, vPosDst, m_pScene);
	pAgentDst->setAwareness(true);
	const CQuadTreeNode<SNode>* pNodeDst = m_pScene->getLeafNodeBySceneCoord(vPosDst);
	CSceneGrid* pGridDst = m_pScene->fetchSceneGrid(pNodeDst);
	pGridDst->addAgent(pAgentDst);

	CAgent* pAgentSrc  = new CAgent(glm::vec2(getIntRandom(-1, 1), getIntRandom(-1, 1)), DefaultSpeed, vPosSrc, m_pScene);
	pAgentSrc->setAwareness(true);
	const CQuadTreeNode<SNode>* pNodeSrc = m_pScene->getLeafNodeBySceneCoord(vPosSrc);
	CSceneGrid* pGridSrc = m_pScene->fetchSceneGrid(pNodeSrc);
	pGridSrc->addAgent(pAgentSrc);

	CGroup* pGroup = new CGroup();
	m_pCrowdSimulation->addGroup2GroupSet(pGroup);

	if (pGroup->getNumSubgroup() > 0)
		pGroup->clearSubgroupSet();
	m_pCrowdSimulation->dumpGroup4TestingSearchTask(pAgentSrc, pAgentDst, pGroup);

	SAgentRelationship* pRelationship2Dst = new SAgentRelationship();
	pRelationship2Dst->Intimacy = 0.5;
	pRelationship2Dst->LastPosition = vPosDst;
	pAgentSrc->addAgent2Relationship(pAgentDst, pRelationship2Dst);

	SAgentRelationship* pRelationship2Src = new SAgentRelationship();
	pRelationship2Src->Intimacy = 0.5;
	pRelationship2Src->LastPosition = vPosSrc;
	pAgentDst->addAgent2Relationship(pAgentSrc, pRelationship2Src);

	int TimeElapsed = 0;
	float Attention = 2000.0;
	STaskInfo* pAgentSrcFindDstTaskInfo = new STaskInfo(pAgentDst, TimeElapsed, Attention);
	_ASSERT(pGroup->getTaskSize() > 0);
	CSubgroup* pSubgroupSrc = pGroup->fetchSearchingSubgroup(0); //search task is executed by this subgroup
	pSubgroupSrc->setToDoTask(pAgentSrcFindDstTaskInfo);
}

//********************************************************************
//FUNCTION:
void CFramework::_prepareProcess4ClashBetweenGroups(const glm::vec2& vGroupAPos, unsigned int vGroupASize, const glm::vec2& vGroupBPos, unsigned int vGroupBSize, const std::string& vRunConfig)
{
	_ASSERT(!vRunConfig.empty());
	_prepare(vRunConfig);
	_ASSERT(m_pScene);

	float DefaultSpeed = CAgentConfig::getInstance()->getMaxSpeed();
	CAgentGenerator* pAgentGenerator = new CAgentGenerator();
	RVO::RVOSimulator* pRVOSimulator = m_pCrowdSimulation->getRVOSimulator();

	const CQuadTreeNode<SNode>* pNode = m_pScene->getLeafNodeBySceneCoord(vGroupAPos);
	CSceneGrid* pGrid = m_pScene->fetchSceneGrid(pNode);

	CGroup* pGroupA = new CGroup;
	for (size_t i=0; i<vGroupASize; ++i)
	{
		CAgent* pAgent = pAgentGenerator->genAgentAtFixedSceneGrid(m_pScene, pGrid->getCoordinate(), glm::vec2(0, DefaultSpeed));
		size_t Index = pRVOSimulator->addAgent(pAgent->getInitPosition());
		m_pCrowdSimulation->initAgentAdditionalInfo(pRVOSimulator, Index, pGrid->getCoordinate(), pAgent);

		pAgent->setAwareness(true);
		pAgent->setTempGoal(pAgent->getInitPosition());
		pAgent->setGoalPos(vGroupBPos);
		pGrid->addAgent(pAgent);
		pGroupA->addGroupMember(pAgent);
	}
	pGroupA->initRelationship();
	m_pCrowdSimulation->addGroup2GroupSet(pGroupA);

	pNode = m_pScene->getLeafNodeBySceneCoord(vGroupBPos);
	pGrid = m_pScene->fetchSceneGrid(pNode);

	CGroup* pGroupB = new CGroup;
	for (size_t i=0; i<vGroupBSize; ++i)
	{
		CAgent* pAgent = pAgentGenerator->genAgentAtFixedSceneGrid(m_pScene, pGrid->getCoordinate(), glm::vec2(0, DefaultSpeed));

		size_t Index = pRVOSimulator->addAgent(pAgent->getInitPosition());
		m_pCrowdSimulation->initAgentAdditionalInfo(pRVOSimulator, Index, pGrid->getCoordinate(), pAgent);
		pAgent->setAwareness(true);
		pAgent->setTempGoal(pAgent->getInitPosition());
		pAgent->setGoalPos(vGroupAPos);
		pGrid->addAgent(pAgent);
		pGroupB->addGroupMember(pAgent);
	}
	pGroupB->initRelationship();
	m_pCrowdSimulation->addGroup2GroupSet(pGroupB);

	delete pAgentGenerator;
}

//********************************************************************
//FUNCTION:
void CFramework::finishFindingLostAgent(const glm::vec2& vPosSrc, const glm::vec2& vPosDst, const std::string& vRunConfig)
{
	_prepareProcess4FindingLostAgent(vPosSrc, vPosDst, vRunConfig);
	_ASSERT(m_pCrowdSimulation->getNumGroups() == 1);
	CGroup* pGroup = m_pCrowdSimulation->getGroup(0);

	_ASSERT(pGroup->getNumSubgroup() == 2);
	CSubgroup* pSubgroupA = pGroup->fetchSubgroup(0);
	CSubgroup* pSubgroupB = pGroup->fetchSubgroup(1);
	CSubgroup* pSubgroupSrc = pSubgroupA->getToDoState() ? pSubgroupA : pSubgroupB;  //src:execute finding task
	CSubgroup* pSubgroupDst = pSubgroupA->getToDoState() ? pSubgroupB : pSubgroupA;  //dst:the agent to be found
	_ASSERT(pSubgroupSrc->getNumSubgroupMembers() == 1);
	_ASSERT(pSubgroupDst->getNumSubgroupMembers() == 1);

	CAgent* pAgentSrc = pSubgroupSrc->fetchAgent(0);
	CAgent* pAgentDst = pSubgroupDst->fetchAgent(0);
	_ASSERT(CPrepareScene::getInstance()->getNumExit() > 0);
	pAgentSrc->setGoalPos(CPrepareScene::getInstance()->getExit(0));
	pAgentDst->setGoalPos(CPrepareScene::getInstance()->getExit(0));

	while (!m_pCrowdSimulation->isFinished())
	{
		m_pCrowdSimulation->advance();
		_updateVisualScene();
	}
}

//********************************************************************
//FUNCTION:
void CFramework::_parseConfigFilesOpenCV(const std::string& vRunConfig)
{
	CRunConfig* pRunConfig = new CRunConfig();
	pRunConfig->parseV(vRunConfig);

	std::string AgentConfigFile           = pRunConfig->getAttribute<std::string>(AGENT);
	std::string CrowdSimulationConfigFile = pRunConfig->getAttribute<std::string>(CROWDSIMULATIONCONFIG);
	std::string SceneConfigFile           = pRunConfig->getAttribute<std::string>(SCENECONFIG);

	if (!AgentConfigFile.empty())
		initAgentConfig(AgentConfigFile);
	if (!CrowdSimulationConfigFile.empty())
		initSimulationConfig(CrowdSimulationConfigFile);
	if (!SceneConfigFile.empty())
		parseAndGenScene(SceneConfigFile);

	delete pRunConfig;
}

//********************************************************************
//FUNCTION:
void CFramework::_parseConfigFilesOpenGL(const std::string& vRunConfig)
{
	CRunConfig* pRunConfig = new CRunConfig();
	pRunConfig->parseV(vRunConfig);

	std::string AgentConfigFile           = pRunConfig->getAttribute<std::string>(AGENT);
	std::string CrowdSimulationConfigFile = pRunConfig->getAttribute<std::string>(CROWDSIMULATIONCONFIG);

	if (!AgentConfigFile.empty())
		initAgentConfig(AgentConfigFile);
	if (!CrowdSimulationConfigFile.empty())
		initSimulationConfig(CrowdSimulationConfigFile);

	delete pRunConfig;
}

//********************************************************************
//FUNCTION:
void CFramework::_prepare(const std::string& vRunConfig)
{
	_ASSERT(!vRunConfig.empty());

	_parseConfigFilesOpenCV(vRunConfig);
	if (m_IsScenePrepared)
	{
		_ASSERT(m_pScene);
		initVisualization(m_pScene->getSceneWidth(), m_pScene->getSceneHeight(), CCrowdSimulationConfig::getInstance()->getBackgroundColor());
		initSimulator();
	}

	m_IsInit = true;
}

//********************************************************************
//FUNCTION:
void CFramework::giveUpFindingLostAgent(const glm::vec2& vPosSrc, const glm::vec2& vPosDst, const std::string& vRunConfig, bool& voIsGivingUp)
{
	_prepareProcess4FindingLostAgent(vPosSrc, vPosDst, vRunConfig);
	_ASSERT(m_pCrowdSimulation->getNumGroups() == 1);
	CGroup* pGroup = m_pCrowdSimulation->getGroup(0);

	_ASSERT(pGroup->getNumSubgroup() == 2);
	CSubgroup* pSubgroupA = pGroup->fetchSubgroup(0);
	CSubgroup* pSubgroupB = pGroup->fetchSubgroup(1);
	CSubgroup* pSubgroupSrc = pSubgroupA->getToDoState() ? pSubgroupA : pSubgroupB;  //src:execute finding task
	CSubgroup* pSubgroupDst = pSubgroupA->getToDoState() ? pSubgroupB : pSubgroupA;  //dst:the agent to be found
	_ASSERT(pSubgroupSrc->getNumSubgroupMembers() == 1);
	_ASSERT(pSubgroupDst->getNumSubgroupMembers() == 1);

	CAgent* pAgentSrc = pSubgroupSrc->fetchAgent(0);
	CAgent* pAgentDst = pSubgroupDst->fetchAgent(0);
	_ASSERT(CPrepareScene::getInstance()->getNumExit() > 0);
	pAgentSrc->setGoalPos(CPrepareScene::getInstance()->getExit(0));
	pAgentDst->setGoalPos(CPrepareScene::getInstance()->getExit(0));

	while (!m_pCrowdSimulation->isFinished())
	{
		m_pCrowdSimulation->advance();
		_updateVisualScene();
	}
}

//********************************************************************
//FUNCTION:
void CFramework::clashBetweenGroups(const glm::vec2& vGroupAPos, unsigned int vGroupASize, const glm::vec2& vGroupBPos, unsigned int vGroupBSize, const std::string& vRunConfig)
{
	_prepareProcess4ClashBetweenGroups(vGroupAPos, vGroupASize, vGroupBPos, vGroupBSize, vRunConfig);
	m_pCrowdSimulation->setNumElapsedFrame(1);
	runCrowdSimulation(false);
}

//********************************************************************
//FUNCTION:
void CFramework::_drawExeTaskGroupMember(const CGroup* vGroup, const glm::vec3& vExeColor) const
{
	_ASSERT(vGroup);
	std::vector<CAgent*> ExeTaskAgentSet;
	vGroup->fetchExeTaskAgent(ExeTaskAgentSet);
	for (auto& Agent : ExeTaskAgentSet)
		drawPoint(Agent->getPosition(), CAgentConfig::getInstance()->getRadius()+3, vExeColor, true);
}

//********************************************************************
//FUNCTION:
void CFramework::parseAndGenScene(const std::string& vBitmapFile)
{
	_ASSERT(!vBitmapFile.empty());

	CPrepareScene::getInstance()->parseSceneImage(vBitmapFile);
	m_pScene = new CScene(CPrepareScene::getInstance()->getSceneWidth(), CPrepareScene::getInstance()->getSceneHeight());
	m_pScene->setPixelInfo(CPrepareScene::getInstance()->getImageData());
	m_pScene->setBaseAndMinDeep(CCrowdSimulationConfig::getInstance()->getBaseNodeDeep(), CCrowdSimulationConfig::getInstance()->getMinNodeDeep());
	m_pScene->initBaseNodeSizeAndMinNodeSize();
	m_pScene->initTree();
	m_pScene->createBaseNode();
	m_pScene->buildTreeForBaseNode();
	m_pScene->encode4Node();

	m_IsScenePrepared = true;
}

//********************************************************************
//FUNCTION:
void CFramework::drawSphere(const glm::vec2& vCoord, float vRadius, const glm::vec3& vColor) const
{
	_ASSERT(m_pVisulization);
	glm::vec2 PosGL = glm::vec2(vCoord.x - CCrowdSimulationConfig::getInstance()->getSceneWidth() / 2, CCrowdSimulationConfig::getInstance()->getSceneHeight() / 2 - vCoord.y);
	m_pVisulization->drawSphere(PosGL, vRadius, vColor);
}

//********************************************************************
//FUNCTION:
void CFramework::drawCylinder(const glm::vec2& vCoord, float vRadius, const glm::vec3& vColor) const
{
	_ASSERT(m_pVisulization);
	glm::vec2 PosGL = glm::vec2(vCoord.x - CCrowdSimulationConfig::getInstance()->getSceneWidth() / 2, CCrowdSimulationConfig::getInstance()->getSceneHeight() / 2 - vCoord.y);
	m_pVisulization->drawCylinder(PosGL, vRadius, vColor);
}