#pragma once
#include "common/HiveConfig.h"
#include "common/ConfigParser.h"

namespace hiveCrowdSimulation
{
	const std::string AGENTCONFIG           = "AgentConfig";
	const std::string SCENECONFIG           = "SceneConfig";
	const std::string CROWDSIMULATIONCONFIG = "CrowdSimulationConfig";

	class CRunConfig : public hiveConfig::CHiveConfig
	{
	public:
		CRunConfig();
		virtual ~CRunConfig();

		virtual bool parseV(const std::string& vConfigInfo) {return hiveConfig::hiveParseConfig(vConfigInfo, hiveConfig::CONFIG_XML, this);}
	};

	CRunConfig::CRunConfig()
	{
		defineAttribute(AGENT,           hiveConfig::ATTRIBUTE_STRING);
		defineAttribute(SCENECONFIG,           hiveConfig::ATTRIBUTE_STRING);
		defineAttribute(CROWDSIMULATIONCONFIG, hiveConfig::ATTRIBUTE_STRING);
	}

	CRunConfig::~CRunConfig()
	{
	}
}