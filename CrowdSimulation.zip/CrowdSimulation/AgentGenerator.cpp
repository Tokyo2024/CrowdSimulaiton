#include "AgentGenerator.h"
#include "AgentConfig.h"
#include "SceneGrid.h"
#include "PrepareScene.h"
#include "SimulationTools.h"
#include "Scene.h"
#include "SimulationTools.h"

using namespace hiveCrowdSimulation;

CAgentGenerator::CAgentGenerator(void)
{
}

CAgentGenerator::~CAgentGenerator(void)
{
}

//********************************************************************
//FUNCTION:
CAgent* CAgentGenerator::genAgentAtFixedSceneGrid(CScene* vScene, const glm::vec2& vGridCoord, const glm::vec2& vSpeedRange)
{
	const CQuadTreeNode<SNode>* Node = vScene->getLeafNodeBySceneCoord(vGridCoord);
	CSceneGrid* SceneGrid = vScene->fetchSceneGrid(Node);
	glm::vec2 Direction = glm::vec2(getFloatRandom(-1.0f, 1.0f), getFloatRandom(-1.0f, 1.0f));
	float Speed = getFloatRandom(vSpeedRange.x, vSpeedRange.y);

	float Offset = CAgentConfig::getInstance()->getRadius();
	glm::vec2 XPosRange, YPosRange;
	XPosRange.x = Node->getCenter().x - Node->getWidth() / 2 + Offset;
	XPosRange.y = Node->getCenter().x + Node->getWidth() / 2 - Offset;
	YPosRange.x = Node->getCenter().y - Node->getHeight() / 2 + Offset;
	YPosRange.y = Node->getCenter().y + Node->getHeight() / 2 - Offset;

	glm::vec2 Position = glm::vec2(getFloatRandom(XPosRange.x, XPosRange.y), getFloatRandom(YPosRange.x, YPosRange.y));
	CAgent* pAgent = new CAgent(Direction, Speed, Position, vScene);
	pAgent->setGridID(vGridCoord);
	return pAgent;
}

//********************************************************************
//FUNCTION:
CAgent* CAgentGenerator::genAgentAtFixedCoordinate(CScene* vScene, const glm::vec2& vCoordinate)
{
	glm::vec2 Direction = glm::normalize(glm::vec2(getFloatRandom(-1.0f, 1.0f), getFloatRandom(-1.0f, 1.0f)));
	float Speed = getFloatRandom(1.0, CAgentConfig::getInstance()->getMaxSpeed());
	CAgent* pAgent = new CAgent(Direction, Speed, vCoordinate, vScene);

	return pAgent;
}