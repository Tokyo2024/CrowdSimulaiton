#include "SimulationTools.h"
#include <fstream>
#include <eigen/dense>
#include <boost/random.hpp>
#include "IAgent.h"

//*******************************************************************
//FUNCTION:
time_t hiveCrowdSimulation::setSeed()
{
	TotalTime++;
	return TotalTime;
}

//*******************************************************************
//FUNCTION:
float hiveCrowdSimulation::dot(const glm::vec2& vVectorA, const glm::vec2& vVectorB)
{
	return vVectorA.x * vVectorB.x + vVectorA.y * vVectorB.y;
}

//*******************************************************************
//FUNCTION:
unsigned int hiveCrowdSimulation::choseByRoulette(const std::vector<float> &vProbability)
{
	std::vector<float> Index;
	float Sum = 0.0f;
	for (unsigned int i=0; i<vProbability.size(); ++i)
	{
		Sum += vProbability[i];
		Index.push_back(Sum);
	}

	float Position = getFloatRandom(0, Sum);

	for (unsigned int i=0; i<Index.size(); ++i)
	{
		if (Position <= Index[i]) return i;
	}
}

//********************************************************************
//FUNCTION:
void hiveCrowdSimulation::writeAgentInfo2File(const CAgent* vAgent, std::ofstream& vioFileStream)
{
	vioFileStream << vAgent->getPosition().x << " " << vAgent->getPosition().y;
	vioFileStream << " " << vAgent->isAwareness();
	vioFileStream << " " << vAgent->getGroupID() << std::endl;
}

//********************************************************************
//FUNCTION:
void hiveCrowdSimulation::computeMeanAndVariance(const std::vector<glm::vec2>& vDataSet, glm::vec2& voMean, glm::mat2x2& voVarianceMat)
{
	for (auto& Data : vDataSet)
		voMean += Data;
	
	if (vDataSet.size() > 0)
		voMean /= vDataSet.size();

	for (unsigned int i=0; i<2; i++)
	{
		for (unsigned int k=0; k<2; k++)
		{
			for (auto& Data : vDataSet)
				voVarianceMat[i][k] += (Data[i] - voMean[i]) * (Data[k] - voMean[k]); 
		}
	}
	voVarianceMat /= (vDataSet.size() - 1);
}

//********************************************************************
//FUNCTION:
float hiveCrowdSimulation::guassDistributionFunc(const glm::vec2& vMean, const glm::mat2x2& vVarianceMat, const glm::vec2& vData)
{
	Eigen::Vector2f Mean = Eigen::Vector2f(vMean.x, vMean.y);
	Eigen::Vector2f Data = Eigen::Vector2f(vData.x, vData.y);
 	Eigen::Matrix2f VarianceMat;
 	for (unsigned int i=0; i<2; i++)
	{
 		for (unsigned int k=0; k<2; k++)
		{
 			VarianceMat(i, k) = vVarianceMat[i][k];
		}
	}

	double FirstMultiplicator = 1.0 / sqrt(pow(2*M_PI, 2) * VarianceMat.determinant());
	
	Eigen::Vector2f Data2MeanVec = Data - Mean;
	double SecondMultiplicator = exp(-1/2.0 * Data2MeanVec.transpose()* VarianceMat.inverse() * Data2MeanVec);

	return FirstMultiplicator * SecondMultiplicator;
}

//********************************************************************
//FUNCTION:
float hiveCrowdSimulation::exceGuassDistributionFunc(const std::vector<glm::vec2>& vDataSet, const glm::vec2& vData)
{
	glm::vec2 Mean;
	glm::mat2 Variance;
	computeMeanAndVariance(vDataSet, Mean, Variance);

	return guassDistributionFunc(Mean, Variance, vData);
}

//********************************************************************
//FUNCTION:
int hiveCrowdSimulation::getIntRandom(int vMin, int vMax)
{
	if (vMin >= vMax)
	{
		std::cout << vMin << ", " << vMax << std::endl;
	}
	boost::uniform_int<int> Distribution(vMin, vMax);
	boost::variate_generator<boost::mt19937_64&, boost::uniform_int<int>> Random(Engine, Distribution);
	return Random();
}

//********************************************************************
//FUNCTION:
float hiveCrowdSimulation::getFloatRandom(float vMin, float vMax)
{
	boost::uniform_real<float> Distribution(vMin, vMax);
	boost::variate_generator<boost::mt19937_64&, boost::uniform_real<float>> Random(Engine, Distribution);
	return Random();
}

//*******************************************************************
//FUNCTION:
int hiveCrowdSimulation::getNum(int vNum)
{
	if (vNum < 2)
		return 1;
	else
	{
		int Count = 0;
		int B = vNum / 2; 
		while (B != 1)
		{
			Count++;
			B /= 2;
		}
		return pow(2, Count);
	}
}

//********************************************************************
//FUNCTION:
void hiveCrowdSimulation::initSeed(time_t vSeed)
{
	Engine = boost::mt19937_64(vSeed);
}

const glm::vec2 hiveCrowdSimulation::rotateVector(const glm::vec2& vVector, float vAngle)
{
	glm::vec2 CurVector = vVector;
	if(CurVector == glm::vec2(0.0, 0.0))
		CurVector = glm::vec2(1.0, 0.0);
	glm::vec2 RotatedVector;
	vAngle = vAngle * M_PI / 180.0f;
	RotatedVector.x = CurVector.x * std::cos(vAngle) - CurVector.y * std::sin(vAngle);
	RotatedVector.y = CurVector.x * std::sin(vAngle) + CurVector.y * std::cos(vAngle);

	return glm::normalize(RotatedVector);
}

//********************************************************************
//FUNCTION:
void hiveCrowdSimulation::computeRectDiagonal(const glm::vec2& vCenter, float vRadius, glm::vec2& voLeftUpPoint, glm::vec2& voRightDownPoint)
{
	voLeftUpPoint.x = vCenter.x - std::sin(45.0*M_PI/180.0)*vRadius;
	voLeftUpPoint.y = vCenter.y - std::cos(45.0*M_PI/180.0)*vRadius;
	voRightDownPoint.x = vCenter.x + std::sin(45.0*M_PI/180.0)*vRadius;
	voRightDownPoint.y = vCenter.y + std::cos(45.0*M_PI/180.0)*vRadius;
}