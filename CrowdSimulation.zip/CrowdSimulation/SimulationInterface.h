#pragma once
#include "SimulationExport.h"
#include <string>
#include <GLM/glm.hpp>
#include <vector>
#include <map>

namespace hiveCrowdSimulation
{
	CROWD_SIMULATION_DLL_EXPORT void initCrowdSimulation(const std::string& vAgentInfo, const std::string& vSceneInfo, const std::string& vSimulationInfo);
	CROWD_SIMULATION_DLL_EXPORT void runCrowdSimulation(bool vIsOutputPosInfo2File);
	CROWD_SIMULATION_DLL_EXPORT void testDisplayingSimulationResultByOpenCV(const std::string& vRunConfig, const std::string& vSimulationResult);
	CROWD_SIMULATION_DLL_EXPORT void testDisplayingSimulationResultByOpenGL(const std::string& vRunConfig, const std::string& vSimulationResult);

	CROWD_SIMULATION_DLL_EXPORT void initAgentConfig(const std::string& vAgentInfo);
	CROWD_SIMULATION_DLL_EXPORT void initSimulationConfig(const std::string& vSimulationInfo);
	CROWD_SIMULATION_DLL_EXPORT void initAgentAndSimulationConfig(const std::string& vSceneInfo, const std::string& vSimulationInfo);

	CROWD_SIMULATION_DLL_EXPORT void initDisPlayWithSpeiciedAttr(int vPWidth, int vPHeight, const glm::vec3& vBackColor);
	CROWD_SIMULATION_DLL_EXPORT void clearScreen();
	CROWD_SIMULATION_DLL_EXPORT void display();
	CROWD_SIMULATION_DLL_EXPORT void prepareScene();
	CROWD_SIMULATION_DLL_EXPORT void preparePath(const std::vector<glm::vec2>& vPointSet, float vRadius, const glm::vec3& vColor);
	CROWD_SIMULATION_DLL_EXPORT void preparePoint(const glm::vec2& vCoord, float vRadius, const glm::vec3& vColor, bool vIsFilled);
	CROWD_SIMULATION_DLL_EXPORT void prepareLine(const glm::vec2& vPointA, const glm::vec2& vPointB, float vLineThickness, const glm::vec3& vLineColor);

 	CROWD_SIMULATION_DLL_EXPORT void genScene();
	CROWD_SIMULATION_DLL_EXPORT void genScene(const std::string& vBitmapFile);
 	CROWD_SIMULATION_DLL_EXPORT void genGraph(bool vIsCrowdDensityConsidered);

 	CROWD_SIMULATION_DLL_EXPORT bool testUpdatingEdgeWeight(const std::string& vSceneInfo, const glm::vec2& vPosA, const glm::vec2& vPosB, double vLength, bool vIsCrowdDensityConsidered);
	CROWD_SIMULATION_DLL_EXPORT void findShortestPath(bool vIsCrowdDensityConsidered, const glm::vec2& vStart, const glm::vec2& vEnd, std::vector<glm::vec2>& voResults);
 	CROWD_SIMULATION_DLL_EXPORT void findPathUseDijkstra(bool vIsCrowdDensityConsidered, const glm::vec2& vStart, const glm::vec2& vEnd, double& voLength, std::vector<glm::vec2>& voResults);
	CROWD_SIMULATION_DLL_EXPORT void testFindingBestNext(const std::string& vSceneInfo, const std::string& vAgentInfo, const glm::vec2& vStart, const glm::vec2& vEnd, float vViewableDistance, glm::vec2& voBestNext, std::vector<glm::vec2>& voRoad);
	CROWD_SIMULATION_DLL_EXPORT bool testVisibility(const glm::vec2& vSource, const glm::vec2& vTarget, float vRadius);
	CROWD_SIMULATION_DLL_EXPORT bool testPassibility(const glm::vec2& vGrid);
	CROWD_SIMULATION_DLL_EXPORT void testUpdatingGraphWithCrowd(const std::string& vAgentInfo, const std::string& vSceneInfo, const std::string& vSimulationInfo);
	CROWD_SIMULATION_DLL_EXPORT void testInitCrowdSimulation(const std::string& vAgentInfo, const std::string& vSceneInfo, const std::string& vSimulationInfo);

	CROWD_SIMULATION_DLL_EXPORT float testGuassDistributionFunc(const std::vector<glm::vec2>& vDataSet, const glm::vec2& vData);
	CROWD_SIMULATION_DLL_EXPORT void computeAllPointsOnLine(const glm::vec2& vArrayCoordA, const glm::vec2& vArrayCoordB, std::vector<glm::vec2>& vResult);
	CROWD_SIMULATION_DLL_EXPORT void testKNNSearch(const std::string& vSceneInfo, const std::vector<glm::vec2>& vDataSet, const glm::vec2& vData, unsigned int vNumOptimalNeighbor);
	CROWD_SIMULATION_DLL_EXPORT float getEdgeWeight(const glm::vec2& vScenePosA, const glm::vec2& vScenePosB);
	CROWD_SIMULATION_DLL_EXPORT bool testQueryingEdgeWeight(const std::string& vSceneInfo, const glm::vec2& vStart, const glm::vec2& vEnd, bool vIsConsiderCrowdDensity);

	//Sprint_5:
	CROWD_SIMULATION_DLL_EXPORT void testSplitingGroup(const std::vector<std::vector<glm::vec2>>& vGroupAgentPosSet, const std::string& vRunConfig, int& voNumSugroup);
	CROWD_SIMULATION_DLL_EXPORT void testMergingGroup(const std::vector<std::vector<glm::vec2>>& vGroupAgentPosSet, const std::string& vRunConfig, int& voNumSugroup);
	CROWD_SIMULATION_DLL_EXPORT void testStartingMakeDecision(const std::vector<glm::vec2>& vSubgroupPosSet, const glm::vec2& vLostPos, const std::vector<float>& vIntimacySet, const std::string& vRunConfig, int& voNumTask);
	CROWD_SIMULATION_DLL_EXPORT void testFindingLostAgentProcessSuccessful(const glm::vec2& vPosSrc, const glm::vec2& vPosDst, const std::string& vRunConfig);
	CROWD_SIMULATION_DLL_EXPORT void testFindingLostAgentProcessUnsuccessful(const glm::vec2& vPosSrc, const glm::vec2& vPosDst, const std::string& vRunConfig, bool& voIsGivingUp);
	CROWD_SIMULATION_DLL_EXPORT void testClashingBetweenGroups(const glm::vec2& vGroupAPos, unsigned int vGroupASize, const glm::vec2& vGroupBPos, unsigned int vGroupBSize, const std::string& vRunConfig);

	//Sprint_7:
	CROWD_SIMULATION_DLL_EXPORT void testLoadingSceneImage(const std::string& vBitmapFile, const std::string& vSimulationFile);
	CROWD_SIMULATION_DLL_EXPORT void testCreatingQuadtree(const std::string& vBitmapFile, const std::string& vSimulationFile);
	CROWD_SIMULATION_DLL_EXPORT void testFindingNeighborhoodByQuadTree(const std::string& vBitmapFile, const std::string& vSimulationFile);
	CROWD_SIMULATION_DLL_EXPORT void testFindingNeighborhoodByGraph(const std::string& vBitmapFile, const std::string& vSimulationFile);
	
	//Sprint_8
	CROWD_SIMULATION_DLL_EXPORT void testComputingGridCoordBetweenTwoGrids(const std::string& vBitmapFile, const glm::vec2& vEye, const glm::vec2& vTarget);
	CROWD_SIMULATION_DLL_EXPORT bool testIsVisiable(const std::string& vBitmapFile, const glm::vec2& vEye, const glm::vec2& vTarget, const std::string& vSimulationFile);
	CROWD_SIMULATION_DLL_EXPORT void testDumpingNodeInSight(const std::string& vSceneInfo, glm::vec2 vEye, float vViewableDistance, std::vector<glm::vec4>& voNodeSet);
	CROWD_SIMULATION_DLL_EXPORT void testGettingAllLeafNodeIntersect2SpecifiedLine(const std::string& vBitmapFile, const std::string& vSimulationFile, const glm::vec2& vEye, const glm::vec2& vTarget);
	CROWD_SIMULATION_DLL_EXPORT void testGettingLeafNodeBySceneCoord(const std::string& vBitmapFile, const std::string& vSimulationFile, const glm::vec2& vCoord);
	CROWD_SIMULATION_DLL_EXPORT void testRotateVector(const glm::vec2& vPoint, const glm::vec2& vVector, float vAngle, const std::string& vBitmapFile, const std::string& vSimulationFile);
	//Sprint_9
	CROWD_SIMULATION_DLL_EXPORT void testGetLeafNodeBySceneCoord(const glm::vec2& vPos, const std::string& vSimulationInfo, const std::string& vSceneInfo);
	//Sprint_10
	CROWD_SIMULATION_DLL_EXPORT void testGenCrowdAtSpecificArea(const std::string& vAgentInfo, const std::string& vSceneInfo, const std::string& vSimulationInfo, const glm::vec2& vCenter, unsigned int vRadius, unsigned int vNumAgent, bool vIsAware);
}