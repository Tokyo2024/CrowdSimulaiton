#pragma once
#include<vector>
#include <glm\glm.hpp>

namespace hiveCrowdSimulation
{
	class CScene;

	struct SRouteMapVertex
	{
		glm::vec2 Position;
		std::vector<int> Neighbors;
		std::vector<float> DistToGoal;
	};

	class CRoadMap
	{
	public:
		CRoadMap();
		~CRoadMap();

		void setScene(CScene* vScene) {m_pScene = vScene;}
		void createRoadMap(const std::vector<glm::vec2>& vNavigationSet);
		int  getRoadMapIndex(const glm::vec2& vPos) const;
		const std::vector<SRouteMapVertex>& getRoadMapSet() const {return m_RoadMapSet;}

	private:
		void __initRoadMapSet(const std::vector<glm::vec2>& vNavigationSet);

	private:
		std::vector<SRouteMapVertex> m_RoadMapSet;
		CScene* m_pScene;
	};
}