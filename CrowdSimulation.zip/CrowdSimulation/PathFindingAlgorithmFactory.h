#pragma once
#include "PathFindingAlgorithm.h"

namespace hiveCrowdSimulation
{
	template <class TAlgorithm>
	class CPathFindingAlgorithmFactory
	{
	public:
		CPathFindingAlgorithmFactory(const std::string& vSig)
		{
			CPathFindingAlgorithmFactoryData::getInstance()->registerPathFindingAlgorithmFactory(reinterpret_cast<CPathFindingAlgorithmFactory<CPathFindingAlgorithm>*>(this), vSig);
		}
		~CPathFindingAlgorithmFactory(void) {}

	protected:
		CPathFindingAlgorithm* _createPathFindingAlgorithmV() {return new TAlgorithm;}

		friend class CPathFindingAlgorithmFactoryData;
	};
}