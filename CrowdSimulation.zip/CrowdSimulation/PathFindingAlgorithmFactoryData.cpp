#include "PathFindingAlgorithmFactoryData.h"

using namespace hiveCrowdSimulation;

CPathFindingAlgorithmFactoryData::CPathFindingAlgorithmFactoryData(void)
{
}

CPathFindingAlgorithmFactoryData::~CPathFindingAlgorithmFactoryData(void)
{
}

//***********************************************************************
//FUNCTION
CPathFindingAlgorithm* hiveCrowdSimulation::CPathFindingAlgorithmFactoryData::createPathFindingAlgorithm(const std::string& vSig)
{
	if (!__isAlgorithmFactoryRegistered(vSig)) return NULL;
	CPathFindingAlgorithm* pPathFindingAlgorithm = m_AlgorithmFactoryMap[vSig]->_createPathFindingAlgorithmV();
	_ASSERT(pPathFindingAlgorithm);
	pPathFindingAlgorithm->setAlgorithmCreationSig(vSig);
	return pPathFindingAlgorithm;
}

//***********************************************************************
//FUNCTION
bool hiveCrowdSimulation::CPathFindingAlgorithmFactoryData::__isAlgorithmFactoryRegistered(const std::string& vSig)
{
	return m_AlgorithmFactoryMap.count(vSig)>0;
}

//***********************************************************************
//FUNCTION
void hiveCrowdSimulation::CPathFindingAlgorithmFactoryData::registerPathFindingAlgorithmFactory(CPathFindingAlgorithmFactory<CPathFindingAlgorithm>* vPathFindingAlgorithmFactory, const std::string& vSig)
{
	m_AlgorithmFactoryMap[vSig] = vPathFindingAlgorithmFactory;
}
