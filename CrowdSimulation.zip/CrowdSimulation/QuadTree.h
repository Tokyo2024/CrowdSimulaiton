#pragma once
#include <iostream>
#include <functional>
#include "QuadTreeNode.h"
#include "SimulationExport.h"

namespace hiveCrowdSimulation
{
	template<class ExtraInfo>
	class CQuadTree
	{
	public:
		CQuadTree(void);
		virtual ~CQuadTree(void);

		typedef std::function<void(CQuadTreeNode<ExtraInfo>*)> NodeOperationFunc;

		bool Empty();
		int  Size();
		int  Height();
		void Clear();
		void addNode(CQuadTreeNode<ExtraInfo>* vChild, CQuadTreeNode<ExtraInfo>* vParent, unsigned int vIndex);
		void deleteNode(CQuadTreeNode<ExtraInfo>* vParent, unsigned int vIndex);
		const CQuadTreeNode<ExtraInfo>* getRoot() const;

		virtual void traverseInorder(NodeOperationFunc vFunc);
		virtual const CQuadTreeNode<ExtraInfo>* getLeafNodeBySceneCoord(const glm::vec2& vSceneCoord) const;

	protected:
		int  _countSize(CQuadTreeNode<ExtraInfo>* vNode);
		int  _countHeight(CQuadTreeNode<ExtraInfo>* vNode);
		void _traverseInorder(CQuadTreeNode<ExtraInfo>* vNode, NodeOperationFunc vFunc);
		void _clearTree(CQuadTreeNode<ExtraInfo>* vParent);

	protected:
		CQuadTreeNode<ExtraInfo>* m_pRootNode;
	};

	template<class ExtraInfo>
	void CQuadTree<ExtraInfo>::_clearTree(CQuadTreeNode<ExtraInfo>* vParent)
	{
		if (vParent->isLeafNode())
		{
			delete vParent;
			vParent = NULL;
		}
		else
		{
			for (size_t i=0; i<MAXCHILDNUM; ++i)
			{
				_clearTree(vParent->getChildByIndex(i));
			}
			delete vParent;
			vParent = NULL;
		}
	}

	template<class ExtraInfo>
	void CQuadTree<ExtraInfo>::traverseInorder(NodeOperationFunc vFunc)
	{
		_traverseInorder(m_pRootNode, vFunc);
	}

	template<class ExtraInfo>
	void CQuadTree<ExtraInfo>::_traverseInorder(CQuadTreeNode<ExtraInfo>* vNode, NodeOperationFunc vFunc)
	{
		if (!vNode->isLeafNode())
		{
			vFunc(vNode);
			for (int i=0; i<MAXCHILDNUM; ++i)
			{
				_traverseInorder(vNode->getChildByIndex(i), vFunc);
			}
		}
		else
		{
			vFunc(vNode);
		}
	}

	template<class ExtraInfo>
	const CQuadTreeNode<ExtraInfo>* CQuadTree<ExtraInfo>::getLeafNodeBySceneCoord(const glm::vec2& vCoordination) const
	{
		if (!m_pRootNode->isCoordinationInMyRange(vCoordination))
		{
			return NULL;
		}
		return m_pRootNode->getChildByCoordinate(vCoordination);
	}

	template<class ExtraInfo>
	const CQuadTreeNode<ExtraInfo>* CQuadTree<ExtraInfo>::getRoot() const
	{
		return m_pRootNode;
	}

	template<class ExtraInfo>
	void CQuadTree<ExtraInfo>::deleteNode(CQuadTreeNode<ExtraInfo>* vParent, unsigned int vIndex)
	{
		_ASSERT(vIndex < MAXCHILDNUM);
		vParent->deleteChild(vIndex);
	}

	template<class ExtraInfo>
	void CQuadTree<ExtraInfo>::addNode(CQuadTreeNode<ExtraInfo>* vChild, CQuadTreeNode<ExtraInfo>* vParent, unsigned int vIndex)
	{
		_ASSERT(vIndex < MAXCHILDNUM);
		vParent->addChild(vChild, vIndex);
	}

	template<class ExtraInfo>
	CQuadTree<ExtraInfo>::~CQuadTree(void)
	{
		_clearTree(m_pRootNode);
	}

	template<class ExtraInfo>
	CQuadTree<ExtraInfo>::CQuadTree(void)
	{
		m_pRootNode = new CQuadTreeNode<ExtraInfo>;
	}

	template<class ExtraInfo>
	void CQuadTree<ExtraInfo>::Clear()
	{
		_clearTree(m_pRootNode);
	}

	template<class ExtraInfo>
	int CQuadTree<ExtraInfo>::Height()
	{
		return _countHeight(m_pRootNode);
	}

	template<class ExtraInfo>
	int CQuadTree<ExtraInfo>::_countHeight(CQuadTreeNode<ExtraInfo>* vNode)
	{
		if (vNode == NULL)
		{
			return 0;
		}
		else
		{
			std::vector<int> HeightSet;
			for (int i=0; i<MAXCHILDNUM; ++i)
			{
				HeightSet.push_back(_countHeight(vNode->getChildByIndex(i)));
			}
			int MaxA =  HeightSet[NorthWest] > HeightSet[NorthEast] ? HeightSet[NorthWest] : HeightSet[NorthEast];
			int MaxB =  HeightSet[SouthWest] > HeightSet[SouthEast] ? HeightSet[SouthWest] : HeightSet[SouthEast];
			return MaxA > MaxB ? MaxA + 1 : MaxB + 1;
		}
	}

	template<class ExtraInfo>
	int CQuadTree<ExtraInfo>::_countSize(CQuadTreeNode<ExtraInfo>* vNode)
	{
		if (vNode == NULL)
		{
			return 0;
		}
		else
		{
			int Sum = 1;
			for (int i=0; i<MAXCHILDNUM; ++i)
			{
				Sum += _countSize(vNode->getChildByIndex(i));
			}
			return Sum;
		}
	}

	template<class ExtraInfo>
	int CQuadTree<ExtraInfo>::Size()
	{
		return _countSize(m_pRootNode);
	}

	template<class ExtraInfo>
	bool CQuadTree<ExtraInfo>::Empty()
	{
		return m_pRootNode == NULL;
	}
}