#include "CrowdSimulationConfig.h"
#include "common/ConfigParser.h"

using namespace hiveCrowdSimulation;

CCrowdSimulationConfig::CCrowdSimulationConfig()
{
	_defineAcceptableAttributeSet();
}

CCrowdSimulationConfig::~CCrowdSimulationConfig()
{
}

//*******************************************************************
//FUNCTION:
bool CCrowdSimulationConfig::parserV(const std::string& vCrowdSimulationInfo)
{
	return hiveConfig::hiveParseConfig(vCrowdSimulationInfo, hiveConfig::CONFIG_XML, this);
}

//*******************************************************************
//FUNCTION:
void hiveCrowdSimulation::CCrowdSimulationConfig::_loadDefaultV()
{
	//setAttribute(hiveCrowdSimulation::OFFSET, (float)4.0);
	setAttribute(ADVANCETIME, 500);
}

//*******************************************************************
//FUNCTION:
void hiveCrowdSimulation::CCrowdSimulationConfig::_onLoadedV()
{
	//IAgentConfig
	if (!isAttributeExisted(OFFSET))		   setAttribute(OFFSET, (float)4.0);
	if (!isAttributeExisted(TIMESTEP))		   setAttribute(TIMESTEP, (float)2.0);
	if (!isAttributeExisted(ADVANCETIME))	   setAttribute(ADVANCETIME, 500);
	if (!isAttributeExisted(RADIUSOFGOAL))	   setAttribute(RADIUSOFGOAL, (float)15.0) ;
	if (!isAttributeExisted(RADIUSOFTEMPGOAL)) setAttribute(RADIUSOFTEMPGOAL, (float)4.0);
	if (!isAttributeExisted(NEIGHBOURNUM))	   setAttribute(NEIGHBOURNUM, 6);
	if (!isAttributeExisted(PROCEEDINGTIME))   setAttribute(PROCEEDINGTIME, 500);

	//GroupConfig
	if (!isAttributeExisted(WEIGHTOFDISTANCE))	setAttribute(WEIGHTOFDISTANCE, (float)1.0);
	if (!isAttributeExisted(WEIGHTOFVELOCITY))	setAttribute(WEIGHTOFVELOCITY, (float)1.0);
	if (!isAttributeExisted(WEIGHTOFPOSITION))	setAttribute(WEIGHTOFPOSITION, (float)1.0);
	if (!isAttributeExisted(WEIGHTOFAWARENESS)) setAttribute(WEIGHTOFAWARENESS, (float)2.0);
	if (!isAttributeExisted(WEIGHTOFIGNORANCE)) setAttribute(WEIGHTOFIGNORANCE, (float)1.0);
	if (!isAttributeExisted(FLOORLIMITMEMBERS)) setAttribute(FLOORLIMITMEMBERS, 2);
	if (!isAttributeExisted(UPPERLIMITMEMBERS)) setAttribute(UPPERLIMITMEMBERS, 8);
	if (!isAttributeExisted(GROUPFORCE))				  setAttribute(GROUPFORCE, std::string("GROUPCENTERGROUPFORCE_SIG"));
	if (!isAttributeExisted(WEIGHTOFTARGETFORCE))		  setAttribute(WEIGHTOFTARGETFORCE, (float)1.0);
	if (!isAttributeExisted(WEIGHTOFCOGESIONFORCE))		  setAttribute(WEIGHTOFCOGESIONFORCE, (float)0.02);
	if (!isAttributeExisted(WEIGHTOFGROUPAWARENESSFORCE)) setAttribute(WEIGHTOFGROUPAWARENESSFORCE, (float)1.0);
	
	//ISceneConfig
	if (!isAttributeExisted(DIMENSION))	   setAttribute(DIMENSION, 2);
	if (!isAttributeExisted(BASENODEDEEP)) setAttribute(BASENODEDEEP, 3);
	if (!isAttributeExisted(MINNODEDEEP))  setAttribute(MINNODEDEEP, 5);

	//DisplayConfig
	if (!isAttributeExisted(BACKCOLOR))		  setAttribute(BACKCOLOR, boost::make_tuple<double, double, double>(0, 0, 0));
	if (!isAttributeExisted(EXITCOLOR))		  setAttribute(EXITCOLOR, boost::make_tuple<double, double, double>(100, 100, 100));
	if (!isAttributeExisted(PASSABLECOLOR))   setAttribute(PASSABLECOLOR, boost::make_tuple<double, double, double>(0, 0, 0));
	if (!isAttributeExisted(OBSTACLECOLOR))   setAttribute(OBSTACLECOLOR, boost::make_tuple<double, double, double>(255, 255, 255));
	if (!isAttributeExisted(AGENTCOLOR))	  setAttribute(AGENTCOLOR, boost::make_tuple<double, double, double>(255, 255, 0));
	if (!isAttributeExisted(ISSHOWSCENEGRID)) setAttribute(ISSHOWSCENEGRID, false);

	//RunConfig
	if (!isAttributeExisted(SIMULATIONRESULTFILE)) setAttribute(SIMULATIONRESULTFILE, std::string("SimulationResult.txt"));
	if (!isAttributeExisted(ISCROWDPOSSPECIFIED))  setAttribute(ISCROWDPOSSPECIFIED, false);
	if (!isAttributeExisted(PATHFINDINGALGORITHM)) setAttribute(PATHFINDINGALGORITHM, "Astar_SIG");

	/*for (unsigned int i=0; i<getNumSubConfig(); i++)
	{
	hiveConfig::CHiveConfig* pNodeConfig = fetchSubConfigAt(i);
	_ASSERTE(pNodeConfig);
	if (pNodeConfig->getType() == IAGENTCONFIG)
	{
	if(!pNodeConfig->isAttributeExisted(OFFSET)) pNodeConfig->setAttribute(OFFSET, (float)4.0);
	}
	}*/
}

//*******************************************************************
//FUNCTION:
void hiveCrowdSimulation::CCrowdSimulationConfig::_defineAcceptableAttributeSet()
{
	defineAttribute(IAGENTCONFIG,			hiveConfig::ATTRIBUTE_SUBCONFIG);
	defineAttribute(GROUPCONFIG,			hiveConfig::ATTRIBUTE_SUBCONFIG);
	defineAttribute(ISCENECONFIG,			hiveConfig::ATTRIBUTE_SUBCONFIG);
	defineAttribute(DISPLAYCONFIG,			hiveConfig::ATTRIBUTE_SUBCONFIG);
	defineAttribute(RUNCONFIG,				hiveConfig::ATTRIBUTE_SUBCONFIG);
	defineAttribute(OFFSET,                 hiveConfig::ATTRIBUTE_FLOAT);
	defineAttribute(TIMESTEP,               hiveConfig::ATTRIBUTE_FLOAT);
	defineAttribute(RADIUSOFGOAL,           hiveConfig::ATTRIBUTE_FLOAT);
	defineAttribute(RADIUSOFTEMPGOAL,       hiveConfig::ATTRIBUTE_FLOAT);
	defineAttribute(SIMULATIONRESULTFILE,   hiveConfig::ATTRIBUTE_STRING);
	defineAttribute(ADVANCETIME,            hiveConfig::ATTRIBUTE_FLOAT);
	defineAttribute(WEIGHTOFDISTANCE,		hiveConfig::ATTRIBUTE_FLOAT);
	defineAttribute(WEIGHTOFVELOCITY,		hiveConfig::ATTRIBUTE_FLOAT);
	defineAttribute(WEIGHTOFPOSITION,		hiveConfig::ATTRIBUTE_FLOAT);
	defineAttribute(WEIGHTOFAWARENESS,		hiveConfig::ATTRIBUTE_FLOAT);
	defineAttribute(WEIGHTOFIGNORANCE,		hiveConfig::ATTRIBUTE_FLOAT);
//	defineAttribute(CONSTANTALPHA,          hiveConfig::ATTRIBUTE_FLOAT);
	defineAttribute(NEIGHBOURNUM,			hiveConfig::ATTRIBUTE_INT);
	defineAttribute(PROCEEDINGTIME,         hiveConfig::ATTRIBUTE_INT);
//	defineAttribute(UPDATESCENETIME,        hiveConfig::ATTRIBUTE_INT);
	defineAttribute(DIMENSION,              hiveConfig::ATTRIBUTE_INT);

	defineAttribute(NUMAGENT,            hiveConfig::ATTRIBUTE_INT);
	defineAttribute(AWARENESSPERCENTAGE, hiveConfig::ATTRIBUTE_FLOAT);
	defineAttribute(IGNORANCEPERCENTAGE, hiveConfig::ATTRIBUTE_FLOAT);

	defineAttribute(BACKCOLOR,         hiveConfig::ATTRIBUTE_VEC3F);
	defineAttribute(PASSABLECOLOR,     hiveConfig::ATTRIBUTE_VEC3F);
	defineAttribute(OBSTACLECOLOR,     hiveConfig::ATTRIBUTE_VEC3F);
	defineAttribute(AGENTCOLOR,        hiveConfig::ATTRIBUTE_VEC3F);
	defineAttribute(EXITCOLOR,         hiveConfig::ATTRIBUTE_VEC3F);

	defineAttribute(AGENTSNOTBELONGEDTOGROUP, hiveConfig::ATTRIBUTE_INT);
	defineAttribute(NUMGROUP ,                hiveConfig::ATTRIBUTE_INT);
	defineAttribute(FLOORLIMITMEMBERS,		  hiveConfig::ATTRIBUTE_INT);
	defineAttribute(UPPERLIMITMEMBERS,		  hiveConfig::ATTRIBUTE_INT);
	defineAttribute(GROUPFORCE,				  hiveConfig::ATTRIBUTE_STRING);

	defineAttribute(WEIGHTOFTARGETFORCE,   hiveConfig::ATTRIBUTE_FLOAT);
	defineAttribute(WEIGHTOFCOGESIONFORCE, hiveConfig::ATTRIBUTE_FLOAT);
	defineAttribute(WEIGHTOFGROUPAWARENESSFORCE, hiveConfig::ATTRIBUTE_FLOAT);
//	defineAttribute(COSTTHRESHOLD,		   hiveConfig::ATTRIBUTE_FLOAT);
	defineAttribute(ISCROWDPOSSPECIFIED,   hiveConfig::ATTRIBUTE_BOOL);
//	defineAttribute(CROWDPOSFILE,		   hiveConfig::ATTRIBUTE_STRING);

	defineAttribute(ISSHOWSCENEGRID,   hiveConfig::ATTRIBUTE_BOOL);
	defineAttribute(BASENODEDEEP,		   hiveConfig::ATTRIBUTE_INT);
	defineAttribute(MINNODEDEEP,		   hiveConfig::ATTRIBUTE_INT);

	defineAttribute(SCENEMODEL,		   hiveConfig::ATTRIBUTE_STRING);
	defineAttribute(SCENEWIDTH,		   hiveConfig::ATTRIBUTE_INT);
	defineAttribute(SCENEHEIGHT,	   hiveConfig::ATTRIBUTE_INT);
	defineAttribute(AWAREAGENTMODEL,   hiveConfig::ATTRIBUTE_STRING);
	defineAttribute(IGNOREAGENTMODEL,  hiveConfig::ATTRIBUTE_STRING);
	defineAttribute(SCENEVERTEX,	   hiveConfig::ATTRIBUTE_STRING);
	defineAttribute(SCENEFRAG,		   hiveConfig::ATTRIBUTE_STRING);
	defineAttribute(AGENTVERTEX,	   hiveConfig::ATTRIBUTE_STRING);
	defineAttribute(AGENTFRAG,		   hiveConfig::ATTRIBUTE_STRING);
}

//*******************************************************************
//FUNCTION:
glm::vec3 hiveCrowdSimulation::CCrowdSimulationConfig::__fetchColor(const std::string& vName) const
{
	boost::tuple<float, float, float> Color = this->getAttribute<boost::tuple<double, double, double>>(vName);
	return glm::vec3(Color.get<0>(), Color.get<1>(), Color.get<2>());
}

//*******************************************************************
//FUNCTION:
glm::vec3 hiveCrowdSimulation::CCrowdSimulationConfig::getBackgroundColor() const
{
	return __fetchColor(BACKCOLOR);
}

//*******************************************************************
//FUNCTION:
glm::vec3 hiveCrowdSimulation::CCrowdSimulationConfig::getPassableColor() const
{
	return __fetchColor(PASSABLECOLOR);
}

//********************************************************************
//FUNCTION:
glm::vec3 hiveCrowdSimulation::CCrowdSimulationConfig::getAgentColor() const
{
	return __fetchColor(AGENTCOLOR);
}

//********************************************************************
//FUNCTION:
glm::vec3 hiveCrowdSimulation::CCrowdSimulationConfig::getObstacleColor() const
{
	return __fetchColor(OBSTACLECOLOR);
}

//********************************************************************
//FUNCTION:
glm::vec3 hiveCrowdSimulation::CCrowdSimulationConfig::getExitColor() const
{
	return __fetchColor(EXITCOLOR);
}