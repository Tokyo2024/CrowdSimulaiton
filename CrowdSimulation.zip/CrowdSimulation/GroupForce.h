#pragma once
#include <GLM/glm.hpp>

namespace hiveCrowdSimulation
{
	class CSubgroup;
	class CAgent;

	class CGroupForce
	{
	public:
		CGroupForce();
		~CGroupForce();

		static void computeGroupForceByGroupCenter(const CSubgroup* vSubgroup, const CAgent* vTargetAgent, glm::vec2& voForce);
		static void computeGroupForceByRoulette(const CSubgroup* vSubgroup, const CAgent* vTargetAgent, glm::vec2& voForce);
		static void computeGroupForceByDistance(const CSubgroup* vSubgroup, const CAgent* vTargetAgent, glm::vec2& voForce);
		static void computeGroupForceByIntimacy(const CSubgroup* vSubgroup, const CAgent* vTargetAgent, glm::vec2& voForce);
	};
}