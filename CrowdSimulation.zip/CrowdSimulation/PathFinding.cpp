#include "PathFinding.h"

hiveCrowdSimulation::CPathFinding::CPathFinding(void)
{
}

hiveCrowdSimulation::CPathFinding::~CPathFinding(void)
{
}