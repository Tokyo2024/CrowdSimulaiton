#include "AStar.h"
#include <algorithm>
#include "BaseGraph.h"

using namespace hiveCrowdSimulation;

CAstar::CAstar()
{
}

CAstar::~CAstar()
{
	__destructDataSet();
}

//********************************************************************
//FUNCTION:
void CAstar::__getSceneGridCoordSet(std::vector<glm::vec2>& voSceneGridCoordSet) const
{
	voSceneGridCoordSet.clear();
	SPoint* pEndPoint = m_ClosedList.back();
	do 
	{
		voSceneGridCoordSet.push_back(pEndPoint->Grid);
		pEndPoint = pEndPoint->pParent;
	}while (!(pEndPoint->Grid == m_ClosedList.back()->Grid));
	std::reverse(voSceneGridCoordSet.begin(), voSceneGridCoordSet.end());

	voSceneGridCoordSet.erase(voSceneGridCoordSet.begin());
}

//*******************************************************************
//FUNCTION:
bool CAstar::findShortestPathV(const CBaseGraph* vGraph, const glm::vec2& vStart, const glm::vec2& vEnd)
{
	return __execFindPathMethod(vGraph, vStart, vEnd);
}

//*******************************************************************
//FUNCTION:
float CAstar::getTotalCost()
{
	return m_ClosedList.back()->TotalCost;
}

//*******************************************************************
//FUNCTION:
bool CAstar::findShortestPathV(const CBaseGraph* vGraph, const glm::vec2& vStart, const glm::vec2& vEnd, std::vector<glm::vec2>& voSceneGridCoordSet)
{
	if (__execFindPathMethod(vGraph, vStart, vEnd))
	{
		__getSceneGridCoordSet(voSceneGridCoordSet);
		return true;
	}
	else
	{
		return false;
	}
}

//*******************************************************************
//FUNCTION:
SPoint* CAstar::__fetchPointFromList(const glm::vec2& vGrid, std::vector<SPoint*>& vPointList) const
{
	auto& Iter = vPointList.begin();
	for (; Iter!=vPointList.end(); ++Iter)
	{
		if ((*Iter)->Grid == vGrid)
			return *Iter;
	}

	return NULL;
}

//********************************************************************
//FUNCTION:
bool CAstar::__execFindPathMethod(const CBaseGraph* vGraph, const glm::vec2& vStart, const glm::vec2& vEnd)
{
	__destructDataSet();

	SPoint* pEndNode   = new SPoint(vEnd, NULL);
	SPoint* pStartNode = new SPoint(vStart, pEndNode, 0.0, vGraph->getCostOfSource2TargetPoint(vStart, vEnd));
	m_OpenList.push_back(pStartNode);

	do 
	{
		auto MinCost            = FLT_MAX;
		auto IsFindOptimalPoint = false;
		std::vector<SPoint*>::iterator OptimalPointIter;
		for (auto& Iter=m_OpenList.begin(); Iter!=m_OpenList.end(); ++Iter)
		{

			if ((*Iter)->TotalCost < MinCost)
			{
				MinCost            = (*Iter)->TotalCost;
				OptimalPointIter   = Iter;
				IsFindOptimalPoint = true;
			}
		}

		if (!IsFindOptimalPoint) 
		{
			delete pEndNode;
			return false;
		}

		SPoint* pOptimalPoint = *OptimalPointIter;
		m_ClosedList.push_back(pOptimalPoint);
		m_OpenList.erase(OptimalPointIter);

		std::vector<glm::vec2> AdjacentNodeSet;
		vGraph->getAdjacentNodeSet(pOptimalPoint->Grid, AdjacentNodeSet);

		for (auto& Node : AdjacentNodeSet)
		{
			if (__isInList(m_ClosedList, Node)) continue;
			else if(!__isInList(m_OpenList, Node))
			{
				double CostOfStart2Current = vGraph->getEdgeWeight(pOptimalPoint->Grid, Node) + pOptimalPoint->CostOfStart2Current;
				SPoint* pTempPoint         = new SPoint(Node, pOptimalPoint, CostOfStart2Current, vGraph->getCostOfSource2TargetPoint(Node, vEnd));
				m_OpenList.push_back(pTempPoint);
			}
			else if (__isInList(m_OpenList, Node))
			{
				SPoint* pNowPoint = __fetchPointFromList(Node, m_OpenList);
				double GCost      = vGraph->getEdgeWeight(pOptimalPoint->Grid, Node) + pOptimalPoint->CostOfStart2Current;
				if (GCost < pNowPoint->CostOfStart2Current)
				{
					pNowPoint->pParent             = pOptimalPoint;
					pNowPoint->CostOfStart2Current = GCost;
					pNowPoint->TotalCost           = pNowPoint->CostOfCurrent2End + pNowPoint->CostOfStart2Current;
				}
			}
		}
	}while (!(__isInList(m_OpenList, vEnd)));

	pEndNode->pParent = m_ClosedList.back();
	pEndNode->TotalCost = pEndNode->pParent->TotalCost;
	m_ClosedList.push_back(pEndNode);
	return true;
}

//********************************************************************
//FUNCTION:
void CAstar::__destructDataSet()
{
	for (auto& Point : m_OpenList)
		delete Point;

	for (auto& Point : m_ClosedList)
		delete Point;

	m_OpenList.resize(0);
	m_ClosedList.resize(0);
}

//*******************************************************************
//FUNCTION:
bool CAstar::__isInList(const std::vector<SPoint*>& vList, const glm::vec2& vSceneGrid) const
{
	for (auto& Point : vList)
	{
		if (Point->Grid == vSceneGrid) return true;
	}
	return false;
}