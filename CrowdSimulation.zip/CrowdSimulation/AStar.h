#pragma once
#include <vector>
#include "PathFindingAlgorithm.h"
#include "Common.h"

namespace hiveCrowdSimulation
{
	class CBaseGraph;

	class CAstar : public CPathFindingAlgorithm
	{
	public:
		CAstar();
		virtual ~CAstar();

		virtual bool findShortestPathV(const CBaseGraph* vGraph, const glm::vec2& vStart, const glm::vec2& vEnd) override;
		virtual float getTotalCost() override;
		virtual bool findShortestPathV(const CBaseGraph* vGraph, const glm::vec2& vStart, const glm::vec2& vEnd, std::vector<glm::vec2>& voSceneGridCoordSet) override;
		
	private:
		SPoint* __fetchPointFromList(const glm::vec2& vGrid, std::vector<SPoint*>& vPointList) const;
		bool    __isInList(const std::vector<SPoint*>& vList, const glm::vec2& vSceneGrid) const; 		
		bool    __execFindPathMethod(const CBaseGraph* vGraph, const glm::vec2& vStart, const glm::vec2& vEnd);
		void    __getSceneGridCoordSet(std::vector<glm::vec2>& voSceneGridCoordSet) const;
		void    __destructDataSet();

	private:
		std::vector<SPoint*> m_OpenList;
		std::vector<SPoint*> m_ClosedList;
	};
}