#pragma once
#include <vector>
#include <GLM/glm.hpp>
#include "common/WeightedDirectedGraph.h"

namespace hiveCrowdSimulation
{
	typedef hiveCommon::CWeightedDirectedGraph<glm::vec2>::GraphVertex GRAPHVERTEX;
	typedef hiveCommon::CWeightedDirectedGraph<glm::vec4>::GraphVertex NEWGRAPHVERTEX;

	class CScene;

	class CBaseGraph
	{
	public:
		CBaseGraph();
		virtual ~CBaseGraph();

		void         genGraph(CScene* vScene);
		void         findShortestPathUseDijkstra(const glm::vec2& vBeginNode, const glm::vec2& vEndNode, double& voLength, std::vector<glm::vec2>& voResult);
		void         updateEdgeWeight(const glm::vec2& vBeginNode, const glm::vec2& vEndNode, double vEdgeWeight);
		void         deleteNode(const glm::vec2& vTargetNode);
		void         getAdjacentNodeSet(const glm::vec2& vTargetNode, std::vector<glm::vec2>& voAdjacentNodeSet) const;
		double       getCostOfSource2TargetPoint(const glm::vec2& vBeginNode, const glm::vec2& vEndNode) const;
		double       getEdgeWeight(const glm::vec2& vBeginNode, const glm::vec2& vEndNode) const;
		unsigned int getNumEdges() const {return m_Graph.getNumEdges();}

	protected:
		virtual double _computeEdgeWeightV(const glm::vec2& vBegin, const glm::vec2& vEnd) const = 0;

	private:
		void        __addNode(glm::vec2 vGrid);
		void        __addEdge(const glm::vec2& vBeginNode, const glm::vec2& vEndNode, double vWeight);
		void        __findAndAddEdgesForAGrid(CScene* vScene, glm::vec2& vNode);
		
		GRAPHVERTEX __node2Index(const glm::vec2& vTargetNode) const ;
		glm::vec2   __index2Node(const GRAPHVERTEX& vTargetIndex) const;

	private:
		hiveCommon::CWeightedDirectedGraph<glm::vec2>  m_Graph;
		std::vector<std::pair<GRAPHVERTEX, glm::vec2>> m_Node2IndexVec;
	};
}