#include "SimulationInterface.h"
#include "opencv2/core/core.hpp"
#include "opencv2/highgui/highgui.hpp"
#include "FrameWork.h"
#include "GraphWithoutCrowd.h"
#include "GraphWithCrowd.h"
#include "QuadTreeNode.h"
#include "PrepareScene.h"
#include "Scene.h"
#include "AStar.h"
#include "BestNextFinding.h"
#include "VisualizationByOpenCV.h"
#include "CrowdSimulationConfig.h"

using namespace hiveCrowdSimulation;

//*******************************************************************
//FUNCTION:
CROWD_SIMULATION_DLL_EXPORT void hiveCrowdSimulation::initCrowdSimulation(const std::string& vAgentInfo, const std::string& vSceneInfo, const std::string& vSimulationInfo)
{
	CFramework::getInstance()->initFramework(vAgentInfo, vSceneInfo, vSimulationInfo);
}

//********************************************************************
//FUNCTION:
CROWD_SIMULATION_DLL_EXPORT void hiveCrowdSimulation::runCrowdSimulation(bool vIsOutputPosInfo2File)
{
	CFramework::getInstance()->runCrowdSimulation(vIsOutputPosInfo2File);
}

//********************************************************************
//FUNCTION:
CROWD_SIMULATION_DLL_EXPORT void hiveCrowdSimulation::genGraph(bool vIsCrowdDensityConsidered)
{
	CFramework::getInstance()->genGraph(vIsCrowdDensityConsidered);
}

//********************************************************************
//FUNCTION:
CROWD_SIMULATION_DLL_EXPORT bool hiveCrowdSimulation::testVisibility(const glm::vec2& vSource, const glm::vec2& vTarget, float vRadius)
{
	return CFramework::getInstance()->testVisibility(vSource, vTarget, vRadius);
}

//*******************************************************************
//FUNCTION:
CROWD_SIMULATION_DLL_EXPORT bool hiveCrowdSimulation::testPassibility(const glm::vec2& vGrid)
{
	return CFramework::getInstance()->testPassibility(vGrid);
}

//*******************************************************************
//FUNCTION:
CROWD_SIMULATION_DLL_EXPORT void hiveCrowdSimulation::testUpdatingGraphWithCrowd(const std::string& vAgentInfo, const std::string& vSceneInfo, const std::string& vSimulationInfo)
{
	initCrowdSimulation(vAgentInfo, vSceneInfo, vSimulationInfo);
	CScene* pScene = CFramework::getInstance()->getScene();
	const CBaseGraph* pGraph = CFramework::getInstance()->getGraphWithoutCrowd();

	std::vector<const CQuadTreeNode<SNode>*> PassableNodeSet;
	pScene->dumpPassableLeafNodes(PassableNodeSet);
	std::cout << "Input a numbers less than " << PassableNodeSet.size() - 1 << std::endl;
	int IndexA;
	std::cin >> IndexA;
	glm::vec2 LeafNodeCenterA = PassableNodeSet[IndexA]->getCenter();
	std::vector<glm::vec2> AdjNodeSet;
	pGraph->getAdjacentNodeSet(LeafNodeCenterA, AdjNodeSet);
	_ASSERT(AdjNodeSet.size() > 0);
	glm::vec2 LeafNodeCenterB = AdjNodeSet[0];

	float WeightBeforeDeleteCrowd = hiveCrowdSimulation::getEdgeWeight(LeafNodeCenterA, LeafNodeCenterB);

	CFramework::getInstance()->deleteAgentFromGrid(LeafNodeCenterA);
	CFramework::getInstance()->deleteAgentFromGrid(LeafNodeCenterB);
	CFramework::getInstance()->updateGraphWithCrowd(LeafNodeCenterA);
	CFramework::getInstance()->updateGraphWithCrowd(LeafNodeCenterB);

	float WeightAfterDeleteCrowd = CFramework::getInstance()->getEdgeWeight(LeafNodeCenterA, LeafNodeCenterB);
	printf("WeightBeforeDeleteCrowd: %f\n", WeightBeforeDeleteCrowd);
	printf("WeightAfterDeleteCrowd: %f\n", WeightAfterDeleteCrowd);
	if (WeightBeforeDeleteCrowd >= WeightAfterDeleteCrowd)
		printf("Test pass.\n");
	else
		printf("Test failed.\n");

	bool IsShowSceneGrid = true;
	CFramework::getInstance()->drawScene(IsShowSceneGrid);
	CFramework::getInstance()->displayCrowdDistribution();
	CFramework::getInstance()->drawLine(LeafNodeCenterA, LeafNodeCenterB, 2, glm::vec3(255, 0, 0));
	CFramework::getInstance()->drawPoint(LeafNodeCenterA, 3, glm::vec3(255, 255, 0), true);
	CFramework::getInstance()->drawPoint(LeafNodeCenterB, 3, glm::vec3(0, 255, 0), true);
	CFramework::getInstance()->display();
}

//********************************************************************
//FUNCTION:
CROWD_SIMULATION_DLL_EXPORT void hiveCrowdSimulation::testInitCrowdSimulation(const std::string& vAgentInfo, const std::string& vSceneInfo, const std::string& vSimulationInfo)
{
	CFramework::getInstance()->initFramework(vAgentInfo, vSceneInfo, vSimulationInfo);
	CFramework::getInstance()->clearScreen();
	CFramework::getInstance()->drawScene(true);
	CFramework::getInstance()->displayExit();
	CFramework::getInstance()->displayCrowdDistribution();
	CFramework::getInstance()->display();
}

//********************************************************************
//FUNCTION:
CROWD_SIMULATION_DLL_EXPORT void hiveCrowdSimulation::initDisPlayWithSpeiciedAttr(int vPWidth, int vPHeight, const glm::vec3& vBackColor)
{
	CFramework::getInstance()->initVisualization(vPWidth, vPHeight, vBackColor);
}

//********************************************************************
//FUNCTION:
CROWD_SIMULATION_DLL_EXPORT void hiveCrowdSimulation::clearScreen()
{
	CFramework::getInstance()->clearScreen();
}

//********************************************************************
//FUNCTION:
CROWD_SIMULATION_DLL_EXPORT void hiveCrowdSimulation::display()
{
	CFramework::getInstance()->display();
}

//*******************************************************************
//FUNCTION:
CROWD_SIMULATION_DLL_EXPORT void hiveCrowdSimulation::prepareScene()
{
	CFramework::getInstance()->drawScene(CCrowdSimulationConfig::getInstance()->getAttribute<bool>(ISSHOWSCENEGRID));
}

//*******************************************************************
//FUNCTION:
CROWD_SIMULATION_DLL_EXPORT void hiveCrowdSimulation::preparePath(const std::vector<glm::vec2>& vPointSet, float vRadius, const glm::vec3& vColor)
{
	CFramework::getInstance()->drawPath(vPointSet, vRadius, vColor);
}

//********************************************************************
//FUNCTION:
CROWD_SIMULATION_DLL_EXPORT void hiveCrowdSimulation::preparePoint(const glm::vec2& vCoord, float vRadius, const glm::vec3& vColor, bool vIsFilled)
{
	CFramework::getInstance()->drawPoint(vCoord, vRadius, vColor, vIsFilled);
}

//********************************************************************
//FUNCTION:
CROWD_SIMULATION_DLL_EXPORT void hiveCrowdSimulation::prepareLine(const glm::vec2& vPointA, const glm::vec2& vPointB, float vLineThickness, const glm::vec3& vLineColor)
{
	CFramework::getInstance()->drawLine(vPointA, vPointB, vLineThickness, vLineColor);
}

//********************************************************************
//FUNCTION:
CROWD_SIMULATION_DLL_EXPORT void hiveCrowdSimulation::genScene(const std::string& vBitmapFile)
{
	CFramework::getInstance()->parseAndGenScene(vBitmapFile);
}

//********************************************************************
//FUNCTION:
CROWD_SIMULATION_DLL_EXPORT void hiveCrowdSimulation::findShortestPath(bool vIsCrowdDensityConsidered, const glm::vec2& vStart, const glm::vec2& vEnd, std::vector<glm::vec2>& voResults)
{
	CFramework::getInstance()->findShortestPath(vIsCrowdDensityConsidered, vStart, vEnd, voResults);
}

//********************************************************************
//FUNCTION:
CROWD_SIMULATION_DLL_EXPORT void hiveCrowdSimulation::findPathUseDijkstra(bool vIsCrowdDensityConsidered, const glm::vec2& vStart, const glm::vec2& vEnd, double& voLength, std::vector<glm::vec2>& voResults)
{
	CFramework::getInstance()->findShortestPathUseDijkstra(vIsCrowdDensityConsidered, vStart, vEnd, voLength, voResults);
}

//*******************************************************************
//FUNCTION:
CROWD_SIMULATION_DLL_EXPORT void hiveCrowdSimulation::initAgentAndSimulationConfig(const std::string& vSceneInfo, const std::string& vSimulationInfo)
{
	CFramework::getInstance()->initAgentAndSimulationConfig(vSceneInfo, vSimulationInfo);
}

//********************************************************************
//FUNCTION:
CROWD_SIMULATION_DLL_EXPORT bool hiveCrowdSimulation::testUpdatingEdgeWeight(const std::string& vSceneInfo, const glm::vec2& vStart, const glm::vec2& vEnd, double vLength, bool vIsConsiderCrowdDensity)
{
	CFramework::getInstance()->parseAndGenScene(vSceneInfo);
	genGraph(vIsConsiderCrowdDensity);
	CScene* pScene = CFramework::getInstance()->getScene();
	const CQuadTreeNode<SNode>* pStartNode = pScene->getLeafNodeBySceneCoord(vStart);
	const CQuadTreeNode<SNode>* pEndNode = pScene->getLeafNodeBySceneCoord(vEnd);
	glm::vec2 CenterStart = pStartNode->getCenter();
	glm::vec2 CenterEnd = pEndNode->getCenter();
	CFramework::getInstance()->resetEdgeWeight(CenterStart, CenterEnd, vLength, vIsConsiderCrowdDensity);
	return (float)CFramework::getInstance()->queryEdgeWeight(CenterStart, CenterEnd, vIsConsiderCrowdDensity) == (float)vLength;
}

//********************************************************************
//FUNCTION:
CROWD_SIMULATION_DLL_EXPORT void hiveCrowdSimulation::computeAllPointsOnLine(const glm::vec2& vArrayCoordA, const glm::vec2& vArrayCoordB, std::vector<glm::vec2>& vResult)
{
	CFramework::getInstance()->computeGridCoordBetweenTwoGrids(vArrayCoordA, vArrayCoordB, vResult);
}

//********************************************************************
//FUNCTION:
CROWD_SIMULATION_DLL_EXPORT void hiveCrowdSimulation::testDisplayingSimulationResultByOpenCV(const std::string& vRunConfig, const std::string& vSimulationResult)
{
	CFramework::getInstance()->displayingSimulationResultByOpenCV(vRunConfig, vSimulationResult);
}

//********************************************************************
//FUNCTION:
CROWD_SIMULATION_DLL_EXPORT void hiveCrowdSimulation::testDisplayingSimulationResultByOpenGL(const std::string& vRunConfig, const std::string& vSimulationResult)
{
	CFramework::getInstance()->displayingSimulationResultByOpenGL(vRunConfig, vSimulationResult);
}

//********************************************************************
//FUNCTION:
CROWD_SIMULATION_DLL_EXPORT void hiveCrowdSimulation::initAgentConfig(const std::string& vAgentInfo)
{
	CFramework::getInstance()->initAgentConfig(vAgentInfo);
}

//********************************************************************
//FUNCTION:
CROWD_SIMULATION_DLL_EXPORT void hiveCrowdSimulation::initSimulationConfig(const std::string& vSimulationInfo)
{
	CFramework::getInstance()->initSimulationConfig(vSimulationInfo);
}

//********************************************************************
//FUNCTION:
CROWD_SIMULATION_DLL_EXPORT float hiveCrowdSimulation::testGuassDistributionFunc(const std::vector<glm::vec2>& vDataSet, const glm::vec2& vData)
{
	return hiveCrowdSimulation::exceGuassDistributionFunc(vDataSet, vData);
}

//********************************************************************
//FUNCTION:
CROWD_SIMULATION_DLL_EXPORT void hiveCrowdSimulation::testKNNSearch(const std::string& vSceneInfo, const std::vector<glm::vec2>& vDataSet, const glm::vec2& vData, unsigned int vNumOptimalNeighbor)
{
	CFramework::getInstance()->parseAndGenScene(vSceneInfo);
	std::vector<unsigned int> OptimalNeighborIndexSet;
	CFramework::getInstance()->executeKNNSearch(vDataSet, vData, vNumOptimalNeighbor, OptimalNeighborIndexSet); 

	CScene* pScene = CFramework::getInstance()->getScene();
	_ASSERT(pScene);
	CFramework::getInstance()->initVisualization(pScene->getSceneWidth(), pScene->getSceneHeight(), glm::vec3(0, 0, 0));
	CFramework::getInstance()->drawScene(true);
	CFramework::getInstance()->drawPath(vDataSet, 5, glm::vec3(255, 0, 0));

	std::vector<glm::vec2> ResultSet;
	for (unsigned int i=0; i<OptimalNeighborIndexSet.size(); i++)
		ResultSet.push_back(vDataSet[OptimalNeighborIndexSet[i]]);
	CFramework::getInstance()->drawPath(ResultSet, 3, glm::vec3(0, 255, 0));
	CFramework::getInstance()->drawPoint(vData, 5, glm::vec3(0, 0, 255), true);
	CFramework::getInstance()->display();
}

//********************************************************************
//FUNCTION:
CROWD_SIMULATION_DLL_EXPORT float hiveCrowdSimulation::getEdgeWeight(const glm::vec2& vScenePosA, const glm::vec2& vScenePosB)
{
	return CFramework::getInstance()->getEdgeWeight(vScenePosA, vScenePosB);
}

//********************************************************************
//FUNCTION:
CROWD_SIMULATION_DLL_EXPORT void hiveCrowdSimulation::testFindingBestNext(const std::string& vSceneInfo, const std::string& vAgentInfo, const glm::vec2& vStart, const glm::vec2& vEnd, float vViewableDistance, glm::vec2& voBestNext, std::vector<glm::vec2>& voRoad)
{
	CFramework::getInstance()->parseAndGenScene(vSceneInfo);
	CFramework::getInstance()->initAgentConfig(vAgentInfo);
	CFramework::getInstance()->initSimulationConfig("Simulation.xml");
	CFramework::getInstance()->genGraph(true);
	CScene* pScene = CFramework::getInstance()->getScene();
	_ASSERT(pScene);
	CFramework::getInstance()->initVisualization(pScene->getSceneWidth(), pScene->getSceneHeight(), glm::vec3(0, 0, 0));
	hiveCrowdRendering::CVisualization* pVisualize = CFramework::getInstance()->getVisualization();
	_ASSERT(pVisualize);

	CGraphWithCrowd* pGraphWithCrowd = new CGraphWithCrowd(pScene);
	pGraphWithCrowd->genGraph(pScene);
	CGraphWithoutCrowd* pGraphWithoutCrowd = new CGraphWithoutCrowd();
	pGraphWithoutCrowd->genGraph(pScene);
	CPathFinding* pAStar = new CAStar();
	CBestNextFinding* pBestNextFinding = new CBestNextFinding();

	pBestNextFinding->setPathFindingAlgorithm(pAStar);
//	voBestNext = pBestNextFinding->fetchBestNext(vStart, vEnd, pScene, pGraphWithoutCrowd, pGraphWithCrowd, vViewableDistance, voRoad);
	voBestNext = pBestNextFinding->fetchBestNext(vStart, vEnd, pScene, pGraphWithoutCrowd, pGraphWithoutCrowd, vViewableDistance, voRoad);

	CFramework::getInstance()->drawScene(true);
	pVisualize->drawPoint(vStart, 3.0, glm::vec3(0, 255, 0), true);
	pVisualize->drawPoint(vEnd, 3.0, glm::vec3(0, 0, 255), true);
	float DistanceStart2Best = sqrt((vStart.x - voBestNext.x)*(vStart.x - voBestNext.x) + (vStart.y - voBestNext.y)*(vStart.y - voBestNext.y));
	pVisualize->drawPoint(vStart, DistanceStart2Best, glm::vec3(255, 255, 255), false);
	for (auto& Point : voRoad)
	{
		pVisualize->drawPoint(Point, 2.0, glm::vec3(255, 255, 255), true);
	}
	pVisualize->display();

	delete pAStar;
	delete pBestNextFinding;
	delete pGraphWithCrowd;
	delete pGraphWithoutCrowd;
}

//********************************************************************
//FUNCTION:
CROWD_SIMULATION_DLL_EXPORT bool hiveCrowdSimulation::testQueryingEdgeWeight(const std::string& vSceneInfo, const glm::vec2& vStart, const glm::vec2& vEnd, bool vIsConsiderCrowdDensity)
{
	CFramework::getInstance()->parseAndGenScene(vSceneInfo);
	genGraph(vIsConsiderCrowdDensity);
	CScene* pScene = CFramework::getInstance()->getScene();
	const CQuadTreeNode<SNode>* pStartNode = pScene->getLeafNodeBySceneCoord(vStart);
	const CQuadTreeNode<SNode>* pEndNode = pScene->getLeafNodeBySceneCoord(vEnd);
	glm::vec2 CenterStart = pStartNode->getCenter();
	glm::vec2 CenterEnd = pEndNode->getCenter();
	float Distance = sqrt((double)(CenterEnd.x - CenterStart.x) * (double)(CenterEnd.x - CenterStart.x) + (double)(CenterEnd.y - CenterStart.y) * (double)(CenterEnd.y - CenterStart.y));
	return (float)CFramework::getInstance()->queryEdgeWeight(vStart, vEnd, vIsConsiderCrowdDensity) == Distance;
}

//********************************************************************
//FUNCTION:
CROWD_SIMULATION_DLL_EXPORT void hiveCrowdSimulation::testMergingGroup(const std::vector<std::vector<glm::vec2>>& vGroupAgentPosSet, const std::string& vRunConfig, int& voNumSugroup)
{
	CFramework::getInstance()->mergeGroup(vGroupAgentPosSet, vRunConfig, voNumSugroup);
}

//********************************************************************
//FUNCTION:
CROWD_SIMULATION_DLL_EXPORT void hiveCrowdSimulation::testSplitingGroup(const std::vector<std::vector<glm::vec2>>& vGroupAgentPosSet, const std::string& vRunConfig, int& voNumSugroup)
{
	CFramework::getInstance()->splitGroup(vGroupAgentPosSet, vRunConfig, voNumSugroup);
}

//********************************************************************
//FUNCTION:
CROWD_SIMULATION_DLL_EXPORT void hiveCrowdSimulation::testStartingMakeDecision(const std::vector<glm::vec2>& vSubgroupPosSet, const glm::vec2& vLostPos, const std::vector<float>& vIntimacySet, const std::string& vRunConfig, int& voNumTask)
{
	CFramework::getInstance()->startMakeDecision(vSubgroupPosSet, vLostPos, vIntimacySet, vRunConfig, voNumTask);
}

//********************************************************************
//FUNCTION:
CROWD_SIMULATION_DLL_EXPORT void hiveCrowdSimulation::testFindingLostAgentProcessSuccessful(const glm::vec2& vPosSrc, const glm::vec2& vPosDst, const std::string& vRunConfig)
{
	CFramework::getInstance()->finishFindingLostAgent(vPosSrc, vPosDst, vRunConfig);
}

//********************************************************************
//FUNCTION:
CROWD_SIMULATION_DLL_EXPORT void hiveCrowdSimulation::testFindingLostAgentProcessUnsuccessful(const glm::vec2& vPosSrc, const glm::vec2& vPosDst, const std::string& vRunConfig, bool& voIsGivingUp)
{
	CFramework::getInstance()->giveUpFindingLostAgent(vPosSrc, vPosDst, vRunConfig, voIsGivingUp);
}

//********************************************************************
//FUNCTION:
CROWD_SIMULATION_DLL_EXPORT void hiveCrowdSimulation::testClashingBetweenGroups(const glm::vec2& vGroupAPos, unsigned int vGroupASize, const glm::vec2& vGroupBPos, unsigned int vGroupBSize, const std::string& vRunConfig) //������������ã�
{
	CFramework::getInstance()->clashBetweenGroups(vGroupAPos, vGroupASize, vGroupBPos, vGroupBSize, vRunConfig);
}

//********************************************************************
//FUNCTION:
CROWD_SIMULATION_DLL_EXPORT void hiveCrowdSimulation::testLoadingSceneImage(const std::string& vBitmapFile, const std::string& vSimulationFile)
{
	_ASSERT(!vBitmapFile.empty());
	CPrepareScene::getInstance()->parseSceneImage(vBitmapFile);
	CFramework::getInstance()->initSimulationConfig(vSimulationFile);
	int PWidth = CPrepareScene::getInstance()->getSceneWidth();
	int PHeight = CPrepareScene::getInstance()->getSceneHeight();
	char* pPixelInfo = CPrepareScene::getInstance()->getImageData();

	glm::vec3 ObstacleColor = glm::vec3(0, 0, 255);
	cv::Scalar BackColor = cv::Scalar(0, 0, 0);
	glm::vec3 ExitColor = glm::vec3(255 ,0, 0);
	hiveCrowdRendering::CVisualizationByOpenCV* pVisualize = new hiveCrowdRendering::CVisualizationByOpenCV(PWidth, PHeight, BackColor);

	int ExitNumber = CPrepareScene::getInstance()->getNumExit();
	glm::vec2 ExitPosition, LeftUpPosition, RightDownPosition;
	for (int i=0; i<ExitNumber; i++)
	{
		ExitPosition = CPrepareScene::getInstance()->getExit(i);
		LeftUpPosition = glm::vec2(ExitPosition.x - 4, ExitPosition.y - 4);
		RightDownPosition = glm::vec2(ExitPosition.x + 4, ExitPosition.y + 4);
		pVisualize->drawRectangle(LeftUpPosition, RightDownPosition, ExitColor, true);
	}

	for (int i=0; i<PWidth; i++)
	{
		for (int k=0; k<PHeight; k++)
		{
			if (!pPixelInfo[i*PWidth+k])   //only dispay obstacle
				pVisualize->drawPoint(glm::vec2(k, i), 1, ObstacleColor, true);	
		}
	}
	pVisualize->display();

	delete pVisualize;
	delete pPixelInfo;
}

//********************************************************************
//FUNCTION:
CROWD_SIMULATION_DLL_EXPORT void hiveCrowdSimulation::testCreatingQuadtree(const std::string& vBitmapFile, const std::string& vSimulationFile)
{
	CFramework::getInstance()->parseAndGenScene(vBitmapFile);
	CFramework::getInstance()->initSimulationConfig(vSimulationFile);
	CScene* pScene = CFramework::getInstance()->getScene();
	_ASSERT(pScene);

	hiveCrowdRendering::CVisualizationByOpenCV* pVisualize = new hiveCrowdRendering::CVisualizationByOpenCV(pScene->getSceneWidth(), pScene->getSceneHeight(), cv::Scalar(0, 0, 0));
	glm::vec3 ObstacleColor = glm::vec3(0, 0, 255);
	glm::vec3 PassableColor = glm::vec3(255, 255, 0);
	std::vector<const CQuadTreeNode<SNode>*> LeafNodeSet;
	pScene->dumpAllLeafNode(LeafNodeSet);
	CFramework::getInstance()->drawScene(pVisualize, LeafNodeSet, PassableColor, ObstacleColor);
	for (auto& LeafNode : LeafNodeSet)
	{
		glm::vec4 Rec = LeafNode->getRectangle();
		pVisualize->drawRectangle(glm::vec2(Rec.x, Rec.y), glm::vec2(Rec.z, Rec.w), glm::vec3(255, 255, 255), false);
	}
	pVisualize->display();
	delete pVisualize;
}

//********************************************************************
//FUNCTION:
CROWD_SIMULATION_DLL_EXPORT void hiveCrowdSimulation::testFindingNeighborhoodByQuadTree(const std::string& vBitmapFile, const std::string& vSimulationFile)
{
	CFramework::getInstance()->parseAndGenScene(vBitmapFile);
	CFramework::getInstance()->initSimulationConfig(vSimulationFile);
	CScene* pScene = CFramework::getInstance()->getScene();
	_ASSERT(pScene);

	std::vector<const CQuadTreeNode<SNode>*> AlternativeLeafNodeSet;
	pScene->dumpPassableLeafNodes(AlternativeLeafNodeSet);

	initSeed(time(0));
	int RandomTestingIndex = getIntRandom(0, AlternativeLeafNodeSet.size()-1);
	const CQuadTreeNode<SNode>* pTestingNode = AlternativeLeafNodeSet[RandomTestingIndex];

	hiveCrowdRendering::CVisualizationByOpenCV* pVisualize = new hiveCrowdRendering::CVisualizationByOpenCV(pScene->getSceneWidth(), pScene->getSceneHeight(), cv::Scalar(0, 0, 0));
	glm::vec3 ObstacleColor = glm::vec3(0, 0, 255);
	glm::vec3 PassableColor = glm::vec3(0, 0, 0);

	std::vector<const CQuadTreeNode<SNode>*> LeafNodeSet;
	pScene->dumpAllLeafNode(LeafNodeSet);
	CFramework::getInstance()->drawScene(pVisualize, LeafNodeSet, PassableColor, ObstacleColor);
	glm::vec4 TestNodeRect = pTestingNode->getRectangle();
	pVisualize->drawRectangle(glm::vec2(TestNodeRect.x, TestNodeRect.y), glm::vec2(TestNodeRect.z, TestNodeRect.w), glm::vec3(0, 255, 0), true);
	std::vector<CQuadTreeNode<SNode>*> AdjNodeSet;
	pScene->findAdjNode(pTestingNode, AdjNodeSet);
	for (auto& Node : AdjNodeSet)
	{
		glm::vec4 Rectangle = Node->getRectangle();
		pVisualize->drawRectangle(glm::vec2(Rectangle.x, Rectangle.y), glm::vec2(Rectangle.z, Rectangle.w), glm::vec3(255, 255, 0), true);
		pVisualize->drawRectangle(glm::vec2(Rectangle.x, Rectangle.y), glm::vec2(Rectangle.z, Rectangle.w), glm::vec3(255, 255, 255), false);
	}
	for (auto& LeafNode : LeafNodeSet)
	{
		glm::vec4 Rectangle = LeafNode->getRectangle();
		pVisualize->drawRectangle(glm::vec2(Rectangle.x, Rectangle.y), glm::vec2(Rectangle.z, Rectangle.w), glm::vec3(255, 255, 255), false);
	}

	pVisualize->display();
	delete pVisualize;
}

//*******************************************************************
//FUNCTION:
CROWD_SIMULATION_DLL_EXPORT void hiveCrowdSimulation::testFindingNeighborhoodByGraph(const std::string& vBitmapFile, const std::string& vSimulationFile)
{
	CFramework::getInstance()->parseAndGenScene(vBitmapFile);
	CFramework::getInstance()->initSimulationConfig(vSimulationFile);
	CScene* pScene = CFramework::getInstance()->getScene();
	_ASSERT(pScene);
	hiveCrowdRendering::CVisualizationByOpenCV* pVisualize = new hiveCrowdRendering::CVisualizationByOpenCV(pScene->getSceneWidth(), pScene->getSceneHeight(), cv::Scalar(0, 0, 0));

	CGraphWithoutCrowd* pBaseGraph = new CGraphWithoutCrowd();
	pBaseGraph->genGraph(pScene);

	std::vector<const CQuadTreeNode<SNode>*> AlternativeLeafNodeSet;
	pScene->dumpPassableLeafNodes(AlternativeLeafNodeSet);

	initSeed(time(0));
	int RandomTestingIndex = getIntRandom(0, AlternativeLeafNodeSet.size()-1);
	const CQuadTreeNode<SNode>* pTestingNode = AlternativeLeafNodeSet[RandomTestingIndex];

	std::vector<glm::vec2> AdjNodeSet;
	pBaseGraph->getAdjacentNodeSet(pTestingNode->getCenter(), AdjNodeSet);

	glm::vec3 ObstacleColor = glm::vec3(0, 0, 255);
	glm::vec3 PassableColor = glm::vec3(0, 0, 0);
	std::vector<const CQuadTreeNode<SNode>*> LeafNodeSet;
	pScene->dumpAllLeafNode(LeafNodeSet);

	CFramework::getInstance()->drawScene(pVisualize, LeafNodeSet, PassableColor, ObstacleColor);
	glm::vec4 TestNodeRect = pTestingNode->getRectangle();
	pVisualize->drawRectangle(glm::vec2(TestNodeRect.x, TestNodeRect.y), glm::vec2(TestNodeRect.z, TestNodeRect.w), glm::vec3(0, 255, 0), true);

	for (auto& NodeCenter : AdjNodeSet)
	{
		const CQuadTreeNode<SNode>* pNode = pScene->getLeafNodeBySceneCoord(NodeCenter);
		glm::vec4 NodeRectangle = pNode->getRectangle();
		pVisualize->drawRectangle(glm::vec2(NodeRectangle.x, NodeRectangle.y), glm::vec2(NodeRectangle.z, NodeRectangle.w), glm::vec3(255, 255, 0), true);
		pVisualize->drawLine(pTestingNode->getCenter(), NodeCenter, glm::vec3(0, 255, 0), 2);
	}
	for (auto& LeafNode : LeafNodeSet)
	{
		glm::vec4 Rectangle = LeafNode->getRectangle();
		pVisualize->drawRectangle(glm::vec2(Rectangle.x, Rectangle.y), glm::vec2(Rectangle.z, Rectangle.w), glm::vec3(255, 255, 255), false);

	}
		
	pVisualize->display();

	delete pVisualize;
}

//*******************************************************************
//FUNCTION:
CROWD_SIMULATION_DLL_EXPORT void hiveCrowdSimulation::testComputingGridCoordBetweenTwoGrids(const std::string& vBitmapFile, const glm::vec2& vEye, const glm::vec2& vTarget)
{
	CFramework::getInstance()->parseAndGenScene(vBitmapFile);
	CScene* pScene = CFramework::getInstance()->getScene();
	_ASSERT(pScene);
	_ASSERT(!pScene->isPosExceedBorder(vEye));
	_ASSERT(!pScene->isPosExceedBorder(vTarget));
	hiveCrowdRendering::CVisualizationByOpenCV* pVisualize = new hiveCrowdRendering::CVisualizationByOpenCV(pScene->getSceneWidth(), pScene->getSceneHeight(), cv::Scalar(0, 0, 0));

	std::vector<glm::vec2> ResultSet;
	pScene->computeGridCoordBetweenTwoGrids(vEye, vTarget, ResultSet);

	for (size_t i=0; i<pScene->getBaseNodeSizeOfY(); ++i)
	{
		for (size_t k=0; k<pScene->getBaseNodeSizeOfX(); ++k)
		{
			const CQuadTreeNode<SNode>* pNode = pScene->getBaseNode(i, k);
			glm::vec4 BasicNodeRect = pNode->getRectangle();
			pVisualize->drawRectangle(glm::vec2(BasicNodeRect.x, BasicNodeRect.y), glm::vec2(BasicNodeRect.z, BasicNodeRect.w), glm::vec3(255, 0, 0), false);
		}
	}

	for (auto Coord : ResultSet)
	{
		const CQuadTreeNode<SNode>* pNode = pScene->getBaseNode(Coord.y, Coord.x);
		glm::vec4 BasicNodeRect = pNode->getRectangle();
		pVisualize->drawRectangle(glm::vec2(BasicNodeRect.x, BasicNodeRect.y), glm::vec2(BasicNodeRect.z, BasicNodeRect.w), glm::vec3(255, 255, 0), true);
	}

	pVisualize->drawPoint(vEye, 5, glm::vec3(0, 255, 0), true);
	pVisualize->drawPoint(vTarget, 5, glm::vec3(0, 255, 0), true);
	pVisualize->drawLine(vEye, vTarget, glm::vec3(0, 0, 0), 1);
	pVisualize->display();

	delete pVisualize;
}

//*******************************************************************
//FUNCTION:	
CROWD_SIMULATION_DLL_EXPORT bool hiveCrowdSimulation::testIsVisiable(const std::string& vBitmapFile, const glm::vec2& vEye, const glm::vec2& vTarget, const std::string& vSimulationFile)
{
	CFramework::getInstance()->parseAndGenScene(vBitmapFile);
	CFramework::getInstance()->initSimulationConfig(vSimulationFile);
	CScene* pScene = CFramework::getInstance()->getScene();
	_ASSERT(pScene);
	_ASSERT(!pScene->isPosExceedBorder(vEye));
	_ASSERT(!pScene->isPosExceedBorder(vTarget));

	hiveCrowdRendering::CVisualizationByOpenCV* pVisualize = new hiveCrowdRendering::CVisualizationByOpenCV(pScene->getSceneWidth(), pScene->getSceneHeight(), cv::Scalar(0, 0, 0));

	glm::vec3 ObstacleColor = glm::vec3(0, 0, 255);
	glm::vec3 PassableColor = glm::vec3(255, 255, 255);
	std::vector<const CQuadTreeNode<SNode>*> LeafNodeSet;
	pScene->dumpAllLeafNode(LeafNodeSet);

	CFramework::getInstance()->drawScene(pVisualize, LeafNodeSet, PassableColor, ObstacleColor);

	pVisualize->drawLine(vEye, vTarget, glm::vec3(0, 255, 0), 1.0);
	pVisualize->display();
	delete pVisualize;

	return pScene->isVisible(vEye, vTarget, 1000);
}

//********************************************************************
//FUNCTION:
CROWD_SIMULATION_DLL_EXPORT void hiveCrowdSimulation::testGettingAllLeafNodeIntersect2SpecifiedLine(const std::string& vBitmapFile, const std::string& vSimulationFile, const glm::vec2& vEye, const glm::vec2& vTarget)
{
	CFramework::getInstance()->parseAndGenScene(vBitmapFile);
	CFramework::getInstance()->initSimulationConfig(vSimulationFile);
	CScene* pScene = CFramework::getInstance()->getScene();
	_ASSERT(pScene);
	_ASSERT(!pScene->isPosExceedBorder(vEye));
	_ASSERT(!pScene->isPosExceedBorder(vTarget));

	hiveCrowdRendering::CVisualizationByOpenCV* pVisualize = new hiveCrowdRendering::CVisualizationByOpenCV(pScene->getSceneWidth(), pScene->getSceneHeight(), cv::Scalar(0, 0, 0));
	glm::vec3 ObstacleColor = glm::vec3(0, 0, 255);
	glm::vec3 PassableColor = glm::vec3(255, 0, 0);
	std::vector<const CQuadTreeNode<SNode>*> LeafNodeSet;
	pScene->dumpAllLeafNode(LeafNodeSet);
	CFramework::getInstance()->drawScene(pVisualize, LeafNodeSet, PassableColor, ObstacleColor);
	for (auto& LeafNode : LeafNodeSet)
	{
		glm::vec4 Rec = LeafNode->getRectangle();
		pVisualize->drawRectangle(glm::vec2(Rec.x, Rec.y), glm::vec2(Rec.z, Rec.w), glm::vec3(255, 255, 255), false);
	}

	std::vector<glm::vec2> BasicGridSet;
	pScene->computeGridCoordBetweenTwoGrids(vEye, vTarget, BasicGridSet);
	std::vector<const CQuadTreeNode<SNode>*> NodeSet;
	SStraightLine Line = SStraightLine(vEye, vTarget);
	for (auto& Coord : BasicGridSet)
	{
		const CQuadTreeNode<SNode>* pNode = pScene->getBaseNode(Coord.y, Coord.x);
		pScene->dumpRectangleIntersect2Line(Line, pNode, NodeSet);
	}
	PassableColor = glm::vec3(255, 255, 255);
	ObstacleColor = glm::vec3(255, 255, 255);
	CFramework::getInstance()->drawScene(pVisualize, NodeSet, PassableColor, ObstacleColor);
	pVisualize->drawLine(vEye, vTarget, glm::vec3(255, 255, 0), 2.0);
	pVisualize->display();
	delete pVisualize;
}

//*******************************************************************
//FUNCTION:	
CROWD_SIMULATION_DLL_EXPORT void hiveCrowdSimulation::testDumpingNodeInSight(const std::string& vSceneInfo, glm::vec2 vEye, float vViewableDistance, std::vector<glm::vec4>& voNodeSet)
{
	glm::vec3 NoPassColor = glm::vec3(255, 255, 0);
	glm::vec3 PassColor   = glm::vec3(0, 255, 0);
	glm::vec3 NodeColor   = glm::vec3(255, 255, 255);
	glm::vec3 EyeColor    = glm::vec3(0, 0, 255);
	std::vector<const CQuadTreeNode<SNode>*> SurroundNodeSet;
	std::vector<const CQuadTreeNode<SNode>*> NopassableNodeSet;
	std::vector<const CQuadTreeNode<SNode>*> PassableNodeSet;
	CFramework::getInstance()->parseAndGenScene(vSceneInfo);
	genGraph(false);
	CScene* pScene = CFramework::getInstance()->getScene();

	pScene->dumpNodeInSight(vEye, vViewableDistance, SurroundNodeSet);
	for (auto Node : SurroundNodeSet)
		voNodeSet.push_back(Node->getRectangle());
	pScene->dumpNoPassableLeafNodes(NopassableNodeSet);
	pScene->dumpPassableLeafNodes(PassableNodeSet);

	hiveCrowdRendering::CVisualizationByOpenCV* pVisualize = new hiveCrowdRendering::CVisualizationByOpenCV(pScene->getSceneWidth(), pScene->getSceneHeight(), cv::Scalar(0, 0, 0));
	for (auto& NopassableNode : NopassableNodeSet)
		pVisualize->drawRectangle(glm::vec2(NopassableNode->getRectangle().x, NopassableNode->getRectangle().y), glm::vec2(NopassableNode->getRectangle().z, NopassableNode->getRectangle().w), NoPassColor, true);
	for (auto& PassableNode : PassableNodeSet)
		pVisualize->drawRectangle(glm::vec2(PassableNode->getRectangle().x, PassableNode->getRectangle().y), glm::vec2(PassableNode->getRectangle().z, PassableNode->getRectangle().w), PassColor, false);
	for (auto& NoPassRect : voNodeSet)
		pVisualize->drawRectangle(glm::vec2(NoPassRect.x, NoPassRect.y), glm::vec2(NoPassRect.z, NoPassRect.w), NodeColor, true);
	pVisualize->drawPoint(vEye, 8, EyeColor, true);

	glm::vec4 ViewableRectangle;
	ViewableRectangle.x = std::max((float)0.0, vEye.x - vViewableDistance);
	ViewableRectangle.y = std::max((float)0.0, vEye.y - vViewableDistance);
	ViewableRectangle.z = std::min((float)pScene->getSceneWidth(), vEye.x + vViewableDistance);
	ViewableRectangle.w = std::min((float)pScene->getSceneHeight(), vEye.y + vViewableDistance);
	pVisualize->drawRectangle(glm::vec2(ViewableRectangle.x, ViewableRectangle.y), glm::vec2(ViewableRectangle.z, ViewableRectangle.w), glm::vec3(255, 0, 0), false);
	pVisualize->display();

	delete pVisualize;
}

//********************************************************************
//FUNCTION:
CROWD_SIMULATION_DLL_EXPORT void hiveCrowdSimulation::testGettingLeafNodeBySceneCoord(const std::string& vBitmapFile, const std::string& vSimulationFile, const glm::vec2& vCoord)
{
	CFramework::getInstance()->parseAndGenScene(vBitmapFile);
	CFramework::getInstance()->initSimulationConfig(vSimulationFile);
	CScene* pScene = CFramework::getInstance()->getScene();
	_ASSERT(pScene);
	_ASSERT(!pScene->isPosExceedBorder(vCoord));

	hiveCrowdRendering::CVisualizationByOpenCV* pVisualize = new hiveCrowdRendering::CVisualizationByOpenCV(pScene->getSceneWidth(), pScene->getSceneHeight(), cv::Scalar(0, 0, 0));
	glm::vec3 ObstacleColor = glm::vec3(0, 0, 255);
	glm::vec3 PassableColor = glm::vec3(255, 255, 0);
	std::vector<const CQuadTreeNode<SNode>*> LeafNodeSet;
	pScene->dumpAllLeafNode(LeafNodeSet);
	CFramework::getInstance()->drawScene(pVisualize, LeafNodeSet, PassableColor, ObstacleColor);
	for (auto& LeafNode : LeafNodeSet)
	{
		glm::vec4 Rec = LeafNode->getRectangle();
		pVisualize->drawRectangle(glm::vec2(Rec.x, Rec.y), glm::vec2(Rec.z, Rec.w), glm::vec3(255, 255, 255), false);
	}

	const CQuadTreeNode<SNode>* pNode = pScene->getLeafNodeBySceneCoord(vCoord);
	glm::vec4 Rectangle = pNode->getRectangle();
	pVisualize->drawRectangle(glm::vec2(Rectangle.x, Rectangle.y), glm::vec2(Rectangle.z, Rectangle.w), glm::vec3(255, 0, 0), true);
	pVisualize->drawPoint(vCoord, 3.0, glm::vec3(0, 255, 255), true);
	pVisualize->display();
	delete pVisualize;
}

//********************************************************************
//FUNCTION:
CROWD_SIMULATION_DLL_EXPORT void hiveCrowdSimulation::testRotateVector(const glm::vec2& vPoint, const glm::vec2& vVector, float vAngle, const std::string& vBitmapFile, const std::string& vSimulationFile)
{
	CFramework::getInstance()->parseAndGenScene(vBitmapFile);
	CFramework::getInstance()->initSimulationConfig(vSimulationFile);
	CScene* pScene = CFramework::getInstance()->getScene();
	_ASSERT(pScene);

	hiveCrowdRendering::CVisualizationByOpenCV* pVisualize = new hiveCrowdRendering::CVisualizationByOpenCV(pScene->getSceneWidth(), pScene->getSceneHeight(), cv::Scalar(0, 0, 0));
	glm::vec3 ObstacleColor = glm::vec3(0, 0, 255);
	glm::vec3 PassableColor = glm::vec3(255, 0, 0);
	std::vector<const CQuadTreeNode<SNode>*> LeafNodeSet;
	pScene->dumpAllLeafNode(LeafNodeSet);

	CFramework::getInstance()->drawScene(pVisualize, LeafNodeSet, PassableColor, ObstacleColor);

	pVisualize->drawLine(vPoint, glm::vec2(vPoint.x + vVector.x * 50, vPoint.y + vVector.y * 50), glm::vec3(0, 255, 255), 2.0);
	glm::vec2 RotatedVector = rotateVector(vVector, vAngle);
	glm::vec2 End  = glm::vec2(vPoint.x + RotatedVector.x * 50, vPoint.y + RotatedVector.y * 50);
	pVisualize->drawLine(vPoint, End, glm::vec3(255, 255, 0), 2.0);
	pVisualize->display();
	delete pVisualize;
}

//********************************************************************
//FUNCTION:
CROWD_SIMULATION_DLL_EXPORT void hiveCrowdSimulation::testGetLeafNodeBySceneCoord(const glm::vec2& vPos, const std::string& vSimulationInfo, const std::string& vSceneInfo)
{
	initSimulationConfig(vSimulationInfo);
	CFramework::getInstance()->parseAndGenScene(vSceneInfo);
	CScene* pScene = CFramework::getInstance()->getScene();
	_ASSERT(pScene);
	std::vector<const CQuadTreeNode<SNode>*> LeafNodeSet;
	pScene->dumpAllLeafNode(LeafNodeSet);

	hiveCrowdRendering::CVisualizationByOpenCV* pVisualize = new hiveCrowdRendering::CVisualizationByOpenCV(pScene->getSceneWidth(), pScene->getSceneHeight(), cv::Scalar(0, 0, 0));
	glm::vec3 ObstacleColor = glm::vec3(0, 0, 255);
	glm::vec3 PassableColor = glm::vec3(255, 255, 255);
	CFramework::getInstance()->drawScene(pVisualize, LeafNodeSet, PassableColor, ObstacleColor);

	const CQuadTreeNode<SNode>* pLeafNode = pScene->getLeafNodeBySceneCoord(vPos);
	glm::vec3 TargetNodeColor(0, 255, 0);
	glm::vec3 TargetPointColor(0, 0, 255);
	if (pLeafNode != NULL)
	{
		glm::vec2 LeftTop(pLeafNode->getRectangle().x, pLeafNode->getRectangle().y);
		glm::vec2 RightDown(pLeafNode->getRectangle().z, pLeafNode->getRectangle().w);
		pVisualize->drawRectangle(LeftTop, RightDown, TargetNodeColor, true);
	}
	else
	{
		std::cout << "LeafNode is not found!" << std::endl;
	}
	pVisualize->drawPoint(vPos, 2.0, TargetPointColor, true);
	pVisualize->display();
	delete pVisualize;
}

//********************************************************************
//FUNCTION:
CROWD_SIMULATION_DLL_EXPORT void hiveCrowdSimulation::testGenCrowdAtSpecificArea(const std::string& vAgentInfo, const std::string& vSceneInfo, const std::string& vSimulationInfo, const glm::vec2& vCenter, unsigned int vRadius, unsigned int vNumAgent, bool vIsAware)
{
	CFramework::getInstance()->initFramework(vAgentInfo, vSceneInfo, vSimulationInfo);
	CFramework::getInstance()->genCrowdAndAdd2CrowdSimulationAtSpecificArea(vCenter, vRadius, vNumAgent, vIsAware);
	CFramework::getInstance()->clearScreen();
	CFramework::getInstance()->drawScene(true);
	CFramework::getInstance()->displayCrowdDistribution();
	CFramework::getInstance()->display();
}