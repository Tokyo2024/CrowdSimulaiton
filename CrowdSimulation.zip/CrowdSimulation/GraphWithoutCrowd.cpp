#include "GraphWithoutCrowd.h"
#include "Scene.h"
#include "SimulationTools.h"

using namespace hiveCrowdSimulation;

CGraphWithoutCrowd::CGraphWithoutCrowd()
{
}

CGraphWithoutCrowd::~CGraphWithoutCrowd()
{
}

//*******************************************************************
//FUNCTION:
double CGraphWithoutCrowd::_computeEdgeWeightV(const glm::vec2& vBegin, const glm::vec2& vEnd) const
{
	return glm::distance(vBegin, vEnd);
}