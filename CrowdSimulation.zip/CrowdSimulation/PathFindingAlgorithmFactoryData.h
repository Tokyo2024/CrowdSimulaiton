#pragma once
#include "PathFindingAlgorithmFactory.h"
#include "common/Singleton.h"
#include <map>

namespace hiveCrowdSimulation
{
	class CPathFindingAlgorithm;

	template<class TAlgorithm>
	class CPathFindingAlgorithmFactory;

	class CPathFindingAlgorithmFactoryData : public hiveCommon::CSingleton<CPathFindingAlgorithmFactoryData>
	{
	public:
		CPathFindingAlgorithm* createPathFindingAlgorithm(const std::string& vSig);
		void registerPathFindingAlgorithmFactory(CPathFindingAlgorithmFactory<CPathFindingAlgorithm>* vPathFindingAlgorithmFactory, const std::string& vSig);

	protected:
		CPathFindingAlgorithmFactoryData(void);
		virtual ~CPathFindingAlgorithmFactoryData(void);
		
	private:
		bool __isAlgorithmFactoryRegistered(const std::string& vSig);
		std::map<std::string, CPathFindingAlgorithmFactory<CPathFindingAlgorithm>*> m_AlgorithmFactoryMap;

	friend class hiveCommon::CSingleton<CPathFindingAlgorithmFactoryData>;
	};
}