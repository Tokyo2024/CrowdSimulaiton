#include "Visualization.h"

hiveCrowdRendering::CVisualization::CVisualization(void)
{
}

hiveCrowdRendering::CVisualization::~CVisualization(void)
{
}