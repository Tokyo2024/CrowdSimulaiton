//#pragma once
//#include "RenderingExport.h"
//#include "LoadModel.h"
//#include "common/CommonInterface.h"
//#include "wtypes.h"
//#include "CrowdRender.h"
//#include <iostream>
//
//namespace hiveCrowdRendering
//{
//	#define APP_SHORT_NAME "Window"
//	struct SWindow
//	{
//		std::string Name;
//		HWND Window;               
//		int Width, Height;
//	};
//
//	CROWD_RENDERING_DLL_EXPORT void hiveCreateWindow(int vWidth, int vHeight); 
//	//CROWD_RENDERING_DLL_EXPORT void loadModel(const std::string& vFileName);
//}