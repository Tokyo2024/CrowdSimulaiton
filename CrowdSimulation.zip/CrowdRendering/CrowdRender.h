//#pragma once
//#include "LoadModel.h"
//
//class CCrowdRender
//{
//public:
//	CCrowdRender::CCrowdRender();
//	CCrowdRender::~CCrowdRender();
//
//	void renderScene(HINSTANCE vHInstance); 
//	void renderCrowd();
//private:
//    CLoadModel* m_pLoadModel;
//	static LRESULT CALLBACK __WndProc(HWND vHWnd, UINT vMsg, WPARAM vWParam, LPARAM vLParam);
//};