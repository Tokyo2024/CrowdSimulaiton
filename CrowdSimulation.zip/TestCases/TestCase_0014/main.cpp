#include <memory>
#include "common/CommonInterface.h"
#include "common/HiveCommonMicro.h"
#include "SimulationInterface.h"
#include <vector>

//FUNCTION: detect the memory leak in DEBUG mode
void installMemoryLeakDetector()
{
	// Enable run-time memory check for debug builds.
#if defined(DEBUG) | defined(_DEBUG)
	//_CRTDBG_LEAK_CHECK_DF: Perform automatic leak checking at program exit through a call to _CrtDumpMemoryLeaks and generate an error 
	//report if the application failed to free all the memory it allocated. OFF: Do not automatically perform leak checking at program exit.
	_CrtSetDbgFlag( _CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);

	//the following statement is used to trigger a breakpoint when memory leak happens
	//comment it out if there is no memory leak report;
	//_crtBreakAlloc = 32796;
#endif
}

int main(int, char**)
{
	installMemoryLeakDetector();

	try
	{
		hiveCommon::hiveLoadTestingDLLs();

		const std::string SceneInfo      = "../resource/pic/256-1-3dmax.bmp";
		const std::string SimulationInfo = "Simulation.xml";

		const unsigned int NumOptimalNeighbor = 4;
		const glm::vec2   TargetData          = glm::vec2(128, 128);
		std::vector<glm::vec2> DataSet;

		for (unsigned int i=0; i<4; i++)
		{
			DataSet.push_back(glm::vec2(68, 168-i*20));
			DataSet.push_back(glm::vec2(88, 168-i*20));
			DataSet.push_back(glm::vec2(108, 168-i*20));
			DataSet.push_back(glm::vec2(128, 168-i*20));
			DataSet.push_back(glm::vec2(148, 168-i*20));
			DataSet.push_back(glm::vec2(168, 168-i*20));
			DataSet.push_back(glm::vec2(188, 168-i*20));
		}

		hiveCrowdSimulation::initSimulationConfig(SimulationInfo);
		hiveCrowdSimulation::testKNNSearch(SceneInfo, DataSet, TargetData, NumOptimalNeighbor);

		system("pause");
	}
	catch (...)
	{
		hiveCommon::hiveOutputWarning(__EXCEPTION_SITE__, "The program is terminated due to unexpected error.");
	}				

	return 0;
}