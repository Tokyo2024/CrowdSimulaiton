#include <memory.h>
#include <iostream>
#include "common/CommonInterface.h"
#include "common/HiveCommonMicro.h"
#include "SimulationInterface.h"
#include "VisualizationByOpenCV.h"
#include "Scene.h"

void installMemoryLeakDetector()
{
	// Enable run-time memory check for debug builds.
#if defined(DEBUG) | defined(_DEBUG)
	//_CRTDBG_LEAK_CHECK_DF: Perform automatic leak checking at program exit through a call to _CrtDumpMemoryLeaks and generate an error 
	//report if the application failed to free all the memory it allocated. OFF: Do not automatically perform leak checking at program exit.
	_CrtSetDbgFlag( _CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);

	//the following statement is used to trigger a breakpoint when memory leak happens
	//comment it out if there is no memory leak report;
	//_crtBreakAlloc = 26569;
#endif
}

int main(int, char**)
{
	installMemoryLeakDetector();

	try
	{
		hiveCommon::hiveLoadTestingDLLs();

		const std::string AgentInfo = "Agent.xml";
		//const std::string BitmapFile = "../resource/pic/test-pic-05.bmp";
		const std::string BitmapFile      = "../resource/pic/pic-256-2-1.bmp";
		const std::string SimulationInfo = "Simulation.xml";
		bool IsConsiderCrowdDensity = false;
		hiveCrowdSimulation::initCrowdSimulation(AgentInfo, BitmapFile, SimulationInfo);

		//glm::vec2 Start = glm::vec2(128, 128);	//(10,10)pic-02
		//glm::vec2 End   = glm::vec2(896, 896);	//(500,256)pic-02
		glm::vec2 Start = glm::vec2(90, 153);
		glm::vec2 End   = glm::vec2(200, 23);
		double AstarPathLength    = 0.0;
		double DijkstraPathLength = 0.0;
		float  PointRadius = 2.0;
		float LineThickness = 1.0;
		glm::vec3 LineColor[2] = {glm::vec3(255, 0, 255), glm::vec3(0, 255, 0)};
		glm::vec3 PointColor[2] = {glm::vec3(255, 0, 255), glm::vec3(0, 255, 0)};
		
		std::vector<glm::vec2> AstarResultPosSet;
		std::vector<glm::vec2> DijkstraResultPosSet;
		hiveCrowdSimulation::findShortestPath(IsConsiderCrowdDensity, Start, End, AstarResultPosSet);
		hiveCrowdSimulation::findPathUseDijkstra(IsConsiderCrowdDensity, Start, End, DijkstraPathLength, DijkstraResultPosSet);

		hiveCrowdSimulation::clearScreen();
		hiveCrowdSimulation::prepareScene();
		hiveCrowdSimulation::prepareCrowdDistribution();
		for (unsigned int i=0; i<AstarResultPosSet.size()-1; ++i)
		{
			hiveCrowdSimulation::preparePoint(AstarResultPosSet[i], PointRadius, PointColor[0], true);
			hiveCrowdSimulation::prepareLine(AstarResultPosSet[i], AstarResultPosSet[i+1], LineThickness, LineColor[0]);
		}
		hiveCrowdSimulation::preparePoint(AstarResultPosSet[AstarResultPosSet.size()-1], PointRadius, PointColor[0], true);

		for (unsigned int i=0; i<DijkstraResultPosSet.size()-1; ++i)
		{
			hiveCrowdSimulation::preparePoint(DijkstraResultPosSet[i], PointRadius, PointColor[1], true);
			hiveCrowdSimulation::prepareLine(DijkstraResultPosSet[i], DijkstraResultPosSet[i+1], LineThickness, LineColor[1]);
		}
		hiveCrowdSimulation::preparePoint(DijkstraResultPosSet[DijkstraResultPosSet.size()-1], PointRadius, PointColor[1], true);

		hiveCrowdSimulation::display();

		system("pause");
	}
	catch (...)
	{
		hiveCommon::hiveOutputWarning(__EXCEPTION_SITE__, "The program is terminated due to unexpected error.");
	}

	return 0;
}