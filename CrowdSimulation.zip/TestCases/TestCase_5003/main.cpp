#include <memory.h>
#include "common/CommonInterface.h"
#include "common/HiveCommonMicro.h"
#include "SimulationInterface.h"

void installMemoryLeakDetector()
{
	// Enable run-time memory check for debug builds.
#if defined(DEBUG) | defined(_DEBUG)
	//_CRTDBG_LEAK_CHECK_DF: Perform automatic leak checking at program exit through a call to _CrtDumpMemoryLeaks and generate an error 
	//report if the application failed to free all the memory it allocated. OFF: Do not automatically perform leak checking at program exit.
	_CrtSetDbgFlag( _CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);

	//the following statement is used to trigger a breakpoint when memory leak happens
	//comment it out if there is no memory leak report;
	//_crtBreakAlloc = 370644;
#endif
}

void prepareData4SplitFunction(std::vector<std::vector<glm::vec2>>& voPositionSet)
{
	std::vector<glm::vec2> SubgroupPositionSet;
	SubgroupPositionSet.push_back(glm::vec2(200, 200));
	SubgroupPositionSet.push_back(glm::vec2(215, 200));
	SubgroupPositionSet.push_back(glm::vec2(208, 210));
	SubgroupPositionSet.push_back(glm::vec2(200, 208));
	SubgroupPositionSet.push_back(glm::vec2(250, 190));
	SubgroupPositionSet.push_back(glm::vec2(190, 180));
	voPositionSet.push_back(SubgroupPositionSet);
}

int main(int, char**)
{
	installMemoryLeakDetector();

	try
	{
		hiveCommon::hiveLoadTestingDLLs();

		const std::string GlobalInfo = "GlobalConfig.xml";
		int NumSubgroupAfterSplited  = -1;
		std::vector<std::vector<glm::vec2>> GroupPositionSet;
 		prepareData4SplitFunction(GroupPositionSet);
		
		hiveCrowdSimulation::testSplitingGroup(GroupPositionSet, GlobalInfo, NumSubgroupAfterSplited);
		
		if (NumSubgroupAfterSplited >= 2)
			printf("Test pass.\n");
		else
			printf("Test fail.\n");

		system("pause");
	}
	catch (...)
	{
		hiveCommon::hiveOutputWarning(__EXCEPTION_SITE__, "The program is terminated due to unexpected error.");
	}

	return 0;
}