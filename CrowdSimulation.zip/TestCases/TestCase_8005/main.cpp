 #include <memory>
 #include "common/CommonInterface.h"
 #include "common/HiveCommonMicro.h"
 #include "SimulationInterface.h"
 
 //FUNCTION: detect the memory leak in DEBUG mode
 void installMemoryLeakDetector()
 {
 	// Enable run-time memory check for debug builds.
 #if defined(DEBUG) | defined(_DEBUG)
 	//_CRTDBG_LEAK_CHECK_DF: Perform automatic leak checking at program exit through a call to _CrtDumpMemoryLeaks and generate an error 
 	//report if the application failed to free all the memory it allocated. OFF: Do not automatically perform leak checking at program exit.
 	_CrtSetDbgFlag( _CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);
 
 	//the following statement is used to trigger a breakpoint when memory leak happens
 	//comment it out if there is no memory leak report;
 	//_crtBreakAlloc = 80407; 
 #endif
 }
 
 int main(int, char**)
 {
 	installMemoryLeakDetector();
 
 	try
 	{
 		hiveCommon::hiveLoadTestingDLLs();
 
 		const std::string AgentInfo      = "Agent.xml";
 		const std::string SceneInfo      = "test-pic-02.bmp";
 		const std::string SimulationInfo = "Simulation.xml";
 		const bool IsOutputPosInfo2File  = false;
 
 		hiveCrowdSimulation::initCrowdSimulation(AgentInfo, SceneInfo, SimulationInfo);
 		hiveCrowdSimulation::runCrowdSimulation(IsOutputPosInfo2File);
 
 		system("pause");
 	}
 	catch (...)
 	{
 		hiveCommon::hiveOutputWarning(__EXCEPTION_SITE__, "The program is terminated due to unexpected error.");
 	}				
 
 	return 0;
 }