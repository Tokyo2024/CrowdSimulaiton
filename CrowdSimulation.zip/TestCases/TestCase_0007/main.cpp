#include <memory.h>
#include "common/CommonInterface.h"
#include "common/HiveCommonMicro.h"
#include "SimulationInterface.h"

void installMemoryLeakDetector()
{
	// Enable run-time memory check for debug builds.
#if defined(DEBUG) | defined(_DEBUG)
	//_CRTDBG_LEAK_CHECK_DF: Perform automatic leak checking at program exit through a call to _CrtDumpMemoryLeaks and generate an error 
	//report if the application failed to free all the memory it allocated. OFF: Do not automatically perform leak checking at program exit.
	_CrtSetDbgFlag( _CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);

	//the following statement is used to trigger a breakpoint when memory leak happens
	//comment it out if there is no memory leak report;
	//_crtBreakAlloc = 35975;
#endif
}

void displayPoints(const std::vector<glm::vec2>& vPoints)
{
	for (unsigned int i=0; i<vPoints.size(); i++)
	{
		std::cout << vPoints[i].x << ", " << vPoints[i].y << std::endl;
	}
}

int main(int, char**)
{
	installMemoryLeakDetector();

	try
	{
		hiveCommon::hiveLoadTestingDLLs();

		const std::string AgentInfo      = "Agent.xml";
		const std::string SceneInfo      = "../resource/pic/pic-256-2-1.bmp";
		const std::string SimulationInfo = "Simulation.xml";
		const glm::vec2 Begin            = glm::vec2(120, 60);//90, 153
		const glm::vec2 End              = glm::vec2(200, 23);
		float ViewableDistance = 100.0;
		glm::vec2 BestNext;
		std::vector<glm::vec2> RoadMap;

		hiveCrowdSimulation::testFindingBestNext(SceneInfo, AgentInfo, Begin, End, ViewableDistance, BestNext, RoadMap);

		for (unsigned int i=0; i<RoadMap.size(); ++i)
			std::cout << RoadMap[i].x << "," << RoadMap[i].y << std::endl;
		std::cout << "BestNext:\n" << BestNext.x << "," << BestNext.y << std::endl;

		system("pause");
	}
	catch (...)
	{
		hiveCommon::hiveOutputWarning(__EXCEPTION_SITE__, "The program is terminated due to unexpected error.");
	}

	return 0;
}
