#include <memory.h>
#include "common/CommonInterface.h"
#include "common/HiveCommonMicro.h"
#include "SimulationInterface.h"

void installMemoryLeakDetector()
{
	// Enable run-time memory check for debug builds.
#if defined(DEBUG) | defined(_DEBUG)
	//_CRTDBG_LEAK_CHECK_DF: Perform automatic leak checking at program exit through a call to _CrtDumpMemoryLeaks and generate an error 
	//report if the application failed to free all the memory it allocated. OFF: Do not automatically perform leak checking at program exit.
	_CrtSetDbgFlag( _CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);

	//the following statement is used to trigger a breakpoint when memory leak happens
	//comment it out if there is no memory leak report;
	//_crtBreakAlloc = 370644;
#endif
}

void prepareData4MergeFunction(std::vector<std::vector<glm::vec2>>& voPositionSet)
{
	//case1: can not merge group
	std::vector<glm::vec2> SubgroupPosSet;
	SubgroupPosSet.push_back(glm::vec2(100, 100));
	SubgroupPosSet.push_back(glm::vec2(110, 100));
	SubgroupPosSet.push_back(glm::vec2(100, 110));
	voPositionSet.push_back(SubgroupPosSet);

	SubgroupPosSet.clear();
	SubgroupPosSet.push_back(glm::vec2(310, 215));
	SubgroupPosSet.push_back(glm::vec2(320, 210));
	voPositionSet.push_back(SubgroupPosSet);

	//case2: can merge group(direct visible)
	//std::vector<glm::vec2> SubgroupPosSet;
	//SubgroupPosSet.push_back(glm::vec2(200, 200));
	//SubgroupPosSet.push_back(glm::vec2(210, 200));
	//SubgroupPosSet.push_back(glm::vec2(200, 210));
	//voPositionSet.push_back(SubgroupPosSet);

	//SubgroupPosSet.clear();
	//SubgroupPosSet.push_back(glm::vec2(210, 215));
	//SubgroupPosSet.push_back(glm::vec2(220, 210));
	//voPositionSet.push_back(SubgroupPosSet);
	
	//case3: can merge group(indirect visible)
// 	std::vector<glm::vec2> SubgroupPosSet;
// 	SubgroupPosSet.push_back(glm::vec2(100, 100));
// 	SubgroupPosSet.push_back(glm::vec2(100, 130));
// 	SubgroupPosSet.push_back(glm::vec2(100, 160));
// 	voPositionSet.push_back(SubgroupPosSet);
// 
// 	SubgroupPosSet.clear();
// 	SubgroupPosSet.push_back(glm::vec2(100, 190));
// 	SubgroupPosSet.push_back(glm::vec2(100, 220));
// 	voPositionSet.push_back(SubgroupPosSet);
}

int main(int, char**)
{
	installMemoryLeakDetector();

	try
	{
		hiveCommon::hiveLoadTestingDLLs();

		const std::string GlobalInfo = "GlobalConfig.xml";
		int NumSubgroupAfterMerged  = -1;
		std::vector<std::vector<glm::vec2>> GroupPositionSet;
		prepareData4MergeFunction(GroupPositionSet);

		hiveCrowdSimulation::testMergingGroup(GroupPositionSet, GlobalInfo, NumSubgroupAfterMerged);
		if (NumSubgroupAfterMerged == 1)
			printf("Can merge.\n");
		else
			printf("Can not merge.\n");

		system("pause");
	}
	catch (...)
	{
		hiveCommon::hiveOutputWarning(__EXCEPTION_SITE__, "The program is terminated due to unexpected error.");
	}

	return 0;
}