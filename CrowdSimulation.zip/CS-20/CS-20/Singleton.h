#pragma once
#include <boost/noncopyable.hpp>
#include <boost/scoped_ptr.hpp>

template<class T>
class CSingleton : private boost::noncopyable
{
public:
	static T* getInstance()
	{
		static boost::scoped_ptr<T> Instance;
		if (Instance.get() == 0)
		{
			Instance.reset(new T());
		}

		return Instance.get();
	}

protected:
	CSingleton(void) {}
	virtual ~CSingleton(void) {}
};