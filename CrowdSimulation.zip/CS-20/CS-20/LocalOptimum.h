#pragma once
#include "Astar.h"
#include "Scene.h"

class CLocalOptimum
{
public:
	CLocalOptimum(CScene &vScene);
	CLocalOptimum(void);
	~CLocalOptimum(void);

	void setMyPosition(glm::vec2 vPosition) {m_MyPosition = vPosition;}
	void findBestPath(CSceneNode &vStart, CSceneNode &vEnd);

private:
	CScene m_Scence;
	CGraph m_GraphUsual;
	CGraph m_GraphWithCrowd;
	CAstar m_Astar;

	glm::vec2 m_MyPosition;
};

