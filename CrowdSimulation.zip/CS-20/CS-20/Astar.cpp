#include "Astar.h"
#include <iostream>

CAstar::CAstar(const CGraph &vGraph, const CSceneNode &vStart, const CSceneNode &vEnd)
{
	m_Graph = vGraph;
	m_Start = vStart;
	m_End = vEnd;
}

CAstar::CAstar()
{
}

CAstar::~CAstar(void)
{
}

//*******************************************************************
//FUNCTION:
bool CAstar::isInOpenList(const CSceneNode &vNode)
{
	std::list<SPoint>::iterator IteratorInOpenList;
	for (IteratorInOpenList=m_OpenList.begin(); IteratorInOpenList!=m_OpenList.end(); ++IteratorInOpenList)
	{
		if (IteratorInOpenList->Node == vNode)
		{
			return true;
		}
	}
	return false;
}

//*******************************************************************
//FUNCTION:
bool CAstar::isInClosedList(const CSceneNode &vNode)
{
	std::list<SPoint>::iterator IteratorInClosedList;
	for (IteratorInClosedList=m_ClosedList.begin(); IteratorInClosedList!=m_ClosedList.end(); ++IteratorInClosedList)
	{
		if (IteratorInClosedList->Node == vNode)
		{
			return true;
		}
	}
	return false;
}

//*******************************************************************
//FUNCTION:
std::list<SPoint>::iterator CAstar::Node2Point(const CSceneNode &vNode)
{
	std::list<SPoint>::iterator IteratorInOpenList;
	for (IteratorInOpenList=m_OpenList.begin(); IteratorInOpenList!=m_OpenList.end(); ++IteratorInOpenList)
	{
		if (IteratorInOpenList->Node == vNode)
		{
			return IteratorInOpenList;
		}
	}
}

//*******************************************************************
//FUNCTION:
void CAstar::doAstarSimple()
{
	SPoint CurrentNodeTemp;
	CurrentNodeTemp.Node = m_Start;
	CurrentNodeTemp.Parent = m_End;
	CurrentNodeTemp.G = 0;
	CurrentNodeTemp.H = m_Graph.getHDistance(m_Start, m_End);
	CurrentNodeTemp.F = CurrentNodeTemp.G + CurrentNodeTemp.H;
	m_OpenList.push_front(CurrentNodeTemp);
	do 
	{
		SPoint CurrentNode;
		float Cost = 10000.0f;
		std::list<SPoint>::iterator IteratorInOpenList;
		std::list<SPoint>::iterator IteratorOfBestNext;
		bool Flag = true;
		for (IteratorInOpenList = m_OpenList.begin(); IteratorInOpenList != m_OpenList.end(); ++IteratorInOpenList)
		{
			if (IteratorInOpenList->F < Cost)
			{
				CurrentNode = *IteratorInOpenList;
				Cost = IteratorInOpenList->F;
				IteratorOfBestNext = IteratorInOpenList;
				Flag = false;
			}
		}

		if (Flag)
		{
			std::cout << "no way to density..." << std::endl;
			break;
		}
		m_OpenList.erase(IteratorOfBestNext);
		m_ClosedList.push_front(CurrentNode);
		CurrentNodeTemp = CurrentNode;

		std::vector<CSceneNode> AdjacentNodeSet;
		m_Graph.getAdjacentNodeSet(CurrentNode.Node, AdjacentNodeSet);
		if (AdjacentNodeSet.size() == 0)
		{
			break;
			std::cout << "can not find a way to the destination" << std::endl;
		}
		for (int i=0; i<AdjacentNodeSet.size(); ++i)
		{
			if (isInClosedList(AdjacentNodeSet[i]))
			{
				continue;
			}
			else if (!(isInOpenList(AdjacentNodeSet[i])))
			{
				SPoint TempPoint = SPoint();
				TempPoint.Node = AdjacentNodeSet[i];
				TempPoint.Parent = CurrentNode.Node;
				float GCost = m_Graph.getEdgeWeight(AdjacentNodeSet[i], CurrentNode.Node) + CurrentNode.G;
				TempPoint.G = GCost;
				float HCost = m_Graph.getHDistance(AdjacentNodeSet[i], m_End);
				TempPoint.H = HCost;
				TempPoint.F = TempPoint.G + TempPoint.H;

				m_OpenList.push_front(TempPoint);
			}
			else if (isInOpenList(AdjacentNodeSet[i]))
			{
				std::list<SPoint>::iterator NowPoint = Node2Point(AdjacentNodeSet[i]);
				float GCost = m_Graph.getEdgeWeight(AdjacentNodeSet[i], CurrentNode.Node) + CurrentNode.G;
				if (GCost < NowPoint->G)
				{
					NowPoint->Parent = CurrentNode.Node;
					NowPoint->G = GCost;
					NowPoint->F = NowPoint->H + NowPoint->G;
				}
			}
		}
	} while (!(findEndNodeInOpenList()));
	SPoint EndPoint;
	EndPoint.Node = m_End;
	EndPoint.Parent = CurrentNodeTemp.Node;
	m_ClosedList.push_front(EndPoint);
}

//*******************************************************************
//FUNCTION:
bool CAstar::findEndNodeInOpenList()
{
	std::list<SPoint>::iterator IteratorInClosedList;
	for (IteratorInClosedList=m_OpenList.begin(); IteratorInClosedList != m_OpenList.end(); ++IteratorInClosedList)
	{
		if (IteratorInClosedList->Node == m_End)
		{
			return true;
		}
	}
	return false;
}

//*******************************************************************
//FUNCTION:
SPoint CAstar::getPoint(const CSceneNode &vNode)
{
	std::list<SPoint>::iterator IteratorInClosedList;
	for (IteratorInClosedList=m_ClosedList.begin(); IteratorInClosedList!=m_ClosedList.end(); ++IteratorInClosedList)
	{
		if (IteratorInClosedList->Node == vNode)
		{
			return *IteratorInClosedList;
		}
	}
}

//*******************************************************************
//FUNCTION:
void CAstar::showResult()
{
	SPoint CurrentPoint = getPoint(m_End);
	do 
	{
		std::cout << CurrentPoint.Node.getPositionX() << " " << CurrentPoint.Node.getPositionY() << std::endl;
		CurrentPoint = getPoint(CurrentPoint.Parent);
	} while (!(CurrentPoint.Node == m_End));
}