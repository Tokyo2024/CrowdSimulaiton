#include "Person.h"

CPerson::CPerson()
{

}

CPerson::CPerson(const glm::vec2& vPos, const glm::vec2& vMoveDir, float vMoveSpeed)
{
	m_Position  = vPos;
	m_MoveDir   = vMoveDir;
	m_MoveSpeed = vMoveSpeed;
}

CPerson::~CPerson()
{
}


