#pragma once
#include "Graph.h"
#include "glm/glm.hpp"
#include <list>

struct SPoint
{
	CSceneNode Node;

	float G;
	float H;
	float F;

	CSceneNode Parent;

	SPoint() 
	{
		G = 0;
		H = 0;
		F = 0;
	}
};

class CAstar
{
public:
	CAstar();
	CAstar(const CGraph &vGraph, const CSceneNode &vStart, const CSceneNode &vEnd);
	~CAstar(void);
	void doAstarSimple();

	bool findEndNodeInOpenList();
	bool isInOpenList(const CSceneNode &vNode);
	bool isInClosedList(const CSceneNode &vNode);
	std::list<SPoint>::iterator Node2Point(const CSceneNode &vNode);
	SPoint getPoint(const CSceneNode &vNode);

	void showResult();

private:
	std::list<SPoint> m_OpenList;
	std::list<SPoint> m_ClosedList;
	CGraph m_Graph;

	CSceneNode m_Start;
	CSceneNode m_End;
};

