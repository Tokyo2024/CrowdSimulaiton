#include "genScene.h"
#include "Scene.h"
#include <boost/random.hpp>

CGenScene::CGenScene()
{
}

CGenScene::~CGenScene()
{
}

//*******************************************************************
//FUNCTION:
void CGenScene::genAttributeOfScene(CScene& voScene)
{
 	boost::mt19937_64 Producer(voScene.setSeed());
 	boost::uniform_int<int> Pass(0, 1);
 	boost::variate_generator<boost::mt19937_64&, boost::uniform_int<int>> PassGenerator(Producer, Pass);
 
 	_ASSERT(voScene.getSceneWidth()>0 && voScene.getSceneHeight()>0);
 
  	for (int i=0; i<voScene.getSceneWidth(); ++i)
  	{
  		for (int k=0; k<voScene.getSceneHeight(); ++k)
  		{			
  			CSceneNode TempNode(PassGenerator(), glm::vec2(i, k));
  			voScene.setSceneNode(i, k, TempNode);
  		}
  	}
	voScene.setPerson();
}


//*******************************************************************
//FUNCTION:
void CGenScene::genAttributeOfScene(CScene& voScene, int *vFlag)
{
	_ASSERT(voScene.getSceneWidth()>0 && voScene.getSceneHeight()>0);
	
	for (int i=0; i<voScene.getSceneWidth(); ++i)
	{
		for (int k=0; k<voScene.getSceneHeight(); ++k)
		{			
			CSceneNode TempNode(vFlag[i * voScene.getSceneWidth() + k], glm::vec2(i, k));
			voScene.setSceneNode(i, k, TempNode);
		}
	}
	voScene.setPerson();
}