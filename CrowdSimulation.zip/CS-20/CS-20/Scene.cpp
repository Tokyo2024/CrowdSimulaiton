#include "Scene.h"
#include "Person.h"
#include <time.h>

//*******************************************************************
//FUNCTION:
CScene::CScene(const unsigned int vWidth, const unsigned int vHeight, int vCountOfPeople)
{
	m_SceneDimension = glm::vec2(vWidth, vHeight);
    
	m_Plane.resize(vWidth);
	for (unsigned int i = 0; i < vWidth; i++)
	{
		m_Plane[i].resize(vHeight);
	}

	m_CountOfPeople = vCountOfPeople;
}

CScene::CScene()
{
}

CScene::~CScene()
{
}

//*******************************************************************
//FUNCTION:
float CScene::getRoundFunctionUp(glm::vec2 vCentreOfRound, float vRadius, float vY)
{
	float X = vCentreOfRound.x + sqrt(pow(vRadius, 2) - pow((vY - vCentreOfRound.y), 2));
	if (X > m_SceneDimension.x * 2)
	{
		X = m_SceneDimension.x * 2;
	}
	return X;
} 

//*******************************************************************
//FUNCTION:
float CScene::getRoundFunctionDown(glm::vec2 vCentreOfRound, float vRadius, float vY)
{
	float X = vCentreOfRound.x - sqrt(pow(vRadius, 2) - pow((vY - vCentreOfRound.y), 2));
	if (X < 0)
	{
		X = 0;
	}
	return X;
}

//*******************************************************************
//FUNCTION:
std::vector<CSceneNode> CScene::getNodeInSight(CSceneNode &vEye, float vRadius)
{
	std::vector<CSceneNode> NodeInSight;
	int CountOfCell;
	int EyeX = vEye.getPositionX() * 2 + 1;
	int EyeY = vEye.getPositionY() * 2 + 1;
	CountOfCell = ceil((vRadius - 1) / 2);
	int CurrentY = EyeY - 1 - CountOfCell * 2;
	if (CurrentY < 0)
	{
		CurrentY = 0;
	}
	CurrentY += 2;
	float XUp = getRoundFunctionUp(glm::vec2(EyeX, EyeY), vRadius, CurrentY);
	float XDown = getRoundFunctionDown(glm::vec2(EyeX, EyeY), vRadius, CurrentY);
	int XUpBound = (int)((ceil(XUp) + 1) / 2) * 2;
	int XDownBound = floor(XDown / 2) * 2;

	//�������һ��
	XUpBound--;
	if (CurrentY < EyeY)
	{
		do 
		{
			if (isVisibility(glm::vec2(vEye.getPositionX(), vEye.getPositionY()), glm::vec2((XUpBound - 1) / 2, (CurrentY - 2) / 2)))
			{
				NodeInSight.push_back(m_Plane[(XUpBound - 1) / 2][(CurrentY - 2) / 2]);
			}
			XUpBound -= 2;
		} while (XUpBound > XDownBound);
		CurrentY += 2;
	}
	
	//Բ�����
	while (CurrentY < EyeY)
	{
		XUp = getRoundFunctionUp(glm::vec2(EyeX, EyeY), vRadius, CurrentY);
		XDown = getRoundFunctionDown(glm::vec2(EyeX, EyeY), vRadius, CurrentY);
		XUpBound = (int)((ceil(XUp) + 1) / 2) * 2;
		XDownBound = floor(XDown / 2) * 2;
		XUpBound--;
		XDownBound++;
		if (isVisibility(glm::vec2(vEye.getPositionX(), vEye.getPositionY()), glm::vec2((XUpBound - 1) / 2, (CurrentY - 2) / 2)) && XUpBound != EyeX)
		{
			NodeInSight.push_back(m_Plane[(XUpBound - 1) / 2][(CurrentY - 2) / 2]);
		}
		if (isVisibility(glm::vec2(vEye.getPositionX(), vEye.getPositionY()), glm::vec2((XDownBound - 1) / 2, (CurrentY - 2) / 2)) && XDownBound != EyeX) 
		{
			NodeInSight.push_back(m_Plane[(XDownBound - 1) / 2][(CurrentY - 2) / 2]);
		}
		CurrentY += 2;
	}

	//Բ�Ĵ�
	XUp = getRoundFunctionUp(glm::vec2(EyeX, EyeY), vRadius, EyeY);
	XDown = getRoundFunctionDown(glm::vec2(EyeX, EyeY), vRadius, EyeY);
	XUpBound = (int)((ceil(XUp) + 1) / 2) * 2;
	XDownBound = floor(XDown / 2) * 2;
	XUpBound--;
	XDownBound++;
	if (isVisibility(glm::vec2(vEye.getPositionX(), vEye.getPositionY()), glm::vec2((XUpBound - 1) / 2, (EyeY - 1) / 2)) && XUpBound != EyeX)
	{
		NodeInSight.push_back(m_Plane[(XUpBound - 1) / 2][(EyeY - 1) / 2]);
	}
	if (isVisibility(glm::vec2(vEye.getPositionX(), vEye.getPositionY()), glm::vec2((XDownBound - 1) / 2, (EyeY - 1) / 2)) && XDownBound != EyeX)
	{
		NodeInSight.push_back(m_Plane[(XDownBound - 1) / 2][(EyeY - 1) / 2]);
	}

	//Բ���Ҳ�
	while ((CurrentY < (EyeY + 1 + CountOfCell * 2 - 2)) && (CurrentY < (m_SceneDimension.y * 2 - 2)))
	{
		XUp = getRoundFunctionUp(glm::vec2(EyeX, EyeY), vRadius, CurrentY);
		XDown = getRoundFunctionDown(glm::vec2(EyeX, EyeY), vRadius, CurrentY);
		XUpBound = (int)((ceil(XUp) + 1) / 2) * 2;
		XDownBound = floor(XDown / 2) * 2;
		XUpBound--;
		XDownBound++;

		if (isVisibility(glm::vec2(vEye.getPositionX(), vEye.getPositionY()), glm::vec2((XUpBound - 1) / 2, CurrentY / 2)) && XUpBound != EyeX)
		{
			NodeInSight.push_back(m_Plane[(XUpBound - 1) / 2][CurrentY / 2]);
		}
		if (isVisibility(glm::vec2(vEye.getPositionX(), vEye.getPositionY()), glm::vec2((XDownBound - 1) / 2, CurrentY / 2)) && XDownBound != EyeX)
		{
			NodeInSight.push_back(m_Plane[(XDownBound - 1) / 2][CurrentY / 2]);
		}
		CurrentY += 2;
	}

	//���ұ���һ��
	XUp = getRoundFunctionUp(glm::vec2(EyeX, EyeY), vRadius, CurrentY);
	XDown = getRoundFunctionDown(glm::vec2(EyeX, EyeY), vRadius, CurrentY);
	XUpBound = (int)((ceil(XUp) + 1) / 2) * 2;
	XDownBound = floor(XDown / 2) * 2;
	XUpBound--;

	if (CurrentY < (m_SceneDimension.y * 2))
	{
		do 
		{
			if (isVisibility(glm::vec2(vEye.getPositionX(), vEye.getPositionY()), glm::vec2((XUpBound - 1) / 2, CurrentY / 2)))
			{
				NodeInSight.push_back(m_Plane[(XUpBound - 1) / 2][CurrentY / 2]);
			}
			XUpBound -= 2;
		} while (XUpBound > XDownBound);
	}
	
	return NodeInSight;
}

//*******************************************************************
//FUNCTION:
void CScene::setSceneNode(unsigned int vX, unsigned int vY, const CSceneNode& vSceneNode)
{
	_ASSERT(vX < m_SceneDimension.x && vY < m_SceneDimension.y);

	m_Plane[vX][vY] = vSceneNode;
}

//*******************************************************************
//FUNCTION:
void CScene::setPerson()
{
	boost::mt19937_64 Producer(setSeed());

	boost::uniform_int<int> PositionX(0, m_SceneDimension.x - 1);
	boost::uniform_int<int> PositionY(0, m_SceneDimension.y - 1);
	boost::variate_generator<boost::mt19937_64&, boost::uniform_int<int>> PositionXGenerator(Producer, PositionX);
	boost::variate_generator<boost::mt19937_64&, boost::uniform_int<int>> PositionYGenerator(Producer, PositionY);

	boost::uniform_int<int> DirctionX(-1, 1);
	boost::uniform_int<int> DirctionY(-1, 1);
	boost::variate_generator<boost::mt19937_64&, boost::uniform_int<int>> DirctionXGenerator(Producer, DirctionX);
	boost::variate_generator<boost::mt19937_64&, boost::uniform_int<int>> DirctionYGenerator(Producer, DirctionY);

	boost::uniform_real<float> Speed(0, 9);
	boost::variate_generator<boost::mt19937_64&, boost::uniform_real<float>> SpeedGenerator(Producer, Speed);

	for (int i=0; i<m_CountOfPeople; ++i)
	{
		int PositionX;
		int PositionY;

		do 
		{
			PositionX = PositionXGenerator();
			PositionY = PositionYGenerator();
		} while (m_Plane[PositionX][PositionY].isPassable() == 0);

		float SpeedOfPerson = SpeedGenerator();

		int X = DirctionXGenerator();
		int Y = DirctionYGenerator();

		CPerson TempPerson = CPerson(glm::vec2(PositionX, PositionY), glm::vec2(X, Y), SpeedOfPerson);

		m_Plane[PositionX][PositionY].addPerson(TempPerson);
	}
}

//*******************************************************************
//FUNCTION:
time_t CScene::setSeed()
{
	static time_t Seed = time(0);
	Seed++;
	return Seed;
}

//*******************************************************************
//FUNCTION:
CSceneNode CScene::getSceneNode(unsigned int vX, unsigned int vY) const
{
	_ASSERT(vX < m_SceneDimension.x && vY < m_SceneDimension.y);
	return m_Plane[vX][vY];
}

//*******************************************************************
//FUNCTION:
void CScene::displayPlaneWithCorwd()
{
	for (int i=0; i<m_Plane.size(); ++i)
	{
		std::vector<CSceneNode> TempVertor = m_Plane[i];
		for (int k=0; k<TempVertor.size(); ++k)
		{
			std::cout << TempVertor[k].isPassable() << " ";
		}
		std::cout << std::endl;
	}
	std::cout << std::endl;

	for (int i=0; i<m_Plane.size(); ++i)
	{
		std::vector<CSceneNode> TempVertor = m_Plane[i];
		for (int k=0; k<TempVertor.size(); ++k)
		{
			std::cout << TempVertor[k].getCrowdDensity() << " ";
		}
		std::cout << std::endl;
	}
	std::cout << std::endl;

	for (int i=0; i<m_Plane.size(); ++i)
	{
		std::vector<CSceneNode> TempVertor = m_Plane[i];
		for (int k=0; k<TempVertor.size(); ++k)
		{
			std::cout << TempVertor[k].getAvgMoveDirectionX() << " " << TempVertor[k].getAvgMoveDirectionX() << "    ";
		}
		std::cout << std::endl;
	}
	std::cout << std::endl;
}

//*******************************************************************
//FUNCTION:
void CScene::displayPlane()
{
	for (int i=0; i<m_Plane.size(); ++i)
	{
		std::vector<CSceneNode> TempVertor = m_Plane[i];
		for (int k=0; k<TempVertor.size(); ++k)
		{
			std::cout << TempVertor[k].isPassable() << " ";
		}
		std::cout << std::endl;
	}
	std::cout << std::endl;
}

bool CScene::isVisibility(glm::vec2 vEye, glm::vec2 vTarget)
{
	computeSlope(vEye, vTarget);
	if ((m_Plane[vEye.x][vEye.y].isPassable() == 0) || (m_Plane[vTarget.x][vTarget.y].isPassable() == 0))
	{
		return false;
	}
	if (vEye.x == vTarget.x)
	{
		if (vEye.y < vTarget.y)
		{
			int y = vEye.y + 1;
			while (y <= (vTarget.y - 1))
			{
				if (m_Plane[vEye.x][y].isPassable() == 0)
				{
					//std::cout << m_Plane[vEye.x][y].getPositionX() << " " << m_Plane[vEye.x][y].getPositionY() << std::endl;
					return false;
				}
				//std::cout << m_Plane[vEye.x][y].getPositionX() << " " << m_Plane[vEye.x][y].getPositionY() << std::endl;
				y++;
			}
		}
		else
		{
			int y = vTarget.y + 1;
			while (y <= (vEye.y - 1))
			{
				if (m_Plane[vEye.x][y].isPassable() == 0)
				{
					//std::cout << m_Plane[vEye.x][y].getPositionX() << " " << m_Plane[vEye.x][y].getPositionY() << std::endl;
					return false;
				}
				//std::cout << m_Plane[vEye.x][y].getPositionX() << " " << m_Plane[vEye.x][y].getPositionY() << std::endl;
				y++;
			}
		}
	}
	else if (vEye.y == vTarget.y)
	{
		if (vEye.x < vTarget.x)
		{
			int x = vEye.x + 1;
			while (x <= vTarget.x - 1)
			{
				if (m_Plane[x][vEye.y].isPassable() == 0)
				{
					//std::cout << m_Plane[x][vEye.y].getPositionX() << " " << m_Plane[x][vEye.y].getPositionY() << std::endl;
					return false;
				}
				//std::cout << m_Plane[x][vEye.y].getPositionX() << " " << m_Plane[x][vEye.y].getPositionY() << std::endl;
				x++;
			}
		}
		else
		{
			int x = vTarget.x + 1;
			while (x <= vEye.x - 1)
			{
				if (m_Plane[x][vEye.y].isPassable() == 0)
				{
					//std::cout << m_Plane[x][vEye.y].getPositionX() << " " << m_Plane[x][vEye.y].getPositionY() << std::endl;
					return false;
				}
				//std::cout << m_Plane[x][vEye.y].getPositionX() << " " << m_Plane[x][vEye.y].getPositionY() << std::endl;
				x++;
			}
		}
	}
	else if (m_Slope < 0)
	{
		int EyeX = vEye.y * 2 + 1;
		int EyeY = vEye.x * 2 + 1;
		int TargetX = vTarget.y * 2 + 1;
		int TargetY = vTarget.x * 2 + 1;

		if (EyeX < TargetX)
		{
			int x = EyeX - 1;
			int YBefore = EyeY + 1;
			x += 2;
			int YAfter = 0;
			while (x <= (TargetX + 1))
			{
				double y = getFunction(glm::vec2(EyeX, EyeY), glm::vec2(TargetX, TargetY), x);
				if (y < TargetY)
				{
					y = TargetY;
				}
				YAfter = floor(y / 2) * 2;
				int Y = YBefore - 1;
				while (Y > YAfter)
				{
					if (m_Plane[(Y - 1) / 2][(x - 2) / 2].isPassable() == 0)
					{
						//std::cout << m_Plane[(Y - 1) / 2][(x - 2) / 2].getPositionX() << " " << m_Plane[(Y - 1) / 2][(x - 2) / 2].getPositionY() << std::endl;
						return false;
					}
					//std::cout << m_Plane[(Y - 1) / 2][(x - 2) / 2].getPositionX() << " " << m_Plane[(Y - 1) / 2][(x - 2) / 2].getPositionY() << std::endl;
					Y -= 2;
				}
				x += 2;
				YBefore = (int)((ceil(y) + 1) / 2) * 2;
			}
		}
		else
		{
			int x = TargetX - 1;
			int YBefore = TargetY + 1;
			x += 2;
			int YAfter = 0;
			while (x <= (EyeX + 1))
			{
				double y = getFunction(glm::vec2(EyeX, EyeY), glm::vec2(TargetX, TargetY), x);
				if (y < EyeY)
				{
					y = EyeY;
				}
				YAfter = floor(y / 2) * 2;
				int Y = YBefore - 1;
				while (Y > YAfter)
				{
					if (m_Plane[(Y - 1) / 2][(x - 2) / 2].isPassable() == 0)
					{
						//std::cout << m_Plane[(Y - 1) / 2][(x - 2) / 2].getPositionX() << " " << m_Plane[(Y - 1) / 2][(x - 2) / 2].getPositionY() << std::endl;
						return false;
					}
					//std::cout << m_Plane[(Y - 1) / 2][(x - 2) / 2].getPositionX() << " " << m_Plane[(Y - 1) / 2][(x - 2) / 2].getPositionY() << std::endl;
					Y -= 2;
				}
				x += 2;
				YBefore = (int)((ceil(y) + 1) / 2) * 2;
			}
		}
	}
	else
	{
		int EyeX = vEye.y * 2 + 1;
		int EyeY = vEye.x * 2 + 1;
		int TargetX = vTarget.y * 2 + 1;
		int TargetY = vTarget.x * 2 + 1;

		if (EyeX < TargetX)
		{
			int x = EyeX - 1;	
			int YBefore = EyeY - 1;
			x += 2;
			int YAfter = 0;
			while (x <= (TargetX + 1))
			{
				double y = getFunction(glm::vec2(EyeX, EyeY), glm::vec2(TargetX, TargetY), x);
				if (y > TargetY)
				{
					y = TargetY;
				}
				YAfter = (int)((ceil(y) + 1) / 2) * 2;
				int Y = YAfter - 1;
				while (Y > YBefore)
				{
					if (m_Plane[(Y - 1) / 2][(x - 2) / 2].isPassable() == 0)
					{
						//std::cout << m_Plane[(Y - 1) / 2][(x - 2) / 2].getPositionX() << " " << m_Plane[(Y - 1) / 2][(x - 2) / 2].getPositionY() << std::endl;
						return false;
					}
					//std::cout << m_Plane[(Y - 1) / 2][(x - 2) / 2].getPositionX() << " " << m_Plane[(Y - 1) / 2][(x - 2) / 2].getPositionY() << std::endl;
					Y -= 2;
				}
				x += 2;
				YBefore = floor(y / 2) * 2;
			}
		}
		else
		{
			int x = TargetX - 1;
			int YBefore = TargetY - 1;
			x += 2;
			int YAfter = 0;
			while (x <= (EyeX + 1))
			{
				double y = getFunction(glm::vec2(EyeX, EyeY), glm::vec2(TargetX, TargetY), x);
				if (y > EyeY)
				{
					y = EyeY;
				}
				YAfter = (int)((ceil(y) + 1) / 2) * 2;
				int Y = YAfter - 1;
				while (Y > YBefore)
				{
					if (m_Plane[(Y - 1) / 2][(x - 2) / 2].isPassable() == 0)
					{
						//std::cout << m_Plane[(Y - 1) / 2][(x - 2) / 2].getPositionX() << " " << m_Plane[(Y - 1) / 2][(x - 2) / 2].getPositionY() << std::endl;
						return false;
					}
					//std::cout << m_Plane[(Y - 1) / 2][(x - 2) / 2].getPositionX() << " " << m_Plane[(Y - 1) / 2][(x - 2) / 2].getPositionY() << std::endl;
					Y -= 2;
				}
				x += 2;
				YBefore = floor(y / 2) * 2;
			}
		}
	}
	return true;
}

//*******************************************************************
//FUNCTION:
double CScene::getFunction(glm::vec2 vPointOne, glm::vec2 vPointTwo, int vX)
{
	double Y = (vPointOne.y - vPointTwo.y) / (vPointOne.x - vPointTwo.x) * (vX - vPointTwo.x) + vPointTwo.y;
	return Y;
}

//*******************************************************************
//FUNCTION:
void CScene::computeSlope(glm::vec2 vPointOne, glm::vec2 vPointTwo)
{
	m_Slope = (double)(vPointTwo.x - vPointOne.x) / (double)(vPointTwo.y - vPointOne.y);
}