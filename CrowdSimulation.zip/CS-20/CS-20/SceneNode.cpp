#include "SceneNode.h"
#include <iostream>

 CSceneNode::CSceneNode()
 {
	 m_AvgSpeed = 0;
	 m_AvgDirection = glm::vec2(0, 0);
 }

CSceneNode::CSceneNode(bool vPassable, const glm::vec2& vCoordinate)
{
	m_Passable  = vPassable;
	m_Cordinate = vCoordinate;
	m_AvgDirection = glm::vec2(0, 0);
	m_AvgSpeed = 0;
}

CSceneNode::~CSceneNode()
{
}

//*******************************************************************
//FUNCTION:
void CSceneNode::__computeAvgDirection() 
{
	glm::vec2 Direction = glm::vec2(0, 0);
	float Speed = 0.0f;
	if (m_Crowd.size() > 0)
	{
		for (unsigned int i = 0; i < m_Crowd.size(); i++)
		{
			Direction.x += m_Crowd[i].getMoveDirectionX();
			Direction.y += m_Crowd[i].getMoveDirectionY();
			Speed += m_Crowd[i].getSpeed();
		}

		Direction = glm::vec2(Direction.x / m_Crowd.size(), Direction.y / m_Crowd.size());
		Speed = Speed / m_Crowd.size();
	}
	m_AvgSpeed = Speed;
	 m_AvgDirection = Direction;
}

//*******************************************************************
//FUNCTION:
void CSceneNode::addPerson(const CPerson& vPerson)
{
    m_Crowd.push_back(vPerson);
	__computeAvgDirection();
}

//*******************************************************************
//FUNCTION:
void CSceneNode::deletePerson(const CPerson& vPerson)
{
	_ASSERT(m_Crowd.size() > 0);

	bool CanDelete = false;

	for (unsigned int i = 0; i < m_Crowd.size(); i++)
	{
		if (m_Crowd[i] == vPerson)
		{
			CanDelete = true;
			break;
		}
	}

	if (CanDelete)
	{
		m_Crowd.push_back(vPerson);
		__computeAvgDirection();
	}
	else
	{
		std::cout << "The person not lie on this node. Can delete!" << std::endl;
	}
}

//*******************************************************************
//FUNCTION:
void CSceneNode::dislpayCrowdMoveInfo() const
{
	if (m_Crowd.size() > 0)
	{
		for (unsigned int i = 0; i < m_Crowd.size(); i++)
		{
			std::cout << "Pos: " << m_Crowd[i].getCurrentPosition().x << ", " << m_Crowd[i].getCurrentPosition().y << std::endl;
			std::cout << "Dir: " << m_Crowd[i].getMoveDirectionX() << ", " << m_Crowd[i].getMoveDirectionY() << std::endl;
		    std::cout << "Speed: " << m_Crowd[i].getSpeed() << std::endl;
		}
	}
}

 