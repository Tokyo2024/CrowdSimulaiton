#include "Graph.h"
#include "Scene.h"
#include <iostream>

CGraph::CGraph()
{
}

CGraph::~CGraph()
{
}

//*******************************************************************
//FUNCTION:
void CGraph::genGraphUsual(const CScene& vScene)
{
	for (int i = 0; i < vScene.getSceneWidth(); i++)
	{
		for (int k = 0; k < vScene.getSceneHeight(); k++)
		{
			if (vScene.getSceneNode(i, k).isPassable() == true) //The node is passable
			{
				__addNode(vScene.getSceneNode(i, k));
			}
		}
	}

	for (int i = 0; i < m_Node2IndexVec.size(); i++)
	{
		__findAdjacentNodes(vScene, m_Node2IndexVec[i].second);
	}
}

//*******************************************************************
//FUNCTION:
void CGraph::genGraphWithCrowd(const CScene& vScene)
{
	for (int i = 0; i < vScene.getSceneWidth(); i++)
	{
		for (int k = 0; k < vScene.getSceneHeight(); k++)
		{
			if (vScene.getSceneNode(i, k).isPassable() == true) //The node is passable
			{
				__addNode(vScene.getSceneNode(i, k));
			}
		}
	}

	for (int i = 0; i < m_Node2IndexVec.size(); i++)
	{
		__findAdjacentNodes(vScene, m_Node2IndexVec[i].second);
	}
}

//*******************************************************************
//FUNCTION:
void CGraph::__addNode(CSceneNode& vNode)
{
	//std::cout << "Pos: " << "(" << vNode.getPositionX() << ", " << vNode.getPositionY() << ")" << std::endl;

	GRAPHVERTEX Temp = m_Graph.addVertex(vNode);
	m_Node2IndexVec.push_back(std::make_pair(Temp, vNode));
}

//*******************************************************************
//FUNCTION:
void CGraph::__findAdjacentNodesWithCrowd(const CScene& vScene, const CSceneNode& vNode)
{
	glm::vec2 CurrentNodePos = glm::vec2(vNode.getPositionX(), vNode.getPositionY());

	for (int i = CurrentNodePos.x - 1; i < CurrentNodePos.x + 2; i++)
	{
		if (i < 0)
		{
			continue;
		}

		if (i >= vScene.getSceneWidth())
		{
			break;
		}

		for (int k = CurrentNodePos.y - 1; k < CurrentNodePos.y + 2; k++)
		{
			if (k < 0)
			{
				continue;
			}

			if (k >= vScene.getSceneHeight())
			{
				break;
			}

			if (i == CurrentNodePos.x && k == CurrentNodePos.y)
			{
				continue;
			}

			if (vScene.getSceneNode(i, k).isPassable() == true)
			{
				float EdgeWeight = __computeEdgeWeightWithCrowd(vNode, vScene.getSceneNode(i, k));
				__addEdge(vNode, vScene.getSceneNode(i, k), EdgeWeight);
			}
		}
	}
}

//*******************************************************************
//FUNCTION:
void CGraph::__findAdjacentNodes(const CScene& vScene, const CSceneNode& vNode)
{
	glm::vec2 CurrentNodePos = glm::vec2(vNode.getPositionX(), vNode.getPositionY());

	for (int i = CurrentNodePos.x - 1; i < CurrentNodePos.x + 2; i++)
	{
		if (i < 0)
		{
			continue;
		}

		if (i >= vScene.getSceneWidth())
		{
			break;
		}

		for (int k = CurrentNodePos.y - 1; k < CurrentNodePos.y + 2; k++)
		{
			if (k < 0)
			{
				continue;
			}

			if (k >= vScene.getSceneHeight())
			{
				break;
			}

			if (i == CurrentNodePos.x && k == CurrentNodePos.y)
			{
				continue;
			}

			if (vScene.getSceneNode(i, k).isPassable() == true)
			{
				float EdgeWeight = __computeEdgeWeight(vNode, vScene.getSceneNode(i, k));
				__addEdge(vNode, vScene.getSceneNode(i, k), EdgeWeight);
			}
		}
	}
}

//*******************************************************************
//FUNCTION:
float CGraph::__computeEdgeWeight(const CSceneNode& vBeginNode, const CSceneNode& vEndNode) const
{
	return sqrt(pow(abs(vBeginNode.getPositionX() - vEndNode.getPositionX()),2) + pow(abs(vBeginNode.getPositionY() - vEndNode.getPositionY()), 2));
}

//*******************************************************************
//FUNCTION:
float CGraph::__computeEdgeWeightWithCrowd(const CSceneNode& vBeginNode, const CSceneNode& vEndNode)
{
	glm::vec2 VectorBegin2End = glm::vec2(vEndNode.getPositionX() - vBeginNode.getPositionX(), vEndNode.getPositionY() - vBeginNode.getAvgMoveDirectionY());
	float Distance = sqrt(pow(abs(vBeginNode.getPositionX() - vEndNode.getPositionX()),2) + pow(abs(vBeginNode.getPositionY() - vEndNode.getPositionY()), 2));
	float UintVectorOfSpeed = sqrt(pow(abs(vEndNode.getAvgMoveDirectionX()),2) + pow(abs(vEndNode.getAvgMoveDirectionY()), 2));
	float CosAngle = __dot(VectorBegin2End, glm::vec2(vEndNode.getAvgMoveDirectionX(), vEndNode.getAvgMoveDirectionY())) / (Distance * UintVectorOfSpeed);
	float ResistanceForce;
	if (CosAngle > 0)
	{
		ResistanceForce = CosAngle * vEndNode.getAvgSpeed();
	}
	else if (CosAngle < 0)
	{
		ResistanceForce = (1-CosAngle) * vEndNode.getAvgSpeed();
	}
	else
	{
		ResistanceForce = 1;
	}
	return Distance * ResistanceForce * (1 + vEndNode.getCrowdDensity());
}

//*******************************************************************
//FUNCTION:
float CGraph::__dot(glm::vec2 vVectorA, glm::vec2 vVectorB)
{
	return vVectorA.x * vVectorB.x + vVectorA.y * vVectorB.y;
}

//*******************************************************************
//FUNCTION:
float CGraph::getEdgeWeight(CSceneNode& vBeginNode, CSceneNode& vEndNode)
{
	float EdgeWeight = m_Graph.getEdgeWeight(__node2Index(vBeginNode), __node2Index(vEndNode));

	_ASSERT(EdgeWeight != FLT_MAX);

	return EdgeWeight;
}

//*******************************************************************
//FUNCTION:
GRAPHVERTEX CGraph::__node2Index(const CSceneNode& vTargetNode) const
{
	GRAPHVERTEX NodeIndex = NULL;

	for (int i = 0; i < m_Node2IndexVec.size(); i++)
	{
		if (vTargetNode == (m_Node2IndexVec[i].second))
		{
			NodeIndex = m_Node2IndexVec[i].first;
			break;
		}
	}

	return NodeIndex;
}

//*******************************************************************
//FUNCTION:
CSceneNode CGraph::__Index2Node(const GRAPHVERTEX& vTargetIndex) const
{
	CSceneNode Node;

	for (int i = 0; i < m_Node2IndexVec.size(); i++)
	{
		if (vTargetIndex == m_Node2IndexVec[i].first)
		{
			Node = m_Node2IndexVec[i].second;
			break;
		}
	}

	return Node;
}

//*******************************************************************
//FUNCTION:
void CGraph::deleteNode(const CSceneNode& vTargetNode)
{
	m_Graph.deleteVertex(__node2Index(vTargetNode));
}

//*******************************************************************
//FUNCTION:
void CGraph::getAdjacentNodeSet(const CSceneNode& vTargetNode, std::vector<CSceneNode>& voAdjacentNodeSet) const
{
	std::vector<GRAPHVERTEX> AdjacentNodeSet;
	m_Graph.dumpAdjacentVertexSet(__node2Index(vTargetNode), AdjacentNodeSet);

	for (unsigned int i = 0; i < AdjacentNodeSet.size(); i++)
	{
		voAdjacentNodeSet.push_back(__Index2Node(AdjacentNodeSet[i]));
	}
}

//*******************************************************************
//FUNCTION:
float CGraph::getHDistance(const CSceneNode& vBeginNode, const CSceneNode& vEndNode) const
{
	return abs(vBeginNode.getPositionX() - vEndNode.getPositionX()) + abs(vBeginNode.getPositionY() - vEndNode.getPositionY());
}

//*******************************************************************
//FUNCTION:
void CGraph::__addEdge(const CSceneNode& vBeginNode, const CSceneNode& vEndNode, float vWeight)
{
	_ASSERT(vWeight > 0.0);

	GRAPHVERTEX BeginNodeIndex = __node2Index(vBeginNode);
	GRAPHVERTEX EndNodeIndex   = __node2Index(vEndNode);

	std::cout << "(" << vBeginNode.getPositionX() << ", " << vBeginNode.getPositionY() << ")   " << "(" << vEndNode.getPositionX() << ", " << vEndNode.getPositionY() << ")  " << vWeight << std::endl;
	
	m_Graph.addEdge(BeginNodeIndex, EndNodeIndex, vWeight);
}
