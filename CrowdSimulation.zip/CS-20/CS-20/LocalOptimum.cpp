#include "LocalOptimum.h"

CLocalOptimum::CLocalOptimum(void)
{
}

CLocalOptimum::CLocalOptimum(CScene &vScene)
{
	m_Scence = vScene;
	m_GraphUsual.genGraphUsual(m_Scence);
	m_GraphWithCrowd.genGraphWithCrowd(m_Scence);
}

CLocalOptimum::~CLocalOptimum(void)
{
}

//*******************************************************************
//FUNCTION:
void CLocalOptimum::findBestPath(CSceneNode &vStart, CSceneNode &vEnd)
{
	std::vector<CSceneNode> NodeInSight;
	NodeInSight = m_Scence.getNodeInSight(vStart, 5);
	CSceneNode BestNext;
	float BestCost = 100000.0f;
	for (int i=0; i<NodeInSight.size(); ++i)
	{
		m_Astar = CAstar(m_GraphWithCrowd, vStart, NodeInSight[i]);
		m_Astar.doAstarSimple();
		SPoint TempPointBefore = *(m_Astar.Node2Point(NodeInSight[i]));
		m_Astar = CAstar(m_GraphUsual, NodeInSight[i], vEnd);
		m_Astar.doAstarSimple();
		SPoint TempPointAfter = *(m_Astar.Node2Point(vEnd));
		float TempCost = TempPointAfter.F + TempPointBefore.F;
		if (TempCost < BestCost)
		{
			BestCost = TempCost;
			BestNext = NodeInSight[i];
		}
	}

	std::cout << std::endl;
	std::cout << BestNext.getPositionX() << " " << BestNext.getPositionY() << std::endl;
	std::cout << BestCost;
}