#pragma once
#include <glm/glm.hpp>
#include "Singleton.h"

class CPerson;
class CScene;

class CGenPerson : public CSingleton<CGenPerson>
{
public:
	virtual ~CGenPerson(void);

	CPerson genAttribOfPerson(const glm::vec2& vSpeedRange, CScene& vScene) const;

protected:
	CGenPerson(void);
	friend class CSingleton<CGenPerson>;
};

