#pragma once
#include "Singleton.h"
#include "SceneNode.h"

class CScene;

class CGenScene : public CSingleton<CGenScene>
{
public:
	virtual ~CGenScene();

	void genAttributeOfScene(CScene& voScene);
	void genAttributeOfScene(CScene& voScene, int *vFlag);

protected:
	CGenScene();
	friend class CSingleton<CGenScene>;
};

