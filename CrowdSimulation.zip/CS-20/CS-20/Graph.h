#pragma once
#include "SceneNode.h"
#include <common/WeightedDirectedGraph.h>
#include <vector>

typedef hiveCommon::CWeightedDirectedGraph<CSceneNode>::GraphVertex GRAPHVERTEX;

class CScene;

class CGraph
{
public:
	CGraph();
	~CGraph();

	int   getNumEdges() const {return m_Graph.getNumEdges();}
	float getEdgeWeight(CSceneNode& vBeginNode, CSceneNode& vEndNode);
	void  genGraphUsual(const CScene& vScene);
	void  genGraphWithCrowd(const CScene& vScene);
	void  deleteNode(const CSceneNode& vTargetNode);
	void  getAdjacentNodeSet(const CSceneNode& vTargetNode, std::vector<CSceneNode>& voAdjacentNodeSet) const;
	float getHDistance(const CSceneNode& vBeginNode, const CSceneNode& vEndNode) const;  //��ʱ����յ�ֻ��ˮƽ����ֱ�ƶ�������б���ƶ�

private:
	void        __addNode(CSceneNode& vNode);
	void        __findAdjacentNodes(const CScene& vScene, const CSceneNode& vNode);
	void        __findAdjacentNodesWithCrowd(const CScene& vScene, const CSceneNode& vNode);
	void        __addEdge(const CSceneNode& vBeginNode, const CSceneNode& vEndNode, float vWeight);
	float       __computeEdgeWeight(const CSceneNode& vBeginNode, const CSceneNode& vEndNode) const;
	float       __computeEdgeWeightWithCrowd(const CSceneNode& vBeginNode, const CSceneNode& vEndNode);
	float       __dot(glm::vec2 vVectorA, glm::vec2 vVectorB);
	GRAPHVERTEX __node2Index(const CSceneNode& vTargetNode) const ;
	CSceneNode  __Index2Node(const GRAPHVERTEX& vTargetIndex) const;

private:
	hiveCommon::CWeightedDirectedGraph<CSceneNode>  m_Graph;
	std::vector<std::pair<GRAPHVERTEX, CSceneNode>> m_Node2IndexVec;
};

