#pragma once
#include <glm/glm.hpp>
#include <vector>
#include "SceneNode.h"
#include <iostream>
#include <boost/random.hpp>

class CScene
{
public:
	CScene();
	CScene(const unsigned int vWidth, const unsigned int vHeight, int vCountOfPeople);
	~CScene();

	void         setSceneNode(unsigned int vX, unsigned int vY, const CSceneNode& vSceneNode);
	CSceneNode   getSceneNode(unsigned int vX, unsigned int vY) const;
	unsigned int getSceneWidth() const {return m_SceneDimension.x;}
	unsigned int getSceneHeight() const {return m_SceneDimension.y;}
 	time_t       setSeed();
	void         displayPlaneWithCorwd();
	void         displayPlane();
	double       getFunction(glm::vec2 vPointOne, glm::vec2 vPointTwo, int vX);
	void         computeSlope(glm::vec2 vPointOne, glm::vec2 vPointTwo);
	void         setPerson();
	bool         isVisibility(glm::vec2 vEye, glm::vec2 vTarget);

	std::vector<CSceneNode> getNodeInSight(CSceneNode &vEye, float vRadius);
	float        getRoundFunctionUp(glm::vec2 vCentreOfRound, float vRadius, float vY);
	float        getRoundFunctionDown(glm::vec2 vCentreOfRound, float vRadius, float vY);
private:
	glm::vec2                            m_SceneDimension;
	std::vector<std::vector<CSceneNode>> m_Plane;
	double                               m_Slope;
	int                                  m_CountOfPeople;
};

