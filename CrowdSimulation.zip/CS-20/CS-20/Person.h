#pragma once
#include <glm/glm.hpp>

class CPerson
{
public:
	CPerson();
	CPerson(const glm::vec2& vPos, const glm::vec2& vMoveDir, float vMoveSpeed);
	~CPerson();

	float     getSpeed() const {return m_MoveSpeed;}
	float     getMoveDirectionX() const {return m_MoveDir.x;}
	float     getMoveDirectionY() const {return m_MoveDir.y;}
	glm::vec2 getCurrentPosition() const {return m_Position;}
	bool      operator == (const CPerson& vPerson) {return this->m_Position == vPerson.getCurrentPosition() && this->m_MoveDir == glm::vec2(vPerson.getMoveDirectionX(), vPerson.getMoveDirectionY()) && this->m_MoveSpeed == vPerson.getSpeed();}

private:
	glm::vec2 m_Position;
	glm::vec2 m_MoveDir;
	float     m_MoveSpeed;
};
