#include "genPerson.h"
#include "Person.h"
#include "Scene.h"
#include <boost\random.hpp>

CGenPerson::CGenPerson(void)
{
}

CGenPerson::~CGenPerson(void)
{
}

//*******************************************************************
//FUNCTION:
CPerson CGenPerson::genAttribOfPerson(const glm::vec2& vSpeedRange, CScene& vScene) const
{
 	boost::mt19937_64 Producer(vScene.setSeed());
 
 	boost::uniform_int<int> PositionX(0, vScene.getSceneWidth() - 1);
 	boost::uniform_int<int> PositionY(0, vScene.getSceneHeight() - 1);
 	boost::variate_generator<boost::mt19937_64&, boost::uniform_int<int>> PositionXGenerator(Producer, PositionX);
 	boost::variate_generator<boost::mt19937_64&, boost::uniform_int<int>> PositionYGenerator(Producer, PositionY);
 
 	boost::uniform_int<int> DircetionX(-1, 1);
 	boost::uniform_int<int> DirectionY(-1, 1);
 	boost::variate_generator<boost::mt19937_64&, boost::uniform_int<int>> DirectionXGenerator(Producer, DircetionX);
 	boost::variate_generator<boost::mt19937_64&, boost::uniform_int<int>> DirectionYGenerator(Producer, DirectionY);
 
 	boost::uniform_real<float> Speed(vSpeedRange.x, vSpeedRange.y);
 	boost::variate_generator<boost::mt19937_64&, boost::uniform_real<float>> SpeedGenerator(Producer, Speed);

    glm::vec2 Position  = glm::vec2(PositionXGenerator(), PositionYGenerator());
  	glm::vec2 Direction = glm::vec2(DirectionXGenerator(), DirectionYGenerator());
 	float MoveSpeed = SpeedGenerator();
 
 	CPerson Person(Position, Direction, MoveSpeed);
 
 	return Person;
}
