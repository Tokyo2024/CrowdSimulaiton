#include "Astar.h"
#include "Scene.h"
#include "GenScene.h"
#include "LocalOptimum.h"

const int NUMPERSON = 20;

const int SquareLength = 80;

void transformCoordinate(glm::vec2 &vCoordinate)
{
	vCoordinate.x = floor(vCoordinate.x / SquareLength);
	vCoordinate.y = floor(vCoordinate.y / SquareLength);
}

int main()
{
	CScene *pScene = new CScene(10, 10, 100);
	CGraph *pGraph = new CGraph;
	int Flag[100] = {
		1, 1, 1, 0, 1, 0, 0, 1, 1, 1,
		0, 0, 0, 0, 1, 1, 1, 1, 0, 1,
		0, 0, 1, 0, 0, 0, 1, 0, 0, 0,
		1, 0, 0, 0, 0, 0, 1, 0, 0, 1,
		0, 0, 0, 0, 0, 1, 1, 0, 0, 0,
		0, 0, 1, 1, 0, 0, 0, 1, 1, 1,
		1, 0, 1, 0, 1, 1, 0, 1, 1, 0,
		1, 0, 1, 0, 1, 0, 1, 1, 1, 1,
		0, 1, 0, 0, 1, 1, 0, 1, 1, 1,
		0, 0, 1, 1, 0, 0, 0, 1, 1, 1};
 	CGenScene::getInstance()->genAttributeOfScene(*pScene, Flag);
	//pGraph->genGraphUsual(*pScene);
	CLocalOptimum *LocalOptimum = new CLocalOptimum(*pScene);
	pScene->displayPlane();

	int x1,y1;
	int x2,y2;
	std::cin >> x1;
	std::cin >> y1;
	std::cin >> x2;
	std::cin >> y2;
	CSceneNode Start = pScene->getSceneNode(x1, y1);
 	CSceneNode End = pScene->getSceneNode(x2, y2);
	LocalOptimum->findBestPath(Start, End);

	std::vector<CSceneNode> NodeInSight;

	NodeInSight = pScene->getNodeInSight(Start, 5);

	std::cout << std::endl;
	std::cout << "Point can go are..." << std::endl;
	for (int i=0; i<NodeInSight.size(); ++i)
	{
		std::cout << NodeInSight[i].getPositionX() << " " << NodeInSight[i].getPositionY() << std::endl;
	}



// 
// 	CAstar *pAstar = new CAstar(*pGraph, Start, End);
// 
// 	pAstar->doAstarSimple();
// 	pAstar->showResult();

// 	if (pScene->isVisibility(glm::vec2(x1, y1), glm::vec2(x2, y2)))
// 	{
// 		std::cout << "can see" << std::endl;
// 	}
// 	else
// 	{
// 		std::cout << "can not see" << std::endl;
// 	}
	


	return 0;
}