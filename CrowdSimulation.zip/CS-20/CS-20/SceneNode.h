#pragma once
#include <vector>
#include <glm/glm.hpp>
#include "Person.h"

class CSceneNode
{
public:
	CSceneNode();
	CSceneNode(bool vPassable, const glm::vec2& vCoordinate);
	~CSceneNode();

	float getAvgSpeed() const {return m_AvgSpeed;}
	int   getPositionX() const      {return m_Cordinate.x;}
	int   getPositionY() const      {return m_Cordinate.y;}
	bool  isPassable() const        {return m_Passable;}
	float getAvgMoveDirectionX() const {return m_AvgDirection.x;}
	float getAvgMoveDirectionY() const {return m_AvgDirection.x;}
	float getCrowdDensity() const   {return m_Crowd.size();}
	void  addPerson(const CPerson& vPerson);
	void  deletePerson(const CPerson& vPerson);
	void  dislpayCrowdMoveInfo() const;
	bool  operator == (const CSceneNode& vAnotherNode) const {return m_Cordinate == glm::vec2(vAnotherNode.getPositionX(), vAnotherNode.getPositionY());}

private:
	void  __computeAvgDirection();
private:
	bool                 m_Passable;

	float                m_AvgSpeed;
	glm::vec2            m_Cordinate;
	glm::vec2            m_AvgDirection;
	std::vector<CPerson> m_Crowd;
};



